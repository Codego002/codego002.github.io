#import <UIKit/UIKit.h>

@interface GMLMessageCell : UITableViewCell
- (void)configureWithMessage:(NSDictionary *)message;
@end

@interface GMLMessageDetailViewController : UIViewController
@property (nonatomic, strong) NSDictionary *message;
@property (nonatomic, strong) NSDictionary *account;
@property (nonatomic, strong) NSURL *htmlFileURL;
@end

@interface GMLInboxViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) NSDictionary *focusAccount;
@end
