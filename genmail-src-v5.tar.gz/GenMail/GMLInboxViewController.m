#import "GMLInboxViewController.h"
#import "GMLThemeManager.h"
#import "GMLNetworkManager.h"
#import "GMLAccountStore.h"
#import "GMLCardView.h"
#import <WebKit/WebKit.h>

#pragma mark - GMLMessageCell

@interface GMLMessageCell ()
@property (nonatomic, strong) UILabel *senderLabel;
@property (nonatomic, strong) UILabel *subjectLabel;
@property (nonatomic, strong) UILabel *previewLabel;
@property (nonatomic, strong) UILabel *dateLabel;
@property (nonatomic, strong) UIView *unreadDot;
@end

@implementation GMLMessageCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [GMLThemeManager cellBackgroundColor];
        self.contentView.backgroundColor = self.backgroundColor;
        self.selectionStyle = UITableViewCellSelectionStyleNone;

        self.unreadDot = [[UIView alloc] initWithFrame:CGRectZero];
        self.unreadDot.translatesAutoresizingMaskIntoConstraints = NO;
        self.unreadDot.backgroundColor = [GMLThemeManager accentTextColor];
        self.unreadDot.layer.cornerRadius = 4;
        [self.contentView addSubview:self.unreadDot];

        self.senderLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.senderLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.senderLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightBold];
        self.senderLabel.textColor = [GMLThemeManager primaryTextColor];
        self.senderLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        [self.contentView addSubview:self.senderLabel];

        self.dateLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.dateLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.dateLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
        self.dateLabel.textColor = [GMLThemeManager tertiaryTextColor];
        self.dateLabel.textAlignment = NSTextAlignmentRight;
        [self.dateLabel setContentCompressionResistancePriority:UILayoutPriorityRequired forAxis:UILayoutConstraintAxisHorizontal];
        [self.contentView addSubview:self.dateLabel];

        self.subjectLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.subjectLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.subjectLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
        self.subjectLabel.textColor = [GMLThemeManager primaryTextColor];
        self.subjectLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        [self.contentView addSubview:self.subjectLabel];

        self.previewLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.previewLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.previewLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightRegular];
        self.previewLabel.textColor = [GMLThemeManager tertiaryTextColor];
        self.previewLabel.numberOfLines = 2;
        self.previewLabel.lineBreakMode = NSLineBreakByTruncatingTail;
        [self.contentView addSubview:self.previewLabel];

        [NSLayoutConstraint activateConstraints:@[
            [self.unreadDot.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:8],
            [self.unreadDot.centerYAnchor constraintEqualToAnchor:self.senderLabel.centerYAnchor],
            [self.unreadDot.widthAnchor constraintEqualToConstant:8],
            [self.unreadDot.heightAnchor constraintEqualToConstant:8],

            [self.senderLabel.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:12],
            [self.senderLabel.leadingAnchor constraintEqualToAnchor:self.unreadDot.trailingAnchor constant:8],
            [self.senderLabel.trailingAnchor constraintEqualToAnchor:self.dateLabel.leadingAnchor constant:-8],

            [self.dateLabel.topAnchor constraintEqualToAnchor:self.senderLabel.topAnchor],
            [self.dateLabel.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-16],

            [self.subjectLabel.topAnchor constraintEqualToAnchor:self.senderLabel.bottomAnchor constant:3],
            [self.subjectLabel.leadingAnchor constraintEqualToAnchor:self.senderLabel.leadingAnchor],
            [self.subjectLabel.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-16],

            [self.previewLabel.topAnchor constraintEqualToAnchor:self.subjectLabel.bottomAnchor constant:3],
            [self.previewLabel.leadingAnchor constraintEqualToAnchor:self.senderLabel.leadingAnchor],
            [self.previewLabel.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-16],
            [self.previewLabel.bottomAnchor constraintLessThanOrEqualToAnchor:self.contentView.bottomAnchor constant:-10]
        ]];
    }
    return self;
}

- (void)configureWithMessage:(NSDictionary *)message {
    NSString *from = @"";
    id fromObj = message[@"from"];
    if ([fromObj isKindOfClass:[NSDictionary class]]) {
        from = [[GMLAccountStore shared] stringValue:fromObj[@"name"] fallback:[[GMLAccountStore shared] stringValue:fromObj[@"address"] fallback:@"?"]];
    } else if ([fromObj isKindOfClass:[NSString class]]) {
        from = fromObj;
    }
    self.senderLabel.text = from.length ? from : @"(inconnu)";
    self.subjectLabel.text = [[GMLAccountStore shared] stringValue:message[@"subject"] fallback:@"(sans sujet)"];
    self.previewLabel.text = [[GMLAccountStore shared] compactString:[[GMLAccountStore shared] stringValue:message[@"intro"] fallback:[[GMLAccountStore shared] stringValue:message[@"text"] fallback:@""]] limit:120];

    NSString *date = [[GMLAccountStore shared] stringValue:message[@"createdAt"] fallback:[[GMLAccountStore shared] stringValue:message[@"date"] fallback:@""]];
    if (date.length >= 10) {
        self.dateLabel.text = [date substringToIndex:MIN(16, date.length)];
    } else {
        self.dateLabel.text = date;
    }

    BOOL seen = [message[@"seen"] boolValue];
    self.unreadDot.hidden = seen;
    self.senderLabel.font = [UIFont systemFontOfSize:15 weight:seen ? UIFontWeightMedium : UIFontWeightBold];
}

@end

#pragma mark - GMLMessageDetailViewController

@implementation GMLMessageDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [GMLThemeManager backgroundColor];
    self.title = @"Message";

    NSString *subject = [[GMLAccountStore shared] stringValue:self.message[@"subject"] fallback:@"(sans sujet)"];
    NSString *from = @"";
    id fromObj = self.message[@"from"];
    if ([fromObj isKindOfClass:[NSDictionary class]]) {
        from = [[GMLAccountStore shared] stringValue:fromObj[@"address"] fallback:@"?"];
    } else if ([fromObj isKindOfClass:[NSString class]]) {
        from = fromObj;
    }

    // Header
    UILabel *subjectLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    subjectLabel.translatesAutoresizingMaskIntoConstraints = NO;
    subjectLabel.text = subject;
    subjectLabel.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBold];
    subjectLabel.textColor = [GMLThemeManager primaryTextColor];
    subjectLabel.numberOfLines = 0;
    [self.view addSubview:subjectLabel];

    UILabel *fromLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    fromLabel.translatesAutoresizingMaskIntoConstraints = NO;
    fromLabel.text = [NSString stringWithFormat:@"De: %@", from];
    fromLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    fromLabel.textColor = [GMLThemeManager tertiaryTextColor];
    [self.view addSubview:fromLabel];

    UIView *separator = [[UIView alloc] initWithFrame:CGRectZero];
    separator.translatesAutoresizingMaskIntoConstraints = NO;
    separator.backgroundColor = [GMLThemeManager cardBorderColor];
    [self.view addSubview:separator];

    // WebView for HTML body
    WKWebViewConfiguration *config = [[WKWebViewConfiguration alloc] init];
    WKWebView *webView = [[WKWebView alloc] initWithFrame:CGRectZero configuration:config];
    webView.translatesAutoresizingMaskIntoConstraints = NO;
    webView.backgroundColor = [GMLThemeManager backgroundColor];
    webView.opaque = NO;
    webView.scrollView.backgroundColor = [GMLThemeManager backgroundColor];
    [self.view addSubview:webView];

    [NSLayoutConstraint activateConstraints:@[
        [subjectLabel.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:16],
        [subjectLabel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [subjectLabel.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],

        [fromLabel.topAnchor constraintEqualToAnchor:subjectLabel.bottomAnchor constant:8],
        [fromLabel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [fromLabel.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],

        [separator.topAnchor constraintEqualToAnchor:fromLabel.bottomAnchor constant:12],
        [separator.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [separator.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
        [separator.heightAnchor constraintEqualToConstant:0.5],

        [webView.topAnchor constraintEqualToAnchor:separator.bottomAnchor constant:8],
        [webView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [webView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [webView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor]
    ]];

    // ===== DEBUG INSTRUMENTATION =====
    void (^dbg)(NSString *) = ^(NSString *s) {
        NSString *path = @"/var/mobile/GenMail/AllMail/data/app.log";
        NSString *line = [NSString stringWithFormat:@"[DETAIL] %@\n", s];
        NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
        if (fh) { [fh seekToEndOfFile]; [fh writeData:[line dataUsingEncoding:NSUTF8StringEncoding]]; [fh closeFile]; }
        NSLog(@"[GenMail-DETAIL] %@", s);
    };
    dbg([NSString stringWithFormat:@"viewDidLoad start | msg class=%@", NSStringFromClass([self.message class])]);
    dbg([NSString stringWithFormat:@"msg allKeys=%@", [(NSDictionary *)self.message allKeys]]);
    id htmlRaw = self.message[@"html"];
    id textRaw = self.message[@"text"];
    dbg([NSString stringWithFormat:@"html class=%@ desc-len=%lu", NSStringFromClass([htmlRaw class]), (unsigned long)[[htmlRaw description] length]]);
    if ([htmlRaw isKindOfClass:[NSArray class]]) {
        dbg([NSString stringWithFormat:@"html is NSArray count=%lu", (unsigned long)[(NSArray *)htmlRaw count]]);
        if ([(NSArray *)htmlRaw count] > 0) {
            id first = [(NSArray *)htmlRaw firstObject];
            dbg([NSString stringWithFormat:@"html[0] class=%@ len=%lu", NSStringFromClass([first class]), (unsigned long)[[first description] length]]);
        }
    }
    dbg([NSString stringWithFormat:@"text class=%@ len=%lu", NSStringFromClass([textRaw class]), (unsigned long)[[textRaw description] length]]);
    // ===== END DEBUG =====

    // Load body — robust extraction
    NSString *html = @"";
    if ([htmlRaw isKindOfClass:[NSString class]]) {
        html = (NSString *)htmlRaw;
    } else if ([htmlRaw isKindOfClass:[NSArray class]] && [(NSArray *)htmlRaw count] > 0) {
        id first = [(NSArray *)htmlRaw firstObject];
        if ([first isKindOfClass:[NSString class]]) html = (NSString *)first;
    }
    dbg([NSString stringWithFormat:@"extracted html len=%lu", (unsigned long)html.length]);

    if (html.length == 0) {
        NSString *text = [textRaw isKindOfClass:[NSString class]] ? (NSString *)textRaw : @"";
        if (text.length == 0) text = @"(contenu vide — pas de html ni text dans la reponse API)";
        html = [NSString stringWithFormat:@"<pre style='white-space:pre-wrap;font-family:system-ui;color:#ff6b6b;'>%@</pre>", text];
    }

    NSString *styledHTML = [NSString stringWithFormat:
        @"<html><head><meta name='viewport' content='width=device-width, initial-scale=1'>"
        @"<style>body{background:#0d1117;color:#e0e0e0;font-family:-apple-system,system-ui;font-size:14px;padding:12px;margin:0;word-break:break-word;}"
        @"a{color:#4a9eff;}img{max-width:100%%;height:auto;}.gm-banner{position:fixed;top:0;left:0;right:0;background:#ff00aa;color:#fff;font-size:18px;font-weight:700;padding:8px;z-index:9999;text-align:center;}</style></head><body><div class='gm-banner'>BANNER OK html=%lu</div><div style='height:48px;'></div>%@</body></html>", (unsigned long)html.length, html];
    dbg([NSString stringWithFormat:@"loadHTMLString styledHTML.length=%lu", (unsigned long)styledHTML.length]);
    webView.navigationDelegate = (id<WKNavigationDelegate>)self;
    [webView loadHTMLString:styledHTML baseURL:nil];
    dbg(@"viewDidLoad end");
}

#pragma mark - WKNavigationDelegate (debug)

- (void)webView:(WKWebView *)webView didFinishNavigation:(WKNavigation *)navigation {
    NSString *path = @"/var/mobile/GenMail/AllMail/data/app.log";
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
    if (fh) { [fh seekToEndOfFile]; [fh writeData:[@"[DETAIL] didFinishNavigation OK\n" dataUsingEncoding:NSUTF8StringEncoding]]; [fh closeFile]; }
    [webView evaluateJavaScript:@"document.body.innerText.length + '|' + document.body.scrollHeight + '|' + window.innerHeight + '|' + getComputedStyle(document.body).backgroundColor" completionHandler:^(id res, NSError *err) {
        NSFileHandle *fh2 = [NSFileHandle fileHandleForWritingAtPath:path];
        NSString *s = [NSString stringWithFormat:@"[DETAIL] js-result=%@ err=%@\n", res, err.localizedDescription];
        if (fh2) { [fh2 seekToEndOfFile]; [fh2 writeData:[s dataUsingEncoding:NSUTF8StringEncoding]]; [fh2 closeFile]; }
    }];
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    NSString *path = @"/var/mobile/GenMail/AllMail/data/app.log";
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
    NSString *s = [NSString stringWithFormat:@"[DETAIL] didFailNavigation err=%@\n", error.localizedDescription];
    if (fh) { [fh seekToEndOfFile]; [fh writeData:[s dataUsingEncoding:NSUTF8StringEncoding]]; [fh closeFile]; }
}

- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    NSString *path = @"/var/mobile/GenMail/AllMail/data/app.log";
    NSFileHandle *fh = [NSFileHandle fileHandleForWritingAtPath:path];
    NSString *s = [NSString stringWithFormat:@"[DETAIL] didFailProvisional err=%@\n", error.localizedDescription];
    if (fh) { [fh seekToEndOfFile]; [fh writeData:[s dataUsingEncoding:NSUTF8StringEncoding]]; [fh closeFile]; }
}

@end

#pragma mark - GMLAccountPillCell

@interface GMLAccountPillCell : UICollectionViewCell
@property (nonatomic, strong) UILabel *emailLabel;
@property (nonatomic, strong) UILabel *countBadge;
@end

@implementation GMLAccountPillCell

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.contentView.layer.cornerRadius = 16;
        self.contentView.clipsToBounds = YES;
        self.contentView.backgroundColor = [GMLThemeManager inputBackgroundColor];

        self.emailLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.emailLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.emailLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
        self.emailLabel.textColor = [GMLThemeManager tertiaryTextColor];
        self.emailLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
        [self.contentView addSubview:self.emailLabel];

        self.countBadge = [[UILabel alloc] initWithFrame:CGRectZero];
        self.countBadge.translatesAutoresizingMaskIntoConstraints = NO;
        self.countBadge.font = [UIFont monospacedDigitSystemFontOfSize:11 weight:UIFontWeightBold];
        self.countBadge.textColor = [UIColor whiteColor];
        self.countBadge.textAlignment = NSTextAlignmentCenter;
        self.countBadge.backgroundColor = [GMLThemeManager tertiaryTextColor];
        self.countBadge.layer.cornerRadius = 9;
        self.countBadge.clipsToBounds = YES;
        [self.contentView addSubview:self.countBadge];

        [NSLayoutConstraint activateConstraints:@[
            [self.emailLabel.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:12],
            [self.emailLabel.centerYAnchor constraintEqualToAnchor:self.contentView.centerYAnchor],
            [self.emailLabel.trailingAnchor constraintLessThanOrEqualToAnchor:self.countBadge.leadingAnchor constant:-6],

            [self.countBadge.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-8],
            [self.countBadge.centerYAnchor constraintEqualToAnchor:self.contentView.centerYAnchor],
            [self.countBadge.widthAnchor constraintGreaterThanOrEqualToConstant:18],
            [self.countBadge.heightAnchor constraintEqualToConstant:18]
        ]];
    }
    return self;
}

- (void)configureWithEmail:(NSString *)email count:(NSInteger)count selected:(BOOL)selected {
    NSString *short_ = email.length > 22 ? [[email substringToIndex:20] stringByAppendingString:@".."] : email;
    self.emailLabel.text = short_;
    self.countBadge.text = [NSString stringWithFormat:@"%ld", (long)count];
    if (selected) {
        self.contentView.backgroundColor = [GMLThemeManager accentTextColor];
        self.emailLabel.textColor = [UIColor whiteColor];
        self.countBadge.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.3];
        self.countBadge.textColor = [UIColor whiteColor];
    } else {
        self.contentView.backgroundColor = [GMLThemeManager inputBackgroundColor];
        self.emailLabel.textColor = [GMLThemeManager tertiaryTextColor];
        self.countBadge.backgroundColor = count > 0 ? [GMLThemeManager accentTextColor] : [GMLThemeManager tertiaryTextColor];
        self.countBadge.textColor = [UIColor whiteColor];
    }
}

- (CGSize)sizeThatFits:(CGSize)size {
    CGFloat emailW = [self.emailLabel.text sizeWithAttributes:@{NSFontAttributeName: self.emailLabel.font}].width;
    return CGSizeMake(emailW + 12 + 6 + 18 + 8 + 4, 32);
}

@end

#pragma mark - GMLInboxViewController

@interface GMLInboxViewController () <UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>
@property (nonatomic, strong) UICollectionView *accountStrip;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UILabel *emptyLabel;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) UIRefreshControl *refreshControl;
@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) NSArray *accountsWithToken;
@property (nonatomic, strong) NSArray *messages;
@property (nonatomic, strong) NSDictionary *currentAccount;
@property (nonatomic, strong) NSTimer *autoRefreshTimer;
@property (nonatomic, assign) NSInteger selectedAccountIndex;
@end

@implementation GMLInboxViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [GMLThemeManager backgroundColor];
    self.messages = @[];
    self.accountsWithToken = @[];
    self.selectedAccountIndex = 0;

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(accountsDidUpdate) name:GMLAccountsDidChangeNotification object:nil];

    // Horizontal scrollable account strip
    UICollectionViewFlowLayout *flow = [[UICollectionViewFlowLayout alloc] init];
    flow.scrollDirection = UICollectionViewScrollDirectionHorizontal;
    flow.minimumInteritemSpacing = 8;
    flow.minimumLineSpacing = 8;
    flow.sectionInset = UIEdgeInsetsMake(0, 12, 0, 12);
    flow.estimatedItemSize = CGSizeMake(160, 32);

    self.accountStrip = [[UICollectionView alloc] initWithFrame:CGRectZero collectionViewLayout:flow];
    self.accountStrip.translatesAutoresizingMaskIntoConstraints = NO;
    self.accountStrip.backgroundColor = [UIColor clearColor];
    self.accountStrip.showsHorizontalScrollIndicator = NO;
    self.accountStrip.dataSource = self;
    self.accountStrip.delegate = self;
    [self.accountStrip registerClass:[GMLAccountPillCell class] forCellWithReuseIdentifier:@"PillCell"];
    [self.view addSubview:self.accountStrip];

    // Status
    self.statusLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.statusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.statusLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
    self.statusLabel.textColor = [GMLThemeManager tertiaryTextColor];
    self.statusLabel.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.statusLabel];

    // Spinner
    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    self.spinner.translatesAutoresizingMaskIntoConstraints = NO;
    self.spinner.color = [GMLThemeManager accentTextColor];
    [self.view addSubview:self.spinner];

    // Table
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [GMLThemeManager backgroundColor];
    self.tableView.separatorColor = [GMLThemeManager cardBorderColor];
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.tableView.estimatedRowHeight = 90;
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    [self.tableView registerClass:[GMLMessageCell class] forCellReuseIdentifier:@"MessageCell"];
    [self.view addSubview:self.tableView];

    self.refreshControl = [[UIRefreshControl alloc] init];
    self.refreshControl.tintColor = [GMLThemeManager accentTextColor];
    [self.refreshControl addTarget:self action:@selector(refreshMessages) forControlEvents:UIControlEventValueChanged];
    self.tableView.refreshControl = self.refreshControl;

    // Empty
    self.emptyLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.emptyLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.emptyLabel.text = @"Aucun message.\nSelectionnez un compte pour charger les messages.";
    self.emptyLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    self.emptyLabel.textColor = [GMLThemeManager tertiaryTextColor];
    self.emptyLabel.textAlignment = NSTextAlignmentCenter;
    self.emptyLabel.numberOfLines = 0;
    [self.view addSubview:self.emptyLabel];

    [NSLayoutConstraint activateConstraints:@[
        [self.accountStrip.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:6],
        [self.accountStrip.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.accountStrip.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.accountStrip.heightAnchor constraintEqualToConstant:40],

        [self.statusLabel.topAnchor constraintEqualToAnchor:self.accountStrip.bottomAnchor constant:4],
        [self.statusLabel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [self.statusLabel.trailingAnchor constraintEqualToAnchor:self.spinner.leadingAnchor constant:-8],

        [self.spinner.centerYAnchor constraintEqualToAnchor:self.statusLabel.centerYAnchor],
        [self.spinner.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],

        [self.tableView.topAnchor constraintEqualToAnchor:self.statusLabel.bottomAnchor constant:6],
        [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.tableView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],

        [self.emptyLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.emptyLabel.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
        [self.emptyLabel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:40],
        [self.emptyLabel.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-40]
    ]];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    if (self.focusAccount) {
        self.accountStrip.hidden = YES;
        self.currentAccount = self.focusAccount;
        NSString *email = [[GMLAccountStore shared] stringValue:self.focusAccount[@"email"] fallback:@""];
        self.title = email;
        [self fetchMessages];
    } else {
        [self reloadAccountPicker];
    }
    [self startAutoRefreshIfEnabled];
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [self stopAutoRefresh];
}

- (void)startAutoRefreshIfEnabled {
    [self stopAutoRefresh];
    BOOL enabled = [[NSUserDefaults standardUserDefaults] boolForKey:@"GMLAutoRefreshEnabled"];
    if (!enabled) return;
    self.autoRefreshTimer = [NSTimer scheduledTimerWithTimeInterval:30.0
                                                            target:self
                                                          selector:@selector(autoRefreshTick)
                                                          userInfo:nil
                                                           repeats:YES];
}

- (void)stopAutoRefresh {
    [self.autoRefreshTimer invalidate];
    self.autoRefreshTimer = nil;
}

- (void)autoRefreshTick {
    if (self.currentAccount && !self.spinner.isAnimating) {
        [self fetchMessages];
    }
}

- (void)updateBadge {
    if (self.focusAccount) return;
    NSInteger unread = 0;
    for (NSDictionary *msg in self.messages) {
        if (![msg[@"seen"] boolValue]) unread++;
    }
    self.tabBarItem.badgeValue = unread > 0 ? [NSString stringWithFormat:@"%ld", (long)unread] : nil;
    UIApplication.sharedApplication.applicationIconBadgeNumber = (NSInteger)unread;
}

- (void)reloadAccountPicker {
    NSArray *all = [[GMLAccountStore shared] loadAccounts];
    NSMutableArray *withToken = [NSMutableArray array];
    for (NSDictionary *a in all) {
        NSString *token = [[GMLAccountStore shared] stringValue:a[@"token"] fallback:@""];
        if (token.length > 0) [withToken addObject:a];
    }
    self.accountsWithToken = withToken;

    if (withToken.count == 0) {
        self.currentAccount = nil;
        self.selectedAccountIndex = 0;
        self.messages = @[];
        [self.accountStrip reloadData];
        [self updateUI];
        return;
    }

    if (self.currentAccount) {
        NSString *currentEmail = [[GMLAccountStore shared] stringValue:self.currentAccount[@"email"] fallback:@""];
        NSInteger idx = NSNotFound;
        for (NSInteger i = 0; i < (NSInteger)withToken.count; i++) {
            if ([[[GMLAccountStore shared] stringValue:withToken[i][@"email"] fallback:@""] isEqualToString:currentEmail]) {
                idx = i;
                break;
            }
        }
        if (idx != NSNotFound) {
            self.selectedAccountIndex = idx;
        } else {
            self.selectedAccountIndex = 0;
            self.currentAccount = withToken.firstObject;
            [self fetchMessages];
        }
    } else {
        self.selectedAccountIndex = 0;
        self.currentAccount = withToken.firstObject;
        [self fetchMessages];
    }
    [self.accountStrip reloadData];
}

#pragma mark - UICollectionViewDataSource (Account Strip)

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return self.accountsWithToken.count > 0 ? (NSInteger)self.accountsWithToken.count : 1;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    GMLAccountPillCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:@"PillCell" forIndexPath:indexPath];
    if (self.accountsWithToken.count == 0) {
        [cell configureWithEmail:@"Aucun compte" count:0 selected:NO];
        return cell;
    }
    NSDictionary *account = self.accountsWithToken[indexPath.item];
    NSString *email = [[GMLAccountStore shared] stringValue:account[@"email"] fallback:@"?"];
    NSInteger count = [account[@"messages_count"] integerValue];
    BOOL selected = indexPath.item == self.selectedAccountIndex;
    [cell configureWithEmail:email count:count selected:selected];
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)layout sizeForItemAtIndexPath:(NSIndexPath *)indexPath {
    NSString *email;
    if (self.accountsWithToken.count == 0) {
        email = @"Aucun compte";
    } else {
        email = [[GMLAccountStore shared] stringValue:self.accountsWithToken[indexPath.item][@"email"] fallback:@"?"];
        if (email.length > 22) email = [[email substringToIndex:20] stringByAppendingString:@".."];
    }
    CGFloat emailW = [email sizeWithAttributes:@{NSFontAttributeName: [UIFont systemFontOfSize:12 weight:UIFontWeightMedium]}].width;
    return CGSizeMake(emailW + 48, 32);
}

- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    if (self.accountsWithToken.count == 0) return;
    self.selectedAccountIndex = indexPath.item;
    self.currentAccount = self.accountsWithToken[indexPath.item];
    [self.accountStrip reloadData];
    [self fetchMessages];
}

- (void)accountsDidUpdate {
    if (self.focusAccount) return;
    // Reload accounts with fresh data (includes updated message counts)
    NSArray *all = [[GMLAccountStore shared] loadAccounts];
    NSMutableArray *withToken = [NSMutableArray array];
    for (NSDictionary *a in all) {
        NSString *token = [[GMLAccountStore shared] stringValue:a[@"token"] fallback:@""];
        if (token.length > 0) [withToken addObject:a];
    }
    self.accountsWithToken = withToken;
    [self.accountStrip reloadData];
}

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)refreshMessages {
    [self fetchMessages];
}

- (void)fetchMessages {
    if (!self.currentAccount) return;
    NSString *provider = [[GMLAccountStore shared] stringValue:self.currentAccount[@"provider"] fallback:@""];
    NSString *token = [[GMLAccountStore shared] stringValue:self.currentAccount[@"token"] fallback:@""];
    if (token.length == 0) {
        self.statusLabel.text = @"Token absent pour ce compte";
        return;
    }

    self.statusLabel.text = @"Chargement...";
    [self.spinner startAnimating];

    NSString *url = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/messages" : @"https://api.mail.tm/messages";
    __weak typeof(self) weakSelf = self;
    [[GMLNetworkManager shared] requestJSON:@"GET" url:url token:token jsonBody:nil provider:provider completion:^(NSInteger status, id payload) {
        dispatch_async(dispatch_get_main_queue(), ^{
            [weakSelf.spinner stopAnimating];
            [weakSelf.refreshControl endRefreshing];

            if (status >= 400 || status == 0) {
                weakSelf.statusLabel.text = [NSString stringWithFormat:@"Erreur %ld", (long)status];
                weakSelf.messages = @[];
                [weakSelf updateUI];
                return;
            }

            NSArray *items = nil;
            if ([provider isEqualToString:@"tempemail"]) {
                if ([payload[@"data"] isKindOfClass:[NSDictionary class]]) {
                    items = payload[@"data"][@"items"];
                }
            } else {
                if ([payload isKindOfClass:[NSDictionary class]]) {
                    items = payload[@"hydra:member"];
                }
            }
            weakSelf.messages = [items isKindOfClass:[NSArray class]] ? items : @[];
            weakSelf.statusLabel.text = [NSString stringWithFormat:@"%ld message(s)", (long)weakSelf.messages.count];
            // Sync message count back to account store
            NSString *email = [[GMLAccountStore shared] stringValue:weakSelf.currentAccount[@"email"] fallback:@""];
            [[GMLAccountStore shared] updateMessageCount:(NSInteger)weakSelf.messages.count forEmail:email];
            [weakSelf updateUI];
            [weakSelf updateBadge];
        });
    }];
}

- (void)dismissSelf {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)updateUI {
    self.emptyLabel.hidden = self.messages.count > 0;
    self.tableView.hidden = self.messages.count == 0;
    [self.tableView reloadData];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.messages.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    GMLMessageCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MessageCell" forIndexPath:indexPath];
    [cell configureWithMessage:self.messages[indexPath.row]];
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *message = self.messages[indexPath.row];
    UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [haptic impactOccurred];

    // If we only have a summary, fetch full message first
    NSString *messageId = [[GMLAccountStore shared] stringValue:message[@"id"] fallback:[[GMLAccountStore shared] stringValue:message[@"@id"] fallback:@""]];
    NSString *provider = [[GMLAccountStore shared] stringValue:self.currentAccount[@"provider"] fallback:@""];
    NSString *token = [[GMLAccountStore shared] stringValue:self.currentAccount[@"token"] fallback:@""];

    if (messageId.length > 0 && !message[@"html"] && !message[@"text"]) {
        // Fetch full message
        NSString *baseUrl = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/messages" : @"https://api.mail.tm";
        NSString *url;
        if ([provider isEqualToString:@"tempemail"]) {
            url = [NSString stringWithFormat:@"%@/%@", baseUrl, messageId];
        } else {
            url = [messageId hasPrefix:@"/"] ? [NSString stringWithFormat:@"https://api.mail.tm%@", messageId] : [NSString stringWithFormat:@"https://api.mail.tm/messages/%@", messageId];
        }

        self.statusLabel.text = @"Chargement message...";
        [self.spinner startAnimating];

        __weak typeof(self) weakSelf = self;
        [[GMLNetworkManager shared] requestJSON:@"GET" url:url token:token jsonBody:nil provider:provider completion:^(NSInteger status, id payload) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.spinner stopAnimating];
                weakSelf.statusLabel.text = @"";
                NSDictionary *full = nil;
                if (status < 400 && status > 0 && [payload isKindOfClass:[NSDictionary class]]) {
                    // tempemail.cc wraps response in {code, message, data:{...}} — unwrap
                    if ([provider isEqualToString:@"tempemail"] && [payload[@"data"] isKindOfClass:[NSDictionary class]]) {
                        full = payload[@"data"];
                    } else {
                        full = payload;
                    }
                }
                [weakSelf showMessageDetail:full ?: message];
            });
        }];
    } else {
        [self showMessageDetail:message];
    }
}

- (void)showMessageDetail:(NSDictionary *)message {
    GMLMessageDetailViewController *detail = [[GMLMessageDetailViewController alloc] init];
    detail.message = message;
    detail.account = self.currentAccount;
    [self.navigationController pushViewController:detail animated:YES];
}

@end
