#import <UIKit/UIKit.h>

@interface GMLThemeManager : NSObject

// Background colors
+ (UIColor *)backgroundColor;
+ (UIColor *)cardBackgroundColor;
+ (UIColor *)heroCardBackgroundColor;
+ (UIColor *)inputBackgroundColor;
+ (UIColor *)textViewBackgroundColor;
+ (UIColor *)cellBackgroundColor;
+ (UIColor *)badgeBackgroundColor;
+ (UIColor *)chromeButtonBackgroundColor;
+ (UIColor *)chromeButtonActiveBackgroundColor;
+ (UIColor *)secondaryButtonBackgroundColor;
+ (UIColor *)primaryButtonBackgroundColor;

// Border colors
+ (UIColor *)cardBorderColor;
+ (UIColor *)inputBorderColor;
+ (UIColor *)textViewBorderColor;
+ (UIColor *)chromeButtonBorderColor;
+ (UIColor *)secondaryButtonBorderColor;
+ (UIColor *)logoBorderColor;

// Text colors
+ (UIColor *)primaryTextColor;
+ (UIColor *)secondaryTextColor;
+ (UIColor *)tertiaryTextColor;
+ (UIColor *)placeholderTextColor;
+ (UIColor *)accentTextColor;
+ (UIColor *)badgeTextColor;
+ (UIColor *)chromeButtonTintColor;
+ (UIColor *)textViewTextColor;
+ (UIColor *)fieldLabelColor;
+ (UIColor *)logoTintColor;

// Navigation
+ (UIColor *)navBarBackgroundColor;
+ (UIColor *)navBarTintColor;
+ (UIColor *)windowBackgroundColor;

// Shadow
+ (UIColor *)cardShadowColor;

// Layout constants
+ (CGFloat)cardCornerRadius;
+ (CGFloat)heroCardCornerRadius;
+ (CGFloat)buttonCornerRadius;
+ (CGFloat)inputCornerRadius;
+ (CGFloat)textViewCornerRadius;
+ (CGFloat)chromeButtonCornerRadius;
+ (CGFloat)chromeButtonSize;
+ (CGFloat)badgeCornerRadius;
+ (CGFloat)badgeHeight;
+ (CGFloat)badgeMinWidth;
+ (CGFloat)logoCornerRadius;
+ (CGFloat)cardShadowOpacity;
+ (CGFloat)cardShadowRadius;
+ (CGSize)cardShadowOffset;
+ (CGFloat)inputHeight;

@end
