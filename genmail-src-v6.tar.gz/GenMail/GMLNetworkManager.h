#import <Foundation/Foundation.h>

typedef void (^GMLHTTPCompletion)(NSInteger statusCode, id payload);
typedef void (^GMLDomainsCompletion)(NSArray *domains, NSString *error);

@interface GMLNetworkManager : NSObject

+ (instancetype)shared;

- (void)requestJSON:(NSString *)method
                url:(NSString *)url
              token:(NSString *)token
           jsonBody:(id)jsonBody
           provider:(NSString *)provider
         completion:(GMLHTTPCompletion)completion;

- (void)fetchDomainsForProvider:(NSString *)provider
                     completion:(GMLDomainsCompletion)completion;

- (NSArray *)extractDomainsFromPayload:(id)payload provider:(NSString *)provider;

@property (nonatomic, copy) void (^logBlock)(NSString *message, NSString *level);

@end
