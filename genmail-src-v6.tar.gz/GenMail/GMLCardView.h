#import <UIKit/UIKit.h>

@interface GMLCardView : UIView

+ (instancetype)card;
+ (instancetype)heroCard;

@end

@interface GMLGradientButton : UIButton
@property (nonatomic, strong) CAGradientLayer *gradientLayer;
@property (nonatomic, strong) CAGradientLayer *shimmerLayer;
- (void)startShimmer;
- (void)stopShimmer;
@end

@interface GMLCircularProgressView : UIView
@property (nonatomic, assign) CGFloat progress;
@property (nonatomic, strong) UILabel *percentLabel;
- (void)setProgress:(CGFloat)progress animated:(BOOL)animated;
- (void)showSuccess;
- (void)reset;
@end

@interface GMLUIFactory : NSObject

+ (UILabel *)badgeLabel:(NSString *)text;
+ (UIButton *)actionButton:(NSString *)title primary:(BOOL)primary;
+ (GMLGradientButton *)gradientButton:(NSString *)title;
+ (GMLCircularProgressView *)circularProgress;
+ (UIImage *)symbolImageNamed:(NSString *)name;
+ (UIButton *)chromeButtonWithSymbol:(NSString *)symbol accessibility:(NSString *)label;
+ (UITextField *)textFieldWithPlaceholder:(NSString *)placeholder delegate:(id<UITextFieldDelegate>)delegate;
+ (UIToolbar *)numericAccessoryToolbarWithTarget:(id)target action:(SEL)action;
+ (UITextView *)textViewWithMinHeight:(CGFloat)height;
+ (UILabel *)sectionTitle:(NSString *)text;
+ (UIView *)fieldBlockWithTitle:(NSString *)title control:(UIView *)control;
+ (UIStackView *)horizontalStack:(NSArray *)views compact:(BOOL)compact;

@end
