#import "GMLTabBarController.h"
#import "GMLThemeManager.h"
#import "RootViewController.h"
#import "GMLAccountsViewController.h"
#import "GMLInboxViewController.h"
#import "GMLSettingsViewController.h"

@implementation GMLTabBarController

- (void)viewDidLoad {
    [super viewDidLoad];

    UITabBarAppearance *appearance = [[UITabBarAppearance alloc] init];
    [appearance configureWithOpaqueBackground];
    appearance.backgroundColor = [GMLThemeManager cardBackgroundColor];
    appearance.shadowColor = [UIColor clearColor];

    UITabBarItemAppearance *itemAppearance = [[UITabBarItemAppearance alloc] initWithStyle:UITabBarItemAppearanceStyleStacked];
    [itemAppearance.normal setTitleTextAttributes:@{ NSForegroundColorAttributeName: [GMLThemeManager tertiaryTextColor] }];
    [itemAppearance.normal setIconColor:[GMLThemeManager tertiaryTextColor]];
    [itemAppearance.selected setTitleTextAttributes:@{ NSForegroundColorAttributeName: [GMLThemeManager accentTextColor] }];
    [itemAppearance.selected setIconColor:[GMLThemeManager accentTextColor]];
    appearance.stackedLayoutAppearance = itemAppearance;
    appearance.inlineLayoutAppearance = itemAppearance;
    appearance.compactInlineLayoutAppearance = itemAppearance;

    self.tabBar.standardAppearance = appearance;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability-new"
    if ([self.tabBar respondsToSelector:@selector(setScrollEdgeAppearance:)]) {
        self.tabBar.scrollEdgeAppearance = appearance;
    }
#pragma clang diagnostic pop

    UIView *topBorder = [[UIView alloc] initWithFrame:CGRectZero];
    topBorder.translatesAutoresizingMaskIntoConstraints = NO;
    topBorder.backgroundColor = [GMLThemeManager cardBorderColor];
    [self.tabBar addSubview:topBorder];
    [NSLayoutConstraint activateConstraints:@[
        [topBorder.topAnchor constraintEqualToAnchor:self.tabBar.topAnchor],
        [topBorder.leadingAnchor constraintEqualToAnchor:self.tabBar.leadingAnchor],
        [topBorder.trailingAnchor constraintEqualToAnchor:self.tabBar.trailingAnchor],
        [topBorder.heightAnchor constraintEqualToConstant:0.5]
    ]];

    RootViewController *studioVC = [[RootViewController alloc] init];
    studioVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Studio"
                                                        image:[UIImage systemImageNamed:@"wand.and.stars"]
                                                          tag:0];

    GMLAccountsViewController *accountsVC = [[GMLAccountsViewController alloc] init];
    accountsVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Comptes"
                                                          image:[UIImage systemImageNamed:@"person.crop.rectangle.stack"]
                                                            tag:1];

    GMLInboxViewController *inboxVC = [[GMLInboxViewController alloc] init];
    inboxVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Inbox"
                                                       image:[UIImage systemImageNamed:@"envelope"]
                                                         tag:2];

    GMLSettingsViewController *settingsVC = [[GMLSettingsViewController alloc] init];
    settingsVC.tabBarItem = [[UITabBarItem alloc] initWithTitle:@"Reglages"
                                                          image:[UIImage systemImageNamed:@"gearshape"]
                                                            tag:3];

    UINavigationController *nav0 = [self navForVC:studioVC title:@"GenMail"];
    UINavigationController *nav1 = [self navForVC:accountsVC title:@"Comptes"];
    UINavigationController *nav2 = [self navForVC:inboxVC title:@"Inbox"];
    UINavigationController *nav3 = [self navForVC:settingsVC title:@"Reglages"];

    self.viewControllers = @[nav0, nav1, nav2, nav3];
}

- (UINavigationController *)navForVC:(UIViewController *)vc title:(NSString *)title {
    vc.title = title;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:vc];
    nav.navigationBar.prefersLargeTitles = YES;

    UINavigationBarAppearance *appearance = [[UINavigationBarAppearance alloc] init];
    [appearance configureWithOpaqueBackground];
    appearance.backgroundColor = [GMLThemeManager navBarBackgroundColor];
    appearance.titleTextAttributes = @{ NSForegroundColorAttributeName: [GMLThemeManager primaryTextColor] };
    appearance.largeTitleTextAttributes = @{ NSForegroundColorAttributeName: [GMLThemeManager primaryTextColor] };
    nav.navigationBar.standardAppearance = appearance;
    nav.navigationBar.scrollEdgeAppearance = appearance;
    nav.navigationBar.compactAppearance = appearance;
    nav.navigationBar.tintColor = [GMLThemeManager navBarTintColor];

    return nav;
}

- (UIViewController *)placeholderVC:(NSString *)title subtitle:(NSString *)subtitle {
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view.backgroundColor = [GMLThemeManager backgroundColor];

    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:48 weight:UIImageSymbolWeightLight];
    UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"hammer.fill" withConfiguration:cfg]];
    icon.translatesAutoresizingMaskIntoConstraints = NO;
    icon.tintColor = [GMLThemeManager tertiaryTextColor];
    [vc.view addSubview:icon];

    UILabel *titleLabel = [[UILabel alloc] init];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = title;
    titleLabel.font = [UIFont systemFontOfSize:22 weight:UIFontWeightBold];
    titleLabel.textColor = [GMLThemeManager primaryTextColor];
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [vc.view addSubview:titleLabel];

    UILabel *sub = [[UILabel alloc] init];
    sub.translatesAutoresizingMaskIntoConstraints = NO;
    sub.text = subtitle;
    sub.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    sub.textColor = [GMLThemeManager tertiaryTextColor];
    sub.textAlignment = NSTextAlignmentCenter;
    sub.numberOfLines = 0;
    [vc.view addSubview:sub];

    [NSLayoutConstraint activateConstraints:@[
        [icon.centerXAnchor constraintEqualToAnchor:vc.view.centerXAnchor],
        [icon.centerYAnchor constraintEqualToAnchor:vc.view.centerYAnchor constant:-40],
        [titleLabel.topAnchor constraintEqualToAnchor:icon.bottomAnchor constant:16],
        [titleLabel.centerXAnchor constraintEqualToAnchor:vc.view.centerXAnchor],
        [sub.topAnchor constraintEqualToAnchor:titleLabel.bottomAnchor constant:8],
        [sub.leadingAnchor constraintEqualToAnchor:vc.view.leadingAnchor constant:40],
        [sub.trailingAnchor constraintEqualToAnchor:vc.view.trailingAnchor constant:-40]
    ]];

    return vc;
}

@end
