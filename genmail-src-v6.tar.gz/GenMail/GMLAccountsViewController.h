#import <UIKit/UIKit.h>

@interface GMLAccountCell : UITableViewCell
- (void)configureWithAccount:(NSDictionary *)account selected:(BOOL)selected;
@end

@interface GMLAccountDetailViewController : UIViewController
@property (nonatomic, strong) NSDictionary *account;
@end

@interface GMLAccountsViewController : UIViewController <UITableViewDataSource, UITableViewDelegate, UISearchBarDelegate>
@property (nonatomic, strong) NSMutableArray *accounts;
- (void)reloadAccounts;
- (void)toggleSelectionMode;
@end
