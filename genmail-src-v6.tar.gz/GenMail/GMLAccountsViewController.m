#import "GMLAccountsViewController.h"
#import "GMLInboxViewController.h"
#import "GMLThemeManager.h"
#import "GMLAccountStore.h"
#import "GMLCardView.h"

#pragma mark - GMLAccountCell

@interface GMLAccountCell ()
@property (nonatomic, strong) UIView *avatarView;
@property (nonatomic, strong) UILabel *avatarLabel;
@property (nonatomic, strong) UILabel *emailLabel;
@property (nonatomic, strong) UILabel *providerLabel;
@property (nonatomic, strong) UILabel *statusBadge;
@property (nonatomic, strong) UILabel *messagesLabel;
@property (nonatomic, strong) UILabel *dateLabel;
@property (nonatomic, strong) UIImageView *chevron;
@end

@implementation GMLAccountCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [GMLThemeManager cellBackgroundColor];
        self.contentView.backgroundColor = self.backgroundColor;
        self.selectionStyle = UITableViewCellSelectionStyleNone;

        self.avatarView = [[UIView alloc] initWithFrame:CGRectZero];
        self.avatarView.translatesAutoresizingMaskIntoConstraints = NO;
        self.avatarView.layer.cornerRadius = 22;
        self.avatarView.clipsToBounds = YES;
        [self.contentView addSubview:self.avatarView];

        self.avatarLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.avatarLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.avatarLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightBold];
        self.avatarLabel.textColor = [UIColor whiteColor];
        self.avatarLabel.textAlignment = NSTextAlignmentCenter;
        [self.avatarView addSubview:self.avatarLabel];

        self.emailLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.emailLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.emailLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
        self.emailLabel.textColor = [GMLThemeManager primaryTextColor];
        self.emailLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
        [self.contentView addSubview:self.emailLabel];

        self.providerLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.providerLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.providerLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
        self.providerLabel.textColor = [GMLThemeManager tertiaryTextColor];
        [self.contentView addSubview:self.providerLabel];

        self.statusBadge = [[UILabel alloc] initWithFrame:CGRectZero];
        self.statusBadge.translatesAutoresizingMaskIntoConstraints = NO;
        self.statusBadge.font = [UIFont systemFontOfSize:11 weight:UIFontWeightBold];
        self.statusBadge.textAlignment = NSTextAlignmentCenter;
        self.statusBadge.layer.cornerRadius = 8;
        self.statusBadge.clipsToBounds = YES;
        [self.contentView addSubview:self.statusBadge];

        self.messagesLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.messagesLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.messagesLabel.font = [UIFont systemFontOfSize:12 weight:UIFontWeightMedium];
        self.messagesLabel.textColor = [GMLThemeManager tertiaryTextColor];
        [self.contentView addSubview:self.messagesLabel];

        self.dateLabel = [[UILabel alloc] initWithFrame:CGRectZero];
        self.dateLabel.translatesAutoresizingMaskIntoConstraints = NO;
        self.dateLabel.font = [UIFont systemFontOfSize:11 weight:UIFontWeightRegular];
        self.dateLabel.textColor = [GMLThemeManager tertiaryTextColor];
        [self.contentView addSubview:self.dateLabel];

        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:12 weight:UIImageSymbolWeightMedium];
        self.chevron = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:@"chevron.right" withConfiguration:cfg]];
        self.chevron.translatesAutoresizingMaskIntoConstraints = NO;
        self.chevron.tintColor = [GMLThemeManager tertiaryTextColor];
        [self.contentView addSubview:self.chevron];

        [NSLayoutConstraint activateConstraints:@[
            [self.avatarView.leadingAnchor constraintEqualToAnchor:self.contentView.leadingAnchor constant:16],
            [self.avatarView.centerYAnchor constraintEqualToAnchor:self.contentView.centerYAnchor],
            [self.avatarView.widthAnchor constraintEqualToConstant:44],
            [self.avatarView.heightAnchor constraintEqualToConstant:44],

            [self.avatarLabel.centerXAnchor constraintEqualToAnchor:self.avatarView.centerXAnchor],
            [self.avatarLabel.centerYAnchor constraintEqualToAnchor:self.avatarView.centerYAnchor],

            [self.emailLabel.topAnchor constraintEqualToAnchor:self.contentView.topAnchor constant:12],
            [self.emailLabel.leadingAnchor constraintEqualToAnchor:self.avatarView.trailingAnchor constant:12],
            [self.emailLabel.trailingAnchor constraintEqualToAnchor:self.chevron.leadingAnchor constant:-8],

            [self.providerLabel.topAnchor constraintEqualToAnchor:self.emailLabel.bottomAnchor constant:4],
            [self.providerLabel.leadingAnchor constraintEqualToAnchor:self.emailLabel.leadingAnchor],

            [self.statusBadge.topAnchor constraintEqualToAnchor:self.emailLabel.bottomAnchor constant:3],
            [self.statusBadge.leadingAnchor constraintEqualToAnchor:self.providerLabel.trailingAnchor constant:8],
            [self.statusBadge.heightAnchor constraintEqualToConstant:20],
            [self.statusBadge.widthAnchor constraintGreaterThanOrEqualToConstant:36],

            [self.messagesLabel.topAnchor constraintEqualToAnchor:self.providerLabel.bottomAnchor constant:3],
            [self.messagesLabel.leadingAnchor constraintEqualToAnchor:self.emailLabel.leadingAnchor],

            [self.dateLabel.topAnchor constraintEqualToAnchor:self.providerLabel.bottomAnchor constant:3],
            [self.dateLabel.leadingAnchor constraintEqualToAnchor:self.messagesLabel.trailingAnchor constant:8],

            [self.chevron.trailingAnchor constraintEqualToAnchor:self.contentView.trailingAnchor constant:-16],
            [self.chevron.centerYAnchor constraintEqualToAnchor:self.contentView.centerYAnchor]
        ]];
    }
    return self;
}

- (void)configureWithAccount:(NSDictionary *)account selected:(BOOL)selected {
    NSString *email = [[GMLAccountStore shared] stringValue:account[@"email"] fallback:@"(sans email)"];
    NSString *provider = [[GMLAccountStore shared] stringValue:account[@"provider_label"] fallback:[[GMLAccountStore shared] stringValue:account[@"provider"] fallback:@"?"]];
    NSString *status = [[GMLAccountStore shared] stringValue:account[@"status"] fallback:@""];
    NSInteger messages = [account[@"messages_count"] integerValue];
    NSString *created = [[GMLAccountStore shared] stringValue:account[@"created_at"] fallback:@""];

    self.emailLabel.text = email;
    self.providerLabel.text = provider;
    self.messagesLabel.text = messages > 0 ? [NSString stringWithFormat:@"%ld msg", (long)messages] : @"0 msg";

    if (created.length >= 10) {
        self.dateLabel.text = [created substringToIndex:10];
    } else {
        self.dateLabel.text = @"";
    }

    NSString *initial = email.length > 0 ? [[email substringToIndex:1] uppercaseString] : @"?";
    self.avatarLabel.text = initial;
    self.avatarView.backgroundColor = [self colorForProvider:provider];

    if ([status isEqualToString:@"ok"]) {
        self.statusBadge.text = @" OK ";
        self.statusBadge.textColor = [UIColor colorWithRed:0.20 green:0.80 blue:0.40 alpha:1.0];
        self.statusBadge.backgroundColor = [UIColor colorWithRed:0.10 green:0.25 blue:0.15 alpha:1.0];
    } else if ([status isEqualToString:@"error"] || [status isEqualToString:@"fail"]) {
        self.statusBadge.text = @" ERR ";
        self.statusBadge.textColor = [UIColor colorWithRed:0.95 green:0.35 blue:0.35 alpha:1.0];
        self.statusBadge.backgroundColor = [UIColor colorWithRed:0.25 green:0.10 blue:0.10 alpha:1.0];
    } else {
        self.statusBadge.text = [NSString stringWithFormat:@" %@ ", status.length ? [status uppercaseString] : @"\u2014"];
        self.statusBadge.textColor = [GMLThemeManager tertiaryTextColor];
        self.statusBadge.backgroundColor = [GMLThemeManager badgeBackgroundColor];
    }

    if (selected) {
        self.contentView.backgroundColor = [UIColor colorWithRed:0.10 green:0.15 blue:0.25 alpha:1.0];
        self.tintColor = [GMLThemeManager accentTextColor];
    } else {
        self.contentView.backgroundColor = [GMLThemeManager cellBackgroundColor];
    }
}

- (UIColor *)colorForProvider:(NSString *)provider {
    NSString *lower = [provider lowercaseString];
    if ([lower containsString:@"tempemail"]) return [UIColor colorWithRed:0.20 green:0.50 blue:0.85 alpha:1.0];
    if ([lower containsString:@"mail.tm"]) return [UIColor colorWithRed:0.55 green:0.30 blue:0.85 alpha:1.0];
    if ([lower containsString:@"guerr"]) return [UIColor colorWithRed:0.85 green:0.45 blue:0.20 alpha:1.0];
    return [UIColor colorWithRed:0.30 green:0.60 blue:0.50 alpha:1.0];
}

@end

#pragma mark - GMLAccountDetailViewController

@interface GMLAccountDetailViewController ()
@property (nonatomic, strong) UIScrollView *scrollView;
@end

@implementation GMLAccountDetailViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [GMLThemeManager backgroundColor];
    self.title = @"Detail";

    UIBarButtonItem *closeBtn = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(closeTapped)];
    self.navigationItem.rightBarButtonItem = closeBtn;

    self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectZero];
    self.scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    self.scrollView.alwaysBounceVertical = YES;
    [self.view addSubview:self.scrollView];

    UIView *content = [[UIView alloc] initWithFrame:CGRectZero];
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [self.scrollView addSubview:content];

    [NSLayoutConstraint activateConstraints:@[
        [self.scrollView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [self.scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.scrollView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],
        [content.topAnchor constraintEqualToAnchor:self.scrollView.topAnchor],
        [content.leadingAnchor constraintEqualToAnchor:self.scrollView.leadingAnchor],
        [content.trailingAnchor constraintEqualToAnchor:self.scrollView.trailingAnchor],
        [content.bottomAnchor constraintEqualToAnchor:self.scrollView.bottomAnchor],
        [content.widthAnchor constraintEqualToAnchor:self.scrollView.widthAnchor]
    ]];

    NSString *email = [[GMLAccountStore shared] stringValue:self.account[@"email"] fallback:@"?"];
    NSString *password = [[GMLAccountStore shared] stringValue:self.account[@"password"] fallback:@""];
    NSString *provider = [[GMLAccountStore shared] stringValue:self.account[@"provider_label"] fallback:[[GMLAccountStore shared] stringValue:self.account[@"provider"] fallback:@"?"]];
    NSString *status = [[GMLAccountStore shared] stringValue:self.account[@"status"] fallback:@""];
    NSString *token = [[GMLAccountStore shared] stringValue:self.account[@"token"] fallback:@""];
    NSString *accountId = [[GMLAccountStore shared] stringValue:self.account[@"id"] fallback:@""];
    NSString *created = [[GMLAccountStore shared] stringValue:self.account[@"created_at"] fallback:@""];
    NSInteger messages = [self.account[@"messages_count"] integerValue];

    // Avatar header
    UIView *avatarView = [[UIView alloc] initWithFrame:CGRectZero];
    avatarView.translatesAutoresizingMaskIntoConstraints = NO;
    avatarView.layer.cornerRadius = 36;
    avatarView.clipsToBounds = YES;
    NSString *lower = [provider lowercaseString];
    if ([lower containsString:@"tempemail"]) avatarView.backgroundColor = [UIColor colorWithRed:0.20 green:0.50 blue:0.85 alpha:1.0];
    else if ([lower containsString:@"mail.tm"]) avatarView.backgroundColor = [UIColor colorWithRed:0.55 green:0.30 blue:0.85 alpha:1.0];
    else avatarView.backgroundColor = [UIColor colorWithRed:0.30 green:0.60 blue:0.50 alpha:1.0];
    [content addSubview:avatarView];

    UILabel *avatarLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    avatarLabel.translatesAutoresizingMaskIntoConstraints = NO;
    avatarLabel.font = [UIFont systemFontOfSize:28 weight:UIFontWeightBold];
    avatarLabel.textColor = [UIColor whiteColor];
    avatarLabel.textAlignment = NSTextAlignmentCenter;
    avatarLabel.text = email.length > 0 ? [[email substringToIndex:1] uppercaseString] : @"?";
    [avatarView addSubview:avatarLabel];

    UILabel *emailHeaderLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    emailHeaderLabel.translatesAutoresizingMaskIntoConstraints = NO;
    emailHeaderLabel.text = email;
    emailHeaderLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightBold];
    emailHeaderLabel.textColor = [GMLThemeManager primaryTextColor];
    emailHeaderLabel.textAlignment = NSTextAlignmentCenter;
    emailHeaderLabel.numberOfLines = 0;
    [content addSubview:emailHeaderLabel];

    UILabel *providerHeaderLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    providerHeaderLabel.translatesAutoresizingMaskIntoConstraints = NO;
    providerHeaderLabel.text = provider;
    providerHeaderLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    providerHeaderLabel.textColor = [GMLThemeManager tertiaryTextColor];
    providerHeaderLabel.textAlignment = NSTextAlignmentCenter;
    [content addSubview:providerHeaderLabel];

    // Info card
    GMLCardView *infoCard = [GMLCardView card];
    [content addSubview:infoCard];

    NSArray *fields = @[
        @[@"envelope", @"Email", email],
        @[@"lock", @"Mot de passe", password.length ? password : @"(aucun)"],
        @[@"checkmark.seal", @"Statut", status.length ? [status uppercaseString] : @"\u2014"],
        @[@"number", @"Messages", [NSString stringWithFormat:@"%ld", (long)messages]],
        @[@"calendar", @"Cree le", created.length ? created : @"\u2014"],
        @[@"key", @"Token", token.length ? [[GMLAccountStore shared] compactString:token limit:30] : @"(aucun)"],
        @[@"person.text.rectangle", @"ID", accountId.length ? [[GMLAccountStore shared] compactString:accountId limit:30] : @"\u2014"]
    ];

    UIView *previousRow = nil;
    for (NSArray *field in fields) {
        UIView *row = [self fieldRowWithIcon:field[0] label:field[1] value:field[2]];
        [infoCard addSubview:row];
        [NSLayoutConstraint activateConstraints:@[
            [row.leadingAnchor constraintEqualToAnchor:infoCard.leadingAnchor constant:16],
            [row.trailingAnchor constraintEqualToAnchor:infoCard.trailingAnchor constant:-16]
        ]];
        if (previousRow) {
            UIView *sep = [[UIView alloc] initWithFrame:CGRectZero];
            sep.translatesAutoresizingMaskIntoConstraints = NO;
            sep.backgroundColor = [GMLThemeManager cardBorderColor];
            [infoCard addSubview:sep];
            [NSLayoutConstraint activateConstraints:@[
                [sep.topAnchor constraintEqualToAnchor:previousRow.bottomAnchor],
                [sep.leadingAnchor constraintEqualToAnchor:infoCard.leadingAnchor constant:16],
                [sep.trailingAnchor constraintEqualToAnchor:infoCard.trailingAnchor constant:-16],
                [sep.heightAnchor constraintEqualToConstant:0.5],
                [row.topAnchor constraintEqualToAnchor:sep.bottomAnchor]
            ]];
        } else {
            [row.topAnchor constraintEqualToAnchor:infoCard.topAnchor constant:4].active = YES;
        }
        previousRow = row;
    }
    [previousRow.bottomAnchor constraintEqualToAnchor:infoCard.bottomAnchor constant:-4].active = YES;

    // Action buttons
    UIButton *copyEmailBtn = [self actionButtonWithIcon:@"doc.on.doc" title:@"Copier email" color:[UIColor colorWithRed:0.19 green:0.43 blue:0.83 alpha:1.0]];
    [copyEmailBtn addTarget:self action:@selector(copyEmail) forControlEvents:UIControlEventTouchUpInside];

    UIButton *copyPassBtn = [self actionButtonWithIcon:@"lock.doc" title:@"Copier mdp" color:[UIColor colorWithRed:0.55 green:0.30 blue:0.85 alpha:1.0]];
    [copyPassBtn addTarget:self action:@selector(copyPassword) forControlEvents:UIControlEventTouchUpInside];

    UIButton *copyComboBtn = [self actionButtonWithIcon:@"rectangle.on.rectangle" title:@"Copier email:mdp" color:[UIColor colorWithRed:0.30 green:0.60 blue:0.50 alpha:1.0]];
    [copyComboBtn addTarget:self action:@selector(copyCombo) forControlEvents:UIControlEventTouchUpInside];

    UIButton *deleteBtn = [self actionButtonWithIcon:@"trash" title:@"Supprimer" color:[UIColor colorWithRed:0.85 green:0.25 blue:0.25 alpha:1.0]];
    [deleteBtn addTarget:self action:@selector(deleteAccount) forControlEvents:UIControlEventTouchUpInside];

    UIButton *inboxBtn = [self actionButtonWithIcon:@"envelope.open" title:@"Voir messages" color:[UIColor colorWithRed:0.20 green:0.60 blue:0.85 alpha:1.0]];
    [inboxBtn addTarget:self action:@selector(viewInbox) forControlEvents:UIControlEventTouchUpInside];
    BOOL hasToken = [[GMLAccountStore shared] stringValue:self.account[@"token"] fallback:@""].length > 0;
    inboxBtn.enabled = hasToken;
    inboxBtn.alpha = hasToken ? 1.0 : 0.4;

    UIStackView *row0 = [[UIStackView alloc] initWithArrangedSubviews:@[inboxBtn]];
    row0.translatesAutoresizingMaskIntoConstraints = NO;
    row0.axis = UILayoutConstraintAxisHorizontal;
    row0.distribution = UIStackViewDistributionFillEqually;
    [content addSubview:row0];

    UIStackView *row1 = [[UIStackView alloc] initWithArrangedSubviews:@[copyEmailBtn, copyPassBtn]];
    row1.translatesAutoresizingMaskIntoConstraints = NO;
    row1.axis = UILayoutConstraintAxisHorizontal;
    row1.distribution = UIStackViewDistributionFillEqually;
    row1.spacing = 10;
    [content addSubview:row1];

    UIStackView *row2 = [[UIStackView alloc] initWithArrangedSubviews:@[copyComboBtn, deleteBtn]];
    row2.translatesAutoresizingMaskIntoConstraints = NO;
    row2.axis = UILayoutConstraintAxisHorizontal;
    row2.distribution = UIStackViewDistributionFillEqually;
    row2.spacing = 10;
    [content addSubview:row2];

    [NSLayoutConstraint activateConstraints:@[
        [avatarView.topAnchor constraintEqualToAnchor:content.topAnchor constant:24],
        [avatarView.centerXAnchor constraintEqualToAnchor:content.centerXAnchor],
        [avatarView.widthAnchor constraintEqualToConstant:72],
        [avatarView.heightAnchor constraintEqualToConstant:72],
        [avatarLabel.centerXAnchor constraintEqualToAnchor:avatarView.centerXAnchor],
        [avatarLabel.centerYAnchor constraintEqualToAnchor:avatarView.centerYAnchor],

        [emailHeaderLabel.topAnchor constraintEqualToAnchor:avatarView.bottomAnchor constant:12],
        [emailHeaderLabel.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:20],
        [emailHeaderLabel.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-20],

        [providerHeaderLabel.topAnchor constraintEqualToAnchor:emailHeaderLabel.bottomAnchor constant:4],
        [providerHeaderLabel.centerXAnchor constraintEqualToAnchor:content.centerXAnchor],

        [infoCard.topAnchor constraintEqualToAnchor:providerHeaderLabel.bottomAnchor constant:20],
        [infoCard.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:16],
        [infoCard.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-16],

        [row0.topAnchor constraintEqualToAnchor:infoCard.bottomAnchor constant:16],
        [row0.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:16],
        [row0.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-16],

        [row1.topAnchor constraintEqualToAnchor:row0.bottomAnchor constant:10],
        [row1.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:16],
        [row1.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-16],

        [row2.topAnchor constraintEqualToAnchor:row1.bottomAnchor constant:10],
        [row2.leadingAnchor constraintEqualToAnchor:content.leadingAnchor constant:16],
        [row2.trailingAnchor constraintEqualToAnchor:content.trailingAnchor constant:-16],
        [row2.bottomAnchor constraintEqualToAnchor:content.bottomAnchor constant:-30]
    ]];
}

- (UIView *)fieldRowWithIcon:(NSString *)iconName label:(NSString *)label value:(NSString *)value {
    UIView *row = [[UIView alloc] initWithFrame:CGRectZero];
    row.translatesAutoresizingMaskIntoConstraints = NO;

    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:14 weight:UIImageSymbolWeightMedium];
    UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:iconName withConfiguration:cfg]];
    icon.translatesAutoresizingMaskIntoConstraints = NO;
    icon.tintColor = [GMLThemeManager accentTextColor];
    [row addSubview:icon];

    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = label;
    titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
    titleLabel.textColor = [GMLThemeManager tertiaryTextColor];
    [row addSubview:titleLabel];

    UILabel *valueLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    valueLabel.translatesAutoresizingMaskIntoConstraints = NO;
    valueLabel.text = value;
    valueLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    valueLabel.textColor = [GMLThemeManager primaryTextColor];
    valueLabel.textAlignment = NSTextAlignmentRight;
    valueLabel.lineBreakMode = NSLineBreakByTruncatingMiddle;
    [row addSubview:valueLabel];

    [NSLayoutConstraint activateConstraints:@[
        [row.heightAnchor constraintEqualToConstant:44],
        [icon.leadingAnchor constraintEqualToAnchor:row.leadingAnchor],
        [icon.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
        [icon.widthAnchor constraintEqualToConstant:20],
        [titleLabel.leadingAnchor constraintEqualToAnchor:icon.trailingAnchor constant:10],
        [titleLabel.centerYAnchor constraintEqualToAnchor:row.centerYAnchor],
        [titleLabel.widthAnchor constraintEqualToConstant:90],
        [valueLabel.leadingAnchor constraintEqualToAnchor:titleLabel.trailingAnchor constant:8],
        [valueLabel.trailingAnchor constraintEqualToAnchor:row.trailingAnchor],
        [valueLabel.centerYAnchor constraintEqualToAnchor:row.centerYAnchor]
    ]];

    return row;
}

- (UIButton *)actionButtonWithIcon:(NSString *)icon title:(NSString *)title color:(UIColor *)color {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:14 weight:UIImageSymbolWeightSemibold];
    [button setImage:[[UIImage systemImageNamed:icon withConfiguration:cfg] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    [button setTitle:[NSString stringWithFormat:@" %@", title] forState:UIControlStateNormal];
    button.tintColor = [UIColor whiteColor];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    button.backgroundColor = color;
    button.layer.cornerRadius = [GMLThemeManager buttonCornerRadius];
    [button.heightAnchor constraintEqualToConstant:44].active = YES;
    return button;
}

- (void)closeTapped {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)viewInbox {
    [self flashHaptic];
    GMLInboxViewController *inboxVC = [[GMLInboxViewController alloc] init];
    inboxVC.focusAccount = self.account;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:inboxVC];
    nav.navigationBar.prefersLargeTitles = NO;
    nav.modalPresentationStyle = UIModalPresentationPageSheet;
    #pragma clang diagnostic push
    #pragma clang diagnostic ignored "-Wunguarded-availability-new"
    if ([nav respondsToSelector:@selector(sheetPresentationController)]) {
        UISheetPresentationController *sheet = nav.sheetPresentationController;
        sheet.detents = @[UISheetPresentationControllerDetent.mediumDetent, UISheetPresentationControllerDetent.largeDetent];
        sheet.prefersGrabberVisible = YES;
        sheet.preferredCornerRadius = 20;
    }
    #pragma clang diagnostic pop
    inboxVC.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemClose target:inboxVC action:@selector(dismissSelf)];
    [self presentViewController:nav animated:YES completion:nil];
}

- (void)copyEmail {
    [UIPasteboard generalPasteboard].string = [[GMLAccountStore shared] stringValue:self.account[@"email"] fallback:@""];
    [self flashHaptic];
}

- (void)copyPassword {
    [UIPasteboard generalPasteboard].string = [[GMLAccountStore shared] stringValue:self.account[@"password"] fallback:@""];
    [self flashHaptic];
}

- (void)copyCombo {
    NSString *email = [[GMLAccountStore shared] stringValue:self.account[@"email"] fallback:@""];
    NSString *pass = [[GMLAccountStore shared] stringValue:self.account[@"password"] fallback:@""];
    [UIPasteboard generalPasteboard].string = [NSString stringWithFormat:@"%@:%@", email, pass];
    [self flashHaptic];
}

- (void)deleteAccount {
    NSString *email = [[GMLAccountStore shared] stringValue:self.account[@"email"] fallback:@""];
    [[GMLAccountStore shared] deleteAccountByEmail:email];
    UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleHeavy];
    [haptic impactOccurred];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)flashHaptic {
    UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [haptic impactOccurred];
}

@end

#pragma mark - GMLAccountsViewController

@interface GMLAccountsViewController ()
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UISearchBar *searchBar;
@property (nonatomic, strong) UISegmentedControl *filterControl;
@property (nonatomic, strong) UIView *statsCard;
@property (nonatomic, strong) UILabel *totalCountLabel;
@property (nonatomic, strong) UILabel *okCountLabel;
@property (nonatomic, strong) UILabel *errCountLabel;
@property (nonatomic, strong) NSArray *filteredAccounts;
@property (nonatomic, strong) NSDictionary *selectedAccount;
@property (nonatomic, strong) UILabel *emptyLabel;
@property (nonatomic, strong) UIRefreshControl *refreshControl;
@property (nonatomic, strong) NSString *activeProviderFilter;
@property (nonatomic, assign) BOOL selectionMode;
@property (nonatomic, strong) NSMutableSet *selectedIndices;
@property (nonatomic, strong) UIView *selectionToolbar;
@property (nonatomic, strong) UILabel *selectionCountLabel;
@property (nonatomic, strong) NSLayoutConstraint *toolbarBottomConstraint;
@end

@implementation GMLAccountsViewController

- (void)dealloc {
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [GMLThemeManager backgroundColor];
    self.accounts = [NSMutableArray array];
    self.filteredAccounts = @[];
    self.activeProviderFilter = @"";
    self.selectionMode = NO;
    self.selectedIndices = [NSMutableSet set];

    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(accountsDidChange) name:GMLAccountsDidChangeNotification object:nil];

    // Nav bar edit button
    UIBarButtonItem *editBtn = [[UIBarButtonItem alloc] initWithTitle:@"Selectionner" style:UIBarButtonItemStylePlain target:self action:@selector(toggleSelectionMode)];
    self.navigationItem.rightBarButtonItem = editBtn;

    // Stats card
    self.statsCard = [[UIView alloc] initWithFrame:CGRectZero];
    self.statsCard.translatesAutoresizingMaskIntoConstraints = NO;
    self.statsCard.backgroundColor = [GMLThemeManager cardBackgroundColor];
    self.statsCard.layer.cornerRadius = 14;
    self.statsCard.layer.borderWidth = 1;
    self.statsCard.layer.borderColor = [GMLThemeManager cardBorderColor].CGColor;
    [self.view addSubview:self.statsCard];

    self.totalCountLabel = [self statLabelWithTitle:@"Total"];
    self.okCountLabel = [self statLabelWithTitle:@"OK"];
    self.errCountLabel = [self statLabelWithTitle:@"Erreurs"];

    UIStackView *statsStack = [[UIStackView alloc] initWithArrangedSubviews:@[self.totalCountLabel, self.okCountLabel, self.errCountLabel]];
    statsStack.translatesAutoresizingMaskIntoConstraints = NO;
    statsStack.axis = UILayoutConstraintAxisHorizontal;
    statsStack.distribution = UIStackViewDistributionFillEqually;
    statsStack.spacing = 0;
    [self.statsCard addSubview:statsStack];

    [NSLayoutConstraint activateConstraints:@[
        [statsStack.topAnchor constraintEqualToAnchor:self.statsCard.topAnchor constant:12],
        [statsStack.bottomAnchor constraintEqualToAnchor:self.statsCard.bottomAnchor constant:-12],
        [statsStack.leadingAnchor constraintEqualToAnchor:self.statsCard.leadingAnchor constant:8],
        [statsStack.trailingAnchor constraintEqualToAnchor:self.statsCard.trailingAnchor constant:-8]
    ]];

    // Provider filter
    NSDictionary *providers = [[GMLAccountStore shared] providers];
    NSMutableArray *items = [NSMutableArray arrayWithObject:@"Tous"];
    for (NSString *key in providers) {
        [items addObject:[[GMLAccountStore shared] stringValue:providers[key][@"label"] fallback:key]];
    }
    self.filterControl = [[UISegmentedControl alloc] initWithItems:items];
    self.filterControl.translatesAutoresizingMaskIntoConstraints = NO;
    self.filterControl.selectedSegmentIndex = 0;
    [self.filterControl addTarget:self action:@selector(filterChanged) forControlEvents:UIControlEventValueChanged];
    self.filterControl.backgroundColor = [GMLThemeManager inputBackgroundColor];
    NSDictionary *normalAttrs = @{NSForegroundColorAttributeName: [GMLThemeManager tertiaryTextColor], NSFontAttributeName: [UIFont systemFontOfSize:13 weight:UIFontWeightMedium]};
    NSDictionary *selectedAttrs = @{NSForegroundColorAttributeName: [GMLThemeManager primaryTextColor], NSFontAttributeName: [UIFont systemFontOfSize:13 weight:UIFontWeightBold]};
    [self.filterControl setTitleTextAttributes:normalAttrs forState:UIControlStateNormal];
    [self.filterControl setTitleTextAttributes:selectedAttrs forState:UIControlStateSelected];
    [self.view addSubview:self.filterControl];

    // Search bar
    self.searchBar = [[UISearchBar alloc] initWithFrame:CGRectZero];
    self.searchBar.translatesAutoresizingMaskIntoConstraints = NO;
    self.searchBar.placeholder = @"Rechercher un compte...";
    self.searchBar.delegate = self;
    self.searchBar.barTintColor = [GMLThemeManager backgroundColor];
    self.searchBar.searchBarStyle = UISearchBarStyleMinimal;
    UITextField *searchField = [self.searchBar valueForKey:@"searchField"];
    if (searchField) {
        searchField.textColor = [GMLThemeManager primaryTextColor];
        searchField.backgroundColor = [GMLThemeManager inputBackgroundColor];
    }
    [self.view addSubview:self.searchBar];

    // Table
    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStylePlain];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [GMLThemeManager backgroundColor];
    self.tableView.separatorColor = [GMLThemeManager cardBorderColor];
    self.tableView.rowHeight = 76;
    self.tableView.keyboardDismissMode = UIScrollViewKeyboardDismissModeOnDrag;
    [self.tableView registerClass:[GMLAccountCell class] forCellReuseIdentifier:@"AccountCell"];
    [self.view addSubview:self.tableView];

    self.refreshControl = [[UIRefreshControl alloc] init];
    self.refreshControl.tintColor = [GMLThemeManager accentTextColor];
    [self.refreshControl addTarget:self action:@selector(pullToRefresh) forControlEvents:UIControlEventValueChanged];
    self.tableView.refreshControl = self.refreshControl;

    // Empty state
    self.emptyLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.emptyLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.emptyLabel.text = @"Aucun compte.\nGenerez des comptes depuis l'onglet Studio.";
    self.emptyLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    self.emptyLabel.textColor = [GMLThemeManager tertiaryTextColor];
    self.emptyLabel.textAlignment = NSTextAlignmentCenter;
    self.emptyLabel.numberOfLines = 0;
    [self.view addSubview:self.emptyLabel];

    // Selection toolbar (hidden off-screen, slides up when active)
    self.selectionToolbar = [[UIView alloc] initWithFrame:CGRectZero];
    self.selectionToolbar.translatesAutoresizingMaskIntoConstraints = NO;
    self.selectionToolbar.backgroundColor = [GMLThemeManager cardBackgroundColor];
    self.selectionToolbar.layer.borderWidth = 1;
    self.selectionToolbar.layer.borderColor = [GMLThemeManager cardBorderColor].CGColor;
    [self.view addSubview:self.selectionToolbar];

    self.selectionCountLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.selectionCountLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.selectionCountLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightBold];
    self.selectionCountLabel.textColor = [GMLThemeManager accentTextColor];
    self.selectionCountLabel.text = @"0 selectionne(s)";

    UIImageSymbolConfiguration *tbCfg = [UIImageSymbolConfiguration configurationWithPointSize:13 weight:UIImageSymbolWeightSemibold];

    UIButton *selectAllBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [selectAllBtn setImage:[[UIImage systemImageNamed:@"checkmark.circle.fill" withConfiguration:tbCfg] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    [selectAllBtn setTitle:@" Tout" forState:UIControlStateNormal];
    selectAllBtn.tintColor = [GMLThemeManager accentTextColor];
    [selectAllBtn setTitleColor:[GMLThemeManager accentTextColor] forState:UIControlStateNormal];
    selectAllBtn.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    [selectAllBtn addTarget:self action:@selector(selectAll) forControlEvents:UIControlEventTouchUpInside];

    UIButton *copySelBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [copySelBtn setImage:[[UIImage systemImageNamed:@"doc.on.doc" withConfiguration:tbCfg] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    [copySelBtn setTitle:@" Copier" forState:UIControlStateNormal];
    copySelBtn.tintColor = [UIColor colorWithRed:0.19 green:0.43 blue:0.83 alpha:1.0];
    [copySelBtn setTitleColor:[UIColor colorWithRed:0.19 green:0.43 blue:0.83 alpha:1.0] forState:UIControlStateNormal];
    copySelBtn.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    [copySelBtn addTarget:self action:@selector(copySelected) forControlEvents:UIControlEventTouchUpInside];

    UIButton *deleteSelBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [deleteSelBtn setImage:[[UIImage systemImageNamed:@"trash" withConfiguration:tbCfg] imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    [deleteSelBtn setTitle:@" Suppr" forState:UIControlStateNormal];
    deleteSelBtn.tintColor = [UIColor colorWithRed:0.85 green:0.25 blue:0.25 alpha:1.0];
    [deleteSelBtn setTitleColor:[UIColor colorWithRed:0.85 green:0.25 blue:0.25 alpha:1.0] forState:UIControlStateNormal];
    deleteSelBtn.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    [deleteSelBtn addTarget:self action:@selector(deleteSelected) forControlEvents:UIControlEventTouchUpInside];

    UIStackView *toolbarStack = [[UIStackView alloc] initWithArrangedSubviews:@[self.selectionCountLabel, selectAllBtn, copySelBtn, deleteSelBtn]];
    toolbarStack.translatesAutoresizingMaskIntoConstraints = NO;
    toolbarStack.axis = UILayoutConstraintAxisHorizontal;
    toolbarStack.distribution = UIStackViewDistributionEqualSpacing;
    toolbarStack.alignment = UIStackViewAlignmentCenter;
    [self.selectionToolbar addSubview:toolbarStack];

    self.toolbarBottomConstraint = [self.selectionToolbar.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor constant:60];

    [NSLayoutConstraint activateConstraints:@[
        [self.statsCard.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:8],
        [self.statsCard.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [self.statsCard.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],

        [self.filterControl.topAnchor constraintEqualToAnchor:self.statsCard.bottomAnchor constant:10],
        [self.filterControl.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:16],
        [self.filterControl.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-16],
        [self.filterControl.heightAnchor constraintEqualToConstant:32],

        [self.searchBar.topAnchor constraintEqualToAnchor:self.filterControl.bottomAnchor constant:6],
        [self.searchBar.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:8],
        [self.searchBar.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-8],

        [self.tableView.topAnchor constraintEqualToAnchor:self.searchBar.bottomAnchor constant:4],
        [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.tableView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],

        [self.emptyLabel.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [self.emptyLabel.centerYAnchor constraintEqualToAnchor:self.view.centerYAnchor],
        [self.emptyLabel.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor constant:40],
        [self.emptyLabel.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor constant:-40],

        [self.selectionToolbar.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.selectionToolbar.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.selectionToolbar.heightAnchor constraintEqualToConstant:56],
        self.toolbarBottomConstraint,

        [toolbarStack.topAnchor constraintEqualToAnchor:self.selectionToolbar.topAnchor constant:8],
        [toolbarStack.bottomAnchor constraintEqualToAnchor:self.selectionToolbar.bottomAnchor constant:-8],
        [toolbarStack.leadingAnchor constraintEqualToAnchor:self.selectionToolbar.leadingAnchor constant:16],
        [toolbarStack.trailingAnchor constraintEqualToAnchor:self.selectionToolbar.trailingAnchor constant:-16]
    ]];

    [self reloadAccounts];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    [self reloadAccounts];
    [[GMLAccountStore shared] refreshAllMessageCounts];
}

- (UILabel *)statLabelWithTitle:(NSString *)title {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.numberOfLines = 2;
    label.textAlignment = NSTextAlignmentCenter;
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc]
        initWithString:@"0\n"
        attributes:@{
            NSFontAttributeName: [UIFont monospacedDigitSystemFontOfSize:22 weight:UIFontWeightBold],
            NSForegroundColorAttributeName: [GMLThemeManager primaryTextColor]
        }];
    [attr appendAttributedString:[[NSAttributedString alloc]
        initWithString:title
        attributes:@{
            NSFontAttributeName: [UIFont systemFontOfSize:11 weight:UIFontWeightMedium],
            NSForegroundColorAttributeName: [GMLThemeManager tertiaryTextColor]
        }]];
    label.attributedText = attr;
    return label;
}

- (void)updateStatLabel:(UILabel *)label count:(NSInteger)count title:(NSString *)title color:(UIColor *)color {
    NSMutableAttributedString *attr = [[NSMutableAttributedString alloc]
        initWithString:[NSString stringWithFormat:@"%ld\n", (long)count]
        attributes:@{
            NSFontAttributeName: [UIFont monospacedDigitSystemFontOfSize:22 weight:UIFontWeightBold],
            NSForegroundColorAttributeName: color
        }];
    [attr appendAttributedString:[[NSAttributedString alloc]
        initWithString:title
        attributes:@{
            NSFontAttributeName: [UIFont systemFontOfSize:11 weight:UIFontWeightMedium],
            NSForegroundColorAttributeName: [GMLThemeManager tertiaryTextColor]
        }]];
    label.attributedText = attr;
}

- (void)accountsDidChange {
    [self reloadAccounts];
}

- (void)reloadAccounts {
    NSArray *all = [[GMLAccountStore shared] loadAccounts];
    [self.accounts removeAllObjects];
    [self.accounts addObjectsFromArray:all];
    [self updateStats];
    [self applyFilter];
}

- (void)updateStats {
    NSInteger total = self.accounts.count;
    NSInteger ok = 0, err = 0;
    for (NSDictionary *a in self.accounts) {
        NSString *s = [[GMLAccountStore shared] stringValue:a[@"status"] fallback:@""];
        if ([s isEqualToString:@"ok"]) ok++;
        else if ([s isEqualToString:@"error"] || [s isEqualToString:@"fail"]) err++;
    }
    [self updateStatLabel:self.totalCountLabel count:total title:@"Total" color:[GMLThemeManager accentTextColor]];
    [self updateStatLabel:self.okCountLabel count:ok title:@"OK" color:[UIColor colorWithRed:0.20 green:0.80 blue:0.40 alpha:1.0]];
    [self updateStatLabel:self.errCountLabel count:err title:@"Erreurs" color:[UIColor colorWithRed:0.95 green:0.35 blue:0.35 alpha:1.0]];

    self.title = [NSString stringWithFormat:@"Comptes (%ld)", (long)total];
}

- (void)applyFilter {
    NSMutableArray *result = [NSMutableArray array];
    NSString *query = self.searchBar.text;
    NSString *providerFilter = self.activeProviderFilter ?: @"";

    for (NSDictionary *item in self.accounts) {
        if (providerFilter.length > 0) {
            NSString *label = [[GMLAccountStore shared] stringValue:item[@"provider_label"] fallback:@""];
            if (![[label lowercaseString] containsString:[providerFilter lowercaseString]]) continue;
        }
        if (query.length > 0) {
            NSString *lower = [query lowercaseString];
            NSString *email = [[GMLAccountStore shared] stringValue:item[@"email"] fallback:@""];
            NSString *provider = [[GMLAccountStore shared] stringValue:item[@"provider_label"] fallback:@""];
            if (![[email lowercaseString] containsString:lower] && ![[provider lowercaseString] containsString:lower]) continue;
        }
        [result addObject:item];
    }

    self.filteredAccounts = result;
    self.emptyLabel.hidden = self.filteredAccounts.count > 0;
    self.tableView.hidden = self.filteredAccounts.count == 0;
    [self.tableView reloadData];
}

- (void)filterChanged {
    NSInteger idx = self.filterControl.selectedSegmentIndex;
    if (idx == 0) {
        self.activeProviderFilter = @"";
    } else {
        NSString *title = [self.filterControl titleForSegmentAtIndex:idx];
        self.activeProviderFilter = title ?: @"";
    }
    [self applyFilter];
}

- (void)pullToRefresh {
    [self reloadAccounts];
    [self.refreshControl endRefreshing];
}

#pragma mark - UISearchBarDelegate

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText {
    [self applyFilter];
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar {
    [searchBar resignFirstResponder];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.filteredAccounts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    GMLAccountCell *cell = [tableView dequeueReusableCellWithIdentifier:@"AccountCell" forIndexPath:indexPath];
    NSDictionary *account = self.filteredAccounts[indexPath.row];
    BOOL isSelected = self.selectionMode && [self.selectedIndices containsObject:@(indexPath.row)];
    [cell configureWithAccount:account selected:isSelected];

    if (self.selectionMode) {
        UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:20 weight:UIImageSymbolWeightMedium];
        NSString *imgName = isSelected ? @"checkmark.circle.fill" : @"circle";
        UIImageView *checkView = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:imgName withConfiguration:cfg]];
        checkView.tintColor = isSelected ? [GMLThemeManager accentTextColor] : [GMLThemeManager tertiaryTextColor];
        cell.accessoryView = checkView;
    } else {
        cell.accessoryView = nil;
    }

    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (self.selectionMode) {
        NSNumber *idx = @(indexPath.row);
        if ([self.selectedIndices containsObject:idx]) {
            [self.selectedIndices removeObject:idx];
        } else {
            [self.selectedIndices addObject:idx];
        }
        [self updateSelectionCount];
        [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
        return;
    }

    NSDictionary *account = self.filteredAccounts[indexPath.row];
    UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [haptic impactOccurred];

    GMLAccountDetailViewController *detail = [[GMLAccountDetailViewController alloc] init];
    detail.account = account;
    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:detail];

    UINavigationBarAppearance *appearance = [[UINavigationBarAppearance alloc] init];
    [appearance configureWithOpaqueBackground];
    appearance.backgroundColor = [GMLThemeManager navBarBackgroundColor];
    appearance.titleTextAttributes = @{ NSForegroundColorAttributeName: [GMLThemeManager primaryTextColor] };
    nav.navigationBar.standardAppearance = appearance;
    nav.navigationBar.scrollEdgeAppearance = appearance;
    nav.navigationBar.tintColor = [GMLThemeManager navBarTintColor];

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability-new"
    if ([nav respondsToSelector:@selector(setSheetPresentationController:)] || [self respondsToSelector:@selector(sheetPresentationController)]) {
        if ([nav respondsToSelector:@selector(sheetPresentationController)]) {
            UISheetPresentationController *sheet = nav.sheetPresentationController;
            if (sheet) {
                sheet.detents = @[[UISheetPresentationControllerDetent mediumDetent], [UISheetPresentationControllerDetent largeDetent]];
                sheet.prefersGrabberVisible = YES;
                sheet.preferredCornerRadius = 20;
            }
        }
    }
#pragma clang diagnostic pop

    [self presentViewController:nav animated:YES completion:nil];
}

- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView trailingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *account = self.filteredAccounts[indexPath.row];

    UIContextualAction *deleteAction = [UIContextualAction contextualActionWithStyle:UIContextualActionStyleDestructive title:@"Suppr" handler:^(UIContextualAction *action, UIView *sourceView, void (^completionHandler)(BOOL)) {
        NSString *email = [[GMLAccountStore shared] stringValue:account[@"email"] fallback:@""];
        [[GMLAccountStore shared] deleteAccountByEmail:email];
        [self reloadAccounts];
        completionHandler(YES);
    }];
    deleteAction.image = [UIImage systemImageNamed:@"trash"];

    return [UISwipeActionsConfiguration configurationWithActions:@[deleteAction]];
}

- (UISwipeActionsConfiguration *)tableView:(UITableView *)tableView leadingSwipeActionsConfigurationForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *account = self.filteredAccounts[indexPath.row];

    UIContextualAction *copyAction = [UIContextualAction contextualActionWithStyle:UIContextualActionStyleNormal title:@"Copier" handler:^(UIContextualAction *action, UIView *sourceView, void (^completionHandler)(BOOL)) {
        NSString *email = [[GMLAccountStore shared] stringValue:account[@"email"] fallback:@""];
        NSString *password = [[GMLAccountStore shared] stringValue:account[@"password"] fallback:@""];
        NSString *line = [NSString stringWithFormat:@"%@:%@", email, password];
        [UIPasteboard generalPasteboard].string = line;
        UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
        [haptic impactOccurred];
        completionHandler(YES);
    }];
    copyAction.image = [UIImage systemImageNamed:@"doc.on.doc"];
    copyAction.backgroundColor = [UIColor colorWithRed:0.19 green:0.43 blue:0.83 alpha:1.0];

    return [UISwipeActionsConfiguration configurationWithActions:@[copyAction]];
}

#pragma mark - Multi-selection

- (void)toggleSelectionMode {
    self.selectionMode = !self.selectionMode;
    [self.selectedIndices removeAllObjects];

    if (self.selectionMode) {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Annuler" style:UIBarButtonItemStyleDone target:self action:@selector(toggleSelectionMode)];
        self.tableView.allowsMultipleSelection = YES;
        self.toolbarBottomConstraint.constant = 0;
    } else {
        self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"Selectionner" style:UIBarButtonItemStylePlain target:self action:@selector(toggleSelectionMode)];
        self.tableView.allowsMultipleSelection = NO;
        self.toolbarBottomConstraint.constant = 60;
    }

    [UIView animateWithDuration:0.3 delay:0 usingSpringWithDamping:0.85 initialSpringVelocity:0.5 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        [self.view layoutIfNeeded];
    } completion:nil];

    [self updateSelectionCount];
    [self.tableView reloadData];
}

- (void)updateSelectionCount {
    NSInteger count = self.selectedIndices.count;
    self.selectionCountLabel.text = [NSString stringWithFormat:@"%ld selectionne(s)", (long)count];
}

- (void)selectAll {
    if (self.selectedIndices.count == self.filteredAccounts.count) {
        [self.selectedIndices removeAllObjects];
    } else {
        [self.selectedIndices removeAllObjects];
        for (NSUInteger i = 0; i < self.filteredAccounts.count; i++) {
            [self.selectedIndices addObject:@(i)];
        }
    }
    [self updateSelectionCount];
    [self.tableView reloadData];
}

- (void)copySelected {
    if (self.selectedIndices.count == 0) return;
    NSMutableArray *lines = [NSMutableArray array];
    NSArray *sortedIndices = [[self.selectedIndices allObjects] sortedArrayUsingSelector:@selector(compare:)];
    for (NSNumber *idx in sortedIndices) {
        NSDictionary *account = self.filteredAccounts[[idx unsignedIntegerValue]];
        NSString *email = [[GMLAccountStore shared] stringValue:account[@"email"] fallback:@""];
        NSString *password = [[GMLAccountStore shared] stringValue:account[@"password"] fallback:@""];
        [lines addObject:[NSString stringWithFormat:@"%@:%@", email, password]];
    }
    [UIPasteboard generalPasteboard].string = [lines componentsJoinedByString:@"\n"];
    UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
    [haptic impactOccurred];
    [self toggleSelectionMode];
}

- (void)deleteSelected {
    if (self.selectedIndices.count == 0) return;

    NSString *msg = [NSString stringWithFormat:@"Supprimer %ld compte(s) ?", (long)self.selectedIndices.count];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Confirmation" message:msg preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Annuler" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Supprimer" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        NSArray *sortedIndices = [[self.selectedIndices allObjects] sortedArrayUsingComparator:^NSComparisonResult(NSNumber *a, NSNumber *b) {
            return [b compare:a]; // reverse order to delete from end first
        }];
        for (NSNumber *idx in sortedIndices) {
            NSDictionary *account = self.filteredAccounts[[idx unsignedIntegerValue]];
            NSString *email = [[GMLAccountStore shared] stringValue:account[@"email"] fallback:@""];
            [[GMLAccountStore shared] deleteAccountByEmail:email];
        }
        UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleHeavy];
        [haptic impactOccurred];
        [self toggleSelectionMode];
        [self reloadAccounts];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

@end
