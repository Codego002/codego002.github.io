#import <Foundation/Foundation.h>

extern NSNotificationName const GMLAccountsDidChangeNotification;

@interface GMLAccountStore : NSObject

+ (instancetype)shared;

@property (nonatomic, readonly) NSString *accountsPath;
@property (nonatomic, readonly) NSString *storageDirectory;

- (NSArray *)loadAccounts;
- (void)saveAccounts:(NSArray *)accounts;
- (NSArray *)accountsForProvider:(NSString *)provider;
- (void)upsertAccount:(NSMutableDictionary *)item inAccounts:(NSMutableArray *)accounts;
- (void)deleteAccountByEmail:(NSString *)email;
- (void)updateMessageCount:(NSInteger)count forEmail:(NSString *)email;
- (void)refreshAllMessageCounts;

- (NSString *)documentsPath:(NSString *)name;

- (NSDictionary *)providers;
- (NSDictionary *)providerConfig:(NSString *)provider;

- (NSString *)randomLocal:(NSInteger)length;
- (NSString *)randomPassword;
- (NSString *)uniqueEmailForProvider:(NSString *)provider
                              domain:(NSString *)domain
                              prefix:(NSString *)prefix
                            accounts:(NSArray *)accounts;

- (NSString *)jsonString:(id)obj;
- (NSString *)stringValue:(id)value fallback:(NSString *)fallback;
- (NSString *)compactString:(NSString *)value limit:(NSUInteger)limit;

@end
