#import "GMLNetworkManager.h"

@interface GMLNetworkManager ()
@property (nonatomic, strong) NSURLSession *session;
@end

@implementation GMLNetworkManager

+ (instancetype)shared {
    static GMLNetworkManager *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[GMLNetworkManager alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        NSURLSessionConfiguration *config = [NSURLSessionConfiguration defaultSessionConfiguration];
        config.timeoutIntervalForRequest = 20.0;
        config.timeoutIntervalForResource = 60.0;
        config.waitsForConnectivity = NO;
        _session = [NSURLSession sessionWithConfiguration:config];
    }
    return self;
}

- (void)log:(NSString *)message level:(NSString *)level {
    if (self.logBlock) self.logBlock(message, level);
}

- (NSString *)jsonString:(id)obj {
    if (!obj) return @"";
    if ([obj isKindOfClass:[NSString class]]) return obj;
    NSData *data = [NSJSONSerialization dataWithJSONObject:obj options:NSJSONWritingPrettyPrinted error:nil];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] ?: [obj description];
}

- (NSString *)stringValue:(id)value fallback:(NSString *)fallback {
    if ([value isKindOfClass:[NSString class]]) return value;
    if ([value respondsToSelector:@selector(stringValue)]) return [value stringValue];
    return fallback ?: @"";
}

- (NSString *)compactString:(NSString *)value limit:(NSUInteger)limit {
    NSString *clean = [self stringValue:value fallback:@""];
    if (limit == 0 || clean.length <= limit) return clean;
    return [[clean substringToIndex:limit] stringByAppendingString:@"..."];
}

- (void)requestJSON:(NSString *)method
                url:(NSString *)url
              token:(NSString *)token
           jsonBody:(id)jsonBody
           provider:(NSString *)provider
         completion:(GMLHTTPCompletion)completion {

    NSMutableURLRequest *req = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:url]];
    req.HTTPMethod = method;
    [req setValue:@"application/json, application/ld+json, text/plain, */*" forHTTPHeaderField:@"Accept"];
    [req setValue:@"application/json" forHTTPHeaderField:@"Content-Type"];
    [req setValue:@"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36" forHTTPHeaderField:@"User-Agent"];

    [self log:[NSString stringWithFormat:@"HTTP %@ %@%@", method, url, token.length ? @" [token]" : @""] level:@"HTTP"];

    if ([provider isEqualToString:@"tempemail"]) {
        [req setValue:@"https://www.tempemail.cc" forHTTPHeaderField:@"Origin"];
        [req setValue:@"https://www.tempemail.cc/" forHTTPHeaderField:@"Referer"];
    }
    if (token.length) [req setValue:[NSString stringWithFormat:@"Bearer %@", token] forHTTPHeaderField:@"Authorization"];
    if (jsonBody) req.HTTPBody = [NSJSONSerialization dataWithJSONObject:jsonBody options:0 error:nil];

    [[self.session dataTaskWithRequest:req completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        NSInteger status = [(NSHTTPURLResponse *)response statusCode];
        NSLog(@"[GenMail-NET] %@ %@ -> status=%ld err=%@ dataLen=%lu", method, url, (long)status, error.localizedDescription, (unsigned long)data.length);
        id payload = nil;
        if (data.length) payload = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        if (!payload && data.length) payload = @{ @"status": @(status), @"text": [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] ?: @"" };
        if (error) {
            status = 0;
            payload = @{ @"status": @0, @"message": error.localizedDescription ?: @"Erreur reseau" };
        }
        if ([payload isKindOfClass:[NSDictionary class]] && [payload[@"code"] respondsToSelector:@selector(integerValue)]) status = [payload[@"code"] integerValue];

        dispatch_async(dispatch_get_main_queue(), ^{
            NSString *summary = [self compactString:[self jsonString:payload ?: @{}] limit:220];
            [self log:[NSString stringWithFormat:@"HTTP %@ %@ -> %ld %@", method, url, (long)status, summary.length ? summary : @"(vide)"] level:(status >= 400 || status == 0) ? @"ERROR" : @"HTTP"];
            completion(status, payload ?: @{});
        });
    }] resume];
}

- (void)fetchDomainsForProvider:(NSString *)provider completion:(GMLDomainsCompletion)completion {
    NSString *url = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/domains" : @"https://api.mail.tm/domains";
    [self requestJSON:@"GET" url:url token:nil jsonBody:nil provider:provider completion:^(NSInteger status, id payload) {
        if (status >= 400 || status == 0) return completion(nil, [self jsonString:payload]);
        completion([self extractDomainsFromPayload:payload provider:provider], nil);
    }];
}

- (NSArray *)extractDomainsFromPayload:(id)payload provider:(NSString *)provider {
    NSMutableArray *domains = [NSMutableArray array];
    NSArray *raw = nil;
    if ([provider isEqualToString:@"tempemail"]) {
        raw = [payload isKindOfClass:[NSDictionary class]] ? payload[@"data"] : nil;
    } else {
        if ([payload isKindOfClass:[NSArray class]]) raw = (NSArray *)payload;
        else if ([payload isKindOfClass:[NSDictionary class]]) raw = payload[@"hydra:member"];
    }

    for (id entry in raw ?: @[]) {
        if ([entry isKindOfClass:[NSString class]]) {
            NSString *domain = [(NSString *)entry stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
            if (domain.length) [domains addObject:domain];
            continue;
        }
        if (![entry isKindOfClass:[NSDictionary class]]) continue;
        NSString *domain = [self stringValue:entry[@"domain"] fallback:@""];
        if (domain.length == 0) continue;
        id active = entry[@"isActive"];
        if ([provider isEqualToString:@"mailtm"] && active && ![active boolValue]) continue;
        [domains addObject:domain];
    }
    return domains;
}

@end
