#import "GMLThemeManager.h"

@implementation GMLThemeManager

// Background colors
+ (UIColor *)backgroundColor { return [UIColor colorWithRed:0.03 green:0.05 blue:0.09 alpha:1.0]; }
+ (UIColor *)cardBackgroundColor { return [UIColor colorWithRed:0.07 green:0.10 blue:0.15 alpha:1.0]; }
+ (UIColor *)heroCardBackgroundColor { return [UIColor colorWithRed:0.09 green:0.12 blue:0.18 alpha:1.0]; }
+ (UIColor *)inputBackgroundColor { return [UIColor colorWithRed:0.06 green:0.08 blue:0.12 alpha:1.0]; }
+ (UIColor *)textViewBackgroundColor { return [UIColor colorWithRed:0.05 green:0.07 blue:0.10 alpha:1.0]; }
+ (UIColor *)cellBackgroundColor { return [UIColor colorWithRed:0.06 green:0.08 blue:0.12 alpha:1.0]; }
+ (UIColor *)badgeBackgroundColor { return [UIColor colorWithRed:0.13 green:0.17 blue:0.25 alpha:1.0]; }
+ (UIColor *)chromeButtonBackgroundColor { return [UIColor colorWithRed:0.09 green:0.12 blue:0.18 alpha:1.0]; }
+ (UIColor *)chromeButtonActiveBackgroundColor { return [UIColor colorWithRed:0.19 green:0.43 blue:0.83 alpha:1.0]; }
+ (UIColor *)secondaryButtonBackgroundColor { return [UIColor colorWithRed:0.10 green:0.14 blue:0.21 alpha:1.0]; }
+ (UIColor *)primaryButtonBackgroundColor { return [UIColor colorWithRed:0.19 green:0.43 blue:0.83 alpha:1.0]; }

// Border colors
+ (UIColor *)cardBorderColor { return [UIColor colorWithRed:0.18 green:0.24 blue:0.36 alpha:1.0]; }
+ (UIColor *)inputBorderColor { return [UIColor colorWithRed:0.20 green:0.24 blue:0.34 alpha:1.0]; }
+ (UIColor *)textViewBorderColor { return [UIColor colorWithRed:0.18 green:0.23 blue:0.32 alpha:1.0]; }
+ (UIColor *)chromeButtonBorderColor { return [UIColor colorWithRed:0.19 green:0.26 blue:0.38 alpha:1.0]; }
+ (UIColor *)secondaryButtonBorderColor { return [UIColor colorWithRed:0.20 green:0.28 blue:0.42 alpha:1.0]; }
+ (UIColor *)logoBorderColor { return [UIColor colorWithRed:0.22 green:0.30 blue:0.44 alpha:1.0]; }

// Text colors
+ (UIColor *)primaryTextColor { return UIColor.whiteColor; }
+ (UIColor *)secondaryTextColor { return [UIColor colorWithRed:0.74 green:0.80 blue:0.92 alpha:1.0]; }
+ (UIColor *)tertiaryTextColor { return [UIColor colorWithRed:0.64 green:0.69 blue:0.81 alpha:1.0]; }
+ (UIColor *)placeholderTextColor { return [UIColor colorWithRed:0.49 green:0.55 blue:0.67 alpha:1.0]; }
+ (UIColor *)accentTextColor { return [UIColor colorWithRed:0.57 green:0.76 blue:1.0 alpha:1.0]; }
+ (UIColor *)badgeTextColor { return [UIColor colorWithRed:0.86 green:0.92 blue:1.0 alpha:1.0]; }
+ (UIColor *)chromeButtonTintColor { return [UIColor colorWithRed:0.86 green:0.92 blue:1.0 alpha:1.0]; }
+ (UIColor *)textViewTextColor { return [UIColor colorWithRed:0.85 green:0.90 blue:0.98 alpha:1.0]; }
+ (UIColor *)fieldLabelColor { return [UIColor colorWithRed:0.66 green:0.71 blue:0.83 alpha:1.0]; }
+ (UIColor *)logoTintColor { return [UIColor colorWithRed:0.75 green:0.84 blue:0.99 alpha:1.0]; }

// Navigation
+ (UIColor *)navBarBackgroundColor { return [UIColor colorWithRed:0.07 green:0.10 blue:0.15 alpha:1.0]; }
+ (UIColor *)navBarTintColor { return [UIColor colorWithRed:0.55 green:0.75 blue:1.0 alpha:1.0]; }
+ (UIColor *)windowBackgroundColor { return [UIColor colorWithRed:0.05 green:0.07 blue:0.11 alpha:1.0]; }

// Shadow
+ (UIColor *)cardShadowColor { return [UIColor colorWithRed:0.02 green:0.04 blue:0.08 alpha:1.0]; }

// Layout constants
+ (CGFloat)cardCornerRadius { return 22.0; }
+ (CGFloat)heroCardCornerRadius { return 28.0; }
+ (CGFloat)buttonCornerRadius { return 14.0; }
+ (CGFloat)inputCornerRadius { return 12.0; }
+ (CGFloat)textViewCornerRadius { return 14.0; }
+ (CGFloat)chromeButtonCornerRadius { return 18.0; }
+ (CGFloat)chromeButtonSize { return 36.0; }
+ (CGFloat)badgeCornerRadius { return 11.0; }
+ (CGFloat)badgeHeight { return 22.0; }
+ (CGFloat)badgeMinWidth { return 92.0; }
+ (CGFloat)logoCornerRadius { return 18.0; }
+ (CGFloat)cardShadowOpacity { return 0.28; }
+ (CGFloat)cardShadowRadius { return 24.0; }
+ (CGSize)cardShadowOffset { return CGSizeMake(0, 12); }
+ (CGFloat)inputHeight { return 44.0; }

@end
