#import "GMLSettingsViewController.h"
#import "GMLThemeManager.h"
#import "GMLAccountStore.h"
#import "GMLCardView.h"

@interface GMLSettingsViewController ()
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSArray *sections;
@end

@implementation GMLSettingsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [GMLThemeManager backgroundColor];

    self.sections = @[
        @{
            @"title": @"Inbox",
            @"rows": @[
                @{ @"icon": @"arrow.clockwise", @"title": @"Auto-refresh (30s)", @"type": @"toggle", @"key": @"GMLAutoRefreshEnabled" }
            ]
        },
        @{
            @"title": @"Stockage",
            @"rows": @[
                @{ @"icon": @"doc.text", @"title": @"Fichier comptes", @"type": @"detail" },
                @{ @"icon": @"folder", @"title": @"Dossier GenMail", @"type": @"detail" },
                @{ @"icon": @"trash", @"title": @"Purger tous les comptes", @"type": @"destructive" }
            ]
        },
        @{
            @"title": @"Export",
            @"rows": @[
                @{ @"icon": @"doc.on.clipboard", @"title": @"Copier tout (email:pass)", @"type": @"action" },
                @{ @"icon": @"square.and.arrow.up", @"title": @"Copier tout (JSON)", @"type": @"action" }
            ]
        },
        @{
            @"title": @"A propos",
            @"rows": @[
                @{ @"icon": @"info.circle", @"title": @"Version", @"type": @"info", @"value": @"0.1.8" },
                @{ @"icon": @"hammer", @"title": @"Build", @"type": @"info", @"value": @"Theos arm64" },
                @{ @"icon": @"person.crop.circle", @"title": @"Auteur", @"type": @"info", @"value": @"OpenClaw" }
            ]
        }
    ];

    self.tableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.tableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    self.tableView.backgroundColor = [GMLThemeManager backgroundColor];
    self.tableView.separatorColor = [GMLThemeManager cardBorderColor];
    [self.view addSubview:self.tableView];

    [NSLayoutConstraint activateConstraints:@[
        [self.tableView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [self.tableView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [self.tableView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [self.tableView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor]
    ]];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.sections.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.sections[section][@"rows"] count];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
    return self.sections[section][@"title"];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *row = self.sections[indexPath.section][@"rows"][indexPath.row];
    NSString *type = row[@"type"];

    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleValue1 reuseIdentifier:nil];
    cell.backgroundColor = [GMLThemeManager cardBackgroundColor];
    BOOL isDestructive = [type isEqualToString:@"destructive"];
    cell.textLabel.textColor = isDestructive ? [UIColor colorWithRed:0.95 green:0.30 blue:0.30 alpha:1.0] : [GMLThemeManager primaryTextColor];
    cell.textLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    cell.textLabel.text = row[@"title"];
    cell.selectionStyle = ([type isEqualToString:@"info"] || [type isEqualToString:@"toggle"]) ? UITableViewCellSelectionStyleNone : UITableViewCellSelectionStyleDefault;

    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:16 weight:UIImageSymbolWeightMedium];
    cell.imageView.image = [UIImage systemImageNamed:row[@"icon"] withConfiguration:cfg];
    cell.imageView.tintColor = isDestructive ? [UIColor colorWithRed:0.95 green:0.30 blue:0.30 alpha:1.0] : [GMLThemeManager accentTextColor];

    if ([type isEqualToString:@"info"]) {
        cell.detailTextLabel.text = row[@"value"];
        cell.detailTextLabel.textColor = [GMLThemeManager tertiaryTextColor];
        cell.detailTextLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightRegular];
    } else if ([type isEqualToString:@"detail"]) {
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    } else if ([type isEqualToString:@"toggle"]) {
        NSString *key = row[@"key"];
        UISwitch *toggle = [[UISwitch alloc] init];
        toggle.on = [[NSUserDefaults standardUserDefaults] boolForKey:key];
        toggle.onTintColor = [GMLThemeManager accentTextColor];
        toggle.tag = indexPath.section * 100 + indexPath.row;
        [toggle addTarget:self action:@selector(toggleChanged:) forControlEvents:UIControlEventValueChanged];
        cell.accessoryView = toggle;
    }

    UIView *selectedBg = [[UIView alloc] init];
    selectedBg.backgroundColor = [UIColor colorWithRed:0.10 green:0.15 blue:0.25 alpha:1.0];
    cell.selectedBackgroundView = selectedBg;

    return cell;
}

- (void)tableView:(UITableView *)tableView willDisplayHeaderView:(UIView *)view forSection:(NSInteger)section {
    if ([view isKindOfClass:[UITableViewHeaderFooterView class]]) {
        UITableViewHeaderFooterView *header = (UITableViewHeaderFooterView *)view;
        header.textLabel.textColor = [GMLThemeManager tertiaryTextColor];
        header.textLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    }
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    NSDictionary *row = self.sections[indexPath.section][@"rows"][indexPath.row];
    NSString *title = row[@"title"];

    if ([title isEqualToString:@"Fichier comptes"]) {
        [UIPasteboard generalPasteboard].string = [[GMLAccountStore shared] accountsPath];
        [self showToast:@"Chemin copie"];
    } else if ([title isEqualToString:@"Dossier GenMail"]) {
        [UIPasteboard generalPasteboard].string = [[GMLAccountStore shared] storageDirectory];
        [self showToast:@"Chemin copie"];
    } else if ([title isEqualToString:@"Purger tous les comptes"]) {
        [self confirmPurge];
    } else if ([title isEqualToString:@"Copier tout (email:pass)"]) {
        [self copyAllCombo];
    } else if ([title isEqualToString:@"Copier tout (JSON)"]) {
        [self copyAllJSON];
    }
}

- (void)toggleChanged:(UISwitch *)sender {
    NSInteger section = sender.tag / 100;
    NSInteger row = sender.tag % 100;
    NSDictionary *sectionData = self.sections[section];
    NSDictionary *rowData = sectionData[@"rows"][row];
    NSString *key = rowData[@"key"];
    if (key) {
        [[NSUserDefaults standardUserDefaults] setBool:sender.on forKey:key];
        [[NSUserDefaults standardUserDefaults] synchronize];
        [self showToast:sender.on ? @"Auto-refresh actif" : @"Auto-refresh desactive"];
    }
}

- (void)confirmPurge {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Purger tous les comptes ?" message:@"Cette action supprimera definitivement tous les comptes sauvegardes. Impossible d'annuler." preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Annuler" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Supprimer tout" style:UIAlertActionStyleDestructive handler:^(UIAlertAction *action) {
        [[GMLAccountStore shared] saveAccounts:@[]];
        UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleHeavy];
        [haptic impactOccurred];
        [self showToast:@"Tous les comptes supprimes"];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)copyAllCombo {
    NSArray *accounts = [[GMLAccountStore shared] loadAccounts];
    NSMutableArray *lines = [NSMutableArray array];
    for (NSDictionary *a in accounts) {
        NSString *email = [[GMLAccountStore shared] stringValue:a[@"email"] fallback:@""];
        NSString *pass = [[GMLAccountStore shared] stringValue:a[@"password"] fallback:@""];
        if (email.length) [lines addObject:[NSString stringWithFormat:@"%@:%@", email, pass]];
    }
    [UIPasteboard generalPasteboard].string = [lines componentsJoinedByString:@"\n"];
    [self showToast:[NSString stringWithFormat:@"%ld comptes copies", (long)lines.count]];
}

- (void)copyAllJSON {
    NSArray *accounts = [[GMLAccountStore shared] loadAccounts];
    NSData *data = [NSJSONSerialization dataWithJSONObject:accounts options:NSJSONWritingPrettyPrinted error:nil];
    [UIPasteboard generalPasteboard].string = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] ?: @"[]";
    [self showToast:[NSString stringWithFormat:@"JSON copie (%ld comptes)", (long)accounts.count]];
}

- (void)showToast:(NSString *)text {
    UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [haptic impactOccurred];

    UILabel *toast = [[UILabel alloc] initWithFrame:CGRectZero];
    toast.translatesAutoresizingMaskIntoConstraints = NO;
    toast.text = text;
    toast.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    toast.textColor = [UIColor whiteColor];
    toast.backgroundColor = [UIColor colorWithRed:0.20 green:0.50 blue:0.85 alpha:0.95];
    toast.textAlignment = NSTextAlignmentCenter;
    toast.layer.cornerRadius = 10;
    toast.clipsToBounds = YES;
    toast.alpha = 0;
    [self.view addSubview:toast];

    [NSLayoutConstraint activateConstraints:@[
        [toast.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [toast.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-20],
        [toast.heightAnchor constraintEqualToConstant:40],
        [toast.widthAnchor constraintGreaterThanOrEqualToConstant:160],
        [toast.leadingAnchor constraintGreaterThanOrEqualToAnchor:self.view.leadingAnchor constant:40],
        [toast.trailingAnchor constraintLessThanOrEqualToAnchor:self.view.trailingAnchor constant:-40]
    ]];

    [UIView animateWithDuration:0.25 animations:^{
        toast.alpha = 1.0;
    } completion:^(BOOL finished) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(1.8 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [UIView animateWithDuration:0.3 animations:^{
                toast.alpha = 0;
            } completion:^(BOOL done) {
                [toast removeFromSuperview];
            }];
        });
    }];
}

@end
