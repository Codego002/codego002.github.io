#import "AppDelegate.h"
#import "GMLTabBarController.h"
#import "GMLThemeManager.h"

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    self.window.backgroundColor = [GMLThemeManager windowBackgroundColor];
    self.window.rootViewController = [[GMLTabBarController alloc] init];
    [self.window makeKeyAndVisible];
    return YES;
}

@end
