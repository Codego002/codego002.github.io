#import <UIKit/UIKit.h>

@interface GMLSettingsViewController : UIViewController <UITableViewDataSource, UITableViewDelegate>
@end
