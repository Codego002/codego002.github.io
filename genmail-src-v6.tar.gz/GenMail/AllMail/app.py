from pathlib import Path
import json
import random
import string
import time
from typing import Any, Dict, List, Optional

import requests
from fastapi import FastAPI, HTTPException
from fastapi.responses import HTMLResponse
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / 'data'
DATA_DIR.mkdir(parents=True, exist_ok=True)
ACCOUNTS_FILE = DATA_DIR / 'accounts.json'

PROVIDERS = {
    'tempemail': {'label': 'tempemail.cc', 'base_url': 'https://www.tempemail.cc'},
    'mailtm': {'label': 'mail.tm', 'base_url': 'https://api.mail.tm'},
}

app = FastAPI(title='AllMail')


def load_accounts() -> List[Dict[str, Any]]:
    if not ACCOUNTS_FILE.exists():
        return []
    try:
        return json.loads(ACCOUNTS_FILE.read_text(encoding='utf-8'))
    except Exception:
        return []


def save_accounts(accounts: List[Dict[str, Any]]) -> None:
    ACCOUNTS_FILE.write_text(json.dumps(accounts, ensure_ascii=False, indent=2), encoding='utf-8')


def provider_cfg(provider: str) -> Dict[str, str]:
    key = (provider or '').strip().lower()
    if key not in PROVIDERS:
        raise HTTPException(status_code=400, detail={'message': 'provider invalide', 'available': list(PROVIDERS.keys())})
    return PROVIDERS[key]


def request_json(method: str, url: str, token: Optional[str] = None, json_body: Any = None, provider: str = 'mailtm'):
    headers = {
        'Accept': 'application/json, application/ld+json, text/plain, */*',
        'Content-Type': 'application/json',
        'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36',
    }
    if provider == 'tempemail':
        headers['Origin'] = 'https://www.tempemail.cc'
        headers['Referer'] = 'https://www.tempemail.cc/'
    if token:
        headers['Authorization'] = f'Bearer {token}'
    try:
        resp = requests.request(method, url, headers=headers, json=json_body, timeout=30)
        try:
            payload = resp.json()
        except Exception:
            payload = {'status': resp.status_code, 'text': resp.text}
        app_code = payload.get('code') if isinstance(payload, dict) else None
        effective_status = int(app_code) if isinstance(app_code, int) else resp.status_code
        return effective_status, payload
    except requests.RequestException as e:
        return 0, {'status': 0, 'message': str(e)}


def rand_local(length: int = 10) -> str:
    chars = string.ascii_lowercase + string.digits
    return ''.join(random.choice(chars) for _ in range(length))


def rand_password(length: int = 12) -> str:
    chars = [random.choice(string.ascii_lowercase), random.choice(string.ascii_uppercase), random.choice(string.digits)]
    pool = string.ascii_letters + string.digits
    while len(chars) < max(length - 1, 10):
        chars.append(random.choice(pool))
    random.shuffle(chars)
    return ''.join(chars) + '!'


def upsert_account(item: Dict[str, Any]) -> None:
    accounts = load_accounts()
    key_email = (item.get('email') or '').lower()
    key_provider = item.get('provider') or ''
    found = False
    for acc in accounts:
        if (acc.get('email') or '').lower() == key_email and (acc.get('provider') or '') == key_provider:
            acc.update(item)
            found = True
            break
    if not found:
        accounts.append(item)
    save_accounts(accounts)


class GenerateRequest(BaseModel):
    provider: str
    count: int = 10
    domain: Optional[str] = None
    prefix: Optional[str] = None
    password_mode: str = 'random'
    fixed_password: Optional[str] = None
    verify_login: bool = True
    delay_ms: int = 0


class ImportRequest(BaseModel):
    provider: str
    lines: str


@app.get('/', response_class=HTMLResponse)
def index():
    return HTMLResponse((BASE_DIR / 'static' / 'index.html').read_text(encoding='utf-8'))


@app.get('/api/providers')
def get_providers():
    return {'ok': True, 'providers': PROVIDERS}


@app.get('/api/local/accounts')
def get_local_accounts(provider: str = ''):
    items = load_accounts()
    if provider:
        items = [a for a in items if (a.get('provider') or '') == provider]
    return {'ok': True, 'items': items}


@app.get('/api/local/export.txt')
def export_txt(provider: str = ''):
    items = load_accounts()
    if provider:
        items = [a for a in items if (a.get('provider') or '') == provider]
    lines = [f"{a['email']}:{a['password']}" for a in items if a.get('status') == 'ok' and a.get('email') and a.get('password')]
    return HTMLResponse('\n'.join(lines), media_type='text/plain; charset=utf-8')


@app.post('/api/local/import')
def import_accounts(req: ImportRequest):
    cfg = provider_cfg(req.provider)
    accounts = load_accounts()
    added = updated = 0
    for raw in req.lines.splitlines():
        line = raw.strip()
        if not line or ':' not in line:
            continue
        email, password = line.split(':', 1)
        email = email.strip().lower()
        password = password.strip()
        if not email or not password:
            continue
        found = next((a for a in accounts if (a.get('email') or '').lower() == email and (a.get('provider') or '') == req.provider), None)
        if found:
            found['password'] = password
            updated += 1
        else:
            accounts.append({'provider': req.provider, 'provider_label': cfg['label'], 'email': email, 'password': password, 'base_url': cfg['base_url'], 'token': '', 'remote_id': '', 'status': 'imported', 'last_error': '', 'messages_count': 0})
            added += 1
    save_accounts(accounts)
    return {'ok': True, 'added': added, 'updated': updated}


def tempemail_domains() -> List[str]:
    status, payload = request_json('GET', f"{PROVIDERS['tempemail']['base_url']}/api/domains", provider='tempemail')
    if status >= 400:
        raise HTTPException(status_code=status, detail=payload)
    raw = payload.get('data') or []
    out = []
    for d in raw:
        if isinstance(d, str) and d.strip():
            out.append(d.strip())
        elif isinstance(d, dict) and d.get('domain'):
            out.append(str(d['domain']).strip())
    return out


def mailtm_domains() -> List[str]:
    status, payload = request_json('GET', f"{PROVIDERS['mailtm']['base_url']}/domains", provider='mailtm')
    if status >= 400:
        raise HTTPException(status_code=status, detail=payload)
    if isinstance(payload, list):
        raw = payload
    elif isinstance(payload, dict):
        raw = payload.get('hydra:member') or []
    else:
        raw = []
    return [d.get('domain') for d in raw if isinstance(d, dict) and d.get('domain') and d.get('isActive', True)]


@app.get('/api/remote/domains')
def get_domains(provider: str):
    provider_cfg(provider)
    domains = tempemail_domains() if provider == 'tempemail' else mailtm_domains()
    return {'ok': True, 'provider': provider, 'domains': domains}


@app.post('/api/remote/generate')
def generate_accounts(req: GenerateRequest):
    cfg = provider_cfg(req.provider)
    count = max(1, min(req.count, 200))
    domains = tempemail_domains() if req.provider == 'tempemail' else mailtm_domains()
    if not domains:
        raise HTTPException(status_code=400, detail='Aucun domaine disponible')
    domain = (req.domain or '').strip() or domains[0]
    if domain not in domains:
        raise HTTPException(status_code=400, detail={'message': 'Domaine indisponible', 'available': domains})

    existing = {(a.get('provider') or '', (a.get('email') or '').lower()) for a in load_accounts()}
    results = []
    for i in range(count):
        local = f"{(req.prefix or '').strip().lower()}{rand_local()}"
        email = f'{local}@{domain}'.lower()
        while (req.provider, email) in existing:
            local = f"{(req.prefix or '').strip().lower()}{rand_local()}"
            email = f'{local}@{domain}'.lower()
        password = (req.fixed_password or '').strip() if req.password_mode == 'fixed' else rand_password()
        if not password:
            password = rand_password()

        item = {'provider': req.provider, 'provider_label': cfg['label'], 'email': email, 'password': password, 'base_url': cfg['base_url'], 'token': '', 'remote_id': '', 'status': 'create_error', 'last_error': '', 'messages_count': 0}

        if req.provider == 'tempemail':
            create_status, create_payload = request_json('POST', f"{cfg['base_url']}/api/accounts", json_body={'email': email, 'password': password}, provider='tempemail')
            if create_status == 200:
                data = create_payload.get('data') or {}
                item['remote_id'] = data.get('id', '')
                item['token'] = data.get('token', '')
                item['status'] = 'created'
                if req.verify_login:
                    login_status, login_payload = request_json('POST', f"{cfg['base_url']}/api/token", json_body={'email': email, 'password': password}, provider='tempemail')
                    if login_status == 200:
                        token = (login_payload.get('data') or {}).get('token', item['token'])
                        item['token'] = token
                        me_status, me_payload = request_json('GET', f"{cfg['base_url']}/api/me", token=token, provider='tempemail')
                        if me_status == 200:
                            item['status'] = 'ok'
                        else:
                            item['status'] = 'check_error'
                            item['last_error'] = json.dumps(me_payload, ensure_ascii=False)
                    else:
                        item['status'] = 'login_error'
                        item['last_error'] = json.dumps(login_payload, ensure_ascii=False)
                else:
                    item['status'] = 'ok'
            else:
                item['last_error'] = json.dumps(create_payload, ensure_ascii=False)
                if req.delay_ms > 0 and i < count - 1:
                    time.sleep(req.delay_ms / 1000.0)
        else:
            create_status, create_payload = request_json('POST', f"{cfg['base_url']}/accounts", json_body={'address': email, 'password': password}, provider='mailtm')
            if create_status in (200, 201):
                item['status'] = 'created'
                item['remote_id'] = create_payload.get('id', '')
                if req.verify_login:
                    login_status, login_payload = request_json('POST', f"{cfg['base_url']}/token", json_body={'address': email, 'password': password}, provider='mailtm')
                    if login_status in (200, 201):
                        item['token'] = login_payload.get('token', '')
                        me_status, me_payload = request_json('GET', f"{cfg['base_url']}/me", token=item['token'], provider='mailtm')
                        if me_status == 200:
                            item['status'] = 'ok'
                            item['remote_id'] = me_payload.get('id', item['remote_id'])
                        else:
                            item['status'] = 'check_error'
                            item['last_error'] = json.dumps(me_payload, ensure_ascii=False)
                    else:
                        item['status'] = 'login_error'
                        item['last_error'] = json.dumps(login_payload, ensure_ascii=False)
                else:
                    item['status'] = 'ok'
            else:
                item['last_error'] = json.dumps(create_payload, ensure_ascii=False)

        upsert_account(item)
        existing.add((req.provider, email))
        results.append({'provider': req.provider, 'email': item['email'], 'password': item['password'], 'status': item['status'], 'ok': item['status'] == 'ok', 'error': item['last_error']})
        if req.provider == 'tempemail' and req.delay_ms > 0 and i < count - 1:
            time.sleep(req.delay_ms / 1000.0)

    ok_items = [r for r in results if r['ok']]
    failed = [r for r in results if not r['ok']]
    export_text = '\n'.join(f"{r['email']}:{r['password']}" for r in ok_items)
    return {'ok': True, 'summary': {'requested': count, 'success': len(ok_items), 'failed': len(failed), 'domain': domain, 'provider': req.provider}, 'export': export_text, 'items': results}


@app.post('/api/remote/login-all')
def login_all(provider: str):
    cfg = provider_cfg(provider)
    accounts = [a for a in load_accounts() if (a.get('provider') or '') == provider]
    out = []
    for a in accounts:
        email = a.get('email', '')
        password = a.get('password', '')
        if not email or not password:
            continue
        if provider == 'tempemail':
            status, payload = request_json('POST', f"{cfg['base_url']}/api/token", json_body={'email': email, 'password': password}, provider='tempemail')
            token = (payload.get('data') or {}).get('token', '') if isinstance(payload, dict) else ''
            ok = status == 200 and bool(token)
        else:
            status, payload = request_json('POST', f"{cfg['base_url']}/token", json_body={'address': email, 'password': password}, provider='mailtm')
            token = payload.get('token', '') if isinstance(payload, dict) else ''
            ok = status in (200, 201) and bool(token)
        if ok:
            a['token'] = token
            a['status'] = 'ok'
            a['last_error'] = ''
            out.append({'email': email, 'ok': True})
        else:
            a['status'] = 'login_error'
            a['last_error'] = json.dumps(payload, ensure_ascii=False)
            out.append({'email': email, 'ok': False, 'error': a['last_error']})
    save_accounts(load_accounts())
    return {'ok': True, 'items': out}


@app.get('/api/remote/messages/{provider}/{email:path}')
def get_messages(provider: str, email: str):
    provider_cfg(provider)
    accounts = load_accounts()
    target = next((a for a in accounts if (a.get('provider') or '') == provider and (a.get('email') or '').lower() == email.lower()), None)
    if not target:
        raise HTTPException(status_code=404, detail='Compte introuvable')
    token = target.get('token')
    if not token:
        raise HTTPException(status_code=400, detail='Token absent')
    if provider == 'tempemail':
        status, payload = request_json('GET', f"{target['base_url']}/api/messages", token=token, provider='tempemail')
        items = ((payload.get('data') or {}).get('items') or []) if isinstance(payload, dict) else []
    else:
        status, payload = request_json('GET', f"{target['base_url']}/messages", token=token, provider='mailtm')
        items = payload.get('hydra:member') or [] if isinstance(payload, dict) else []
    if status >= 400:
        raise HTTPException(status_code=status, detail=payload)
    target['messages_count'] = len(items)
    save_accounts(accounts)
    return {'ok': True, 'response': payload}


@app.delete('/api/local/account/{provider}/{email:path}')
def delete_local(provider: str, email: str):
    provider_cfg(provider)
    accounts = load_accounts()
    new_accounts = [a for a in accounts if not ((a.get('provider') or '') == provider and (a.get('email') or '').lower() == email.lower())]
    save_accounts(new_accounts)
    return {'ok': True, 'removed': len(accounts) - len(new_accounts)}


if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='127.0.0.1', port=8795)
