# AllMail

Version unifiée pour **tempemail.cc** et **mail.tm**.

## Fonctions

- choix du provider dans une seule interface
- génération de comptes
- import de comptes existants `email:motdepasse`
- export des comptes OK
- login all
- lecture de la liste des messages
- copie rapide

## Lancement

```bash
cd /home/god/Documents/OpenClawBot/AllMail
python3 app.py
```

Puis ouvrir:

<http://127.0.0.1:8795>
