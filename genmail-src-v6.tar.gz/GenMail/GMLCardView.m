#import "GMLCardView.h"
#import "GMLThemeManager.h"

@implementation GMLCardView

+ (instancetype)card {
    GMLCardView *view = [[GMLCardView alloc] initWithFrame:CGRectZero];
    view.translatesAutoresizingMaskIntoConstraints = NO;
    view.backgroundColor = [GMLThemeManager cardBackgroundColor];
    view.layer.cornerRadius = [GMLThemeManager cardCornerRadius];
    view.layer.borderWidth = 0.5;
    view.layer.borderColor = [GMLThemeManager cardBorderColor].CGColor;
    view.layer.shadowColor = [UIColor blackColor].CGColor;
    view.layer.shadowOpacity = 0.35;
    view.layer.shadowRadius = 16.0;
    view.layer.shadowOffset = CGSizeMake(0, 8);

    // Top edge glow line
    CAGradientLayer *glow = [CAGradientLayer layer];
    glow.colors = @[
        (id)[UIColor colorWithRed:0.30 green:0.55 blue:0.95 alpha:0.15].CGColor,
        (id)[UIColor clearColor].CGColor
    ];
    glow.startPoint = CGPointMake(0.5, 0.0);
    glow.endPoint = CGPointMake(0.5, 1.0);
    glow.frame = CGRectMake(0, 0, 500, 2);
    glow.cornerRadius = [GMLThemeManager cardCornerRadius];
    glow.maskedCorners = kCALayerMinXMinYCorner | kCALayerMaxXMinYCorner;
    [view.layer addSublayer:glow];

    return view;
}

+ (instancetype)heroCard {
    GMLCardView *view = [[GMLCardView alloc] initWithFrame:CGRectZero];
    view.translatesAutoresizingMaskIntoConstraints = NO;
    view.layer.cornerRadius = [GMLThemeManager heroCardCornerRadius];
    view.clipsToBounds = YES;

    // Gradient background
    CAGradientLayer *bg = [CAGradientLayer layer];
    bg.colors = @[
        (id)[UIColor colorWithRed:0.08 green:0.12 blue:0.22 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.06 green:0.09 blue:0.16 alpha:1.0].CGColor,
        (id)[GMLThemeManager heroCardBackgroundColor].CGColor
    ];
    bg.locations = @[@(0.0), @(0.5), @(1.0)];
    bg.startPoint = CGPointMake(0, 0);
    bg.endPoint = CGPointMake(1, 1);
    bg.frame = CGRectMake(0, 0, 500, 300);
    [view.layer insertSublayer:bg atIndex:0];

    // Top highlight line
    CAGradientLayer *topLine = [CAGradientLayer layer];
    topLine.colors = @[
        (id)[UIColor colorWithRed:0.35 green:0.55 blue:0.95 alpha:0.0].CGColor,
        (id)[UIColor colorWithRed:0.35 green:0.55 blue:0.95 alpha:0.25].CGColor,
        (id)[UIColor colorWithRed:0.50 green:0.35 blue:0.90 alpha:0.25].CGColor,
        (id)[UIColor colorWithRed:0.50 green:0.35 blue:0.90 alpha:0.0].CGColor
    ];
    topLine.startPoint = CGPointMake(0, 0.5);
    topLine.endPoint = CGPointMake(1, 0.5);
    topLine.frame = CGRectMake(0, 0, 500, 1);
    [view.layer addSublayer:topLine];

    view.layer.borderWidth = 0.5;
    view.layer.borderColor = [UIColor colorWithRed:0.20 green:0.30 blue:0.50 alpha:0.4].CGColor;

    return view;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    // Update gradient layers to match actual bounds
    for (CALayer *sub in self.layer.sublayers) {
        if ([sub isKindOfClass:[CAGradientLayer class]]) {
            if (sub.frame.size.height <= 2) {
                sub.frame = CGRectMake(0, 0, self.bounds.size.width, sub.frame.size.height);
            } else {
                sub.frame = self.bounds;
            }
        }
    }
}

@end

@implementation GMLGradientButton

- (void)layoutSubviews {
    [super layoutSubviews];
    self.gradientLayer.frame = self.bounds;
    self.shimmerLayer.frame = self.bounds;
}

- (void)startShimmer {
    if (!self.shimmerLayer) return;
    self.shimmerLayer.hidden = NO;
    CABasicAnimation *anim = [CABasicAnimation animationWithKeyPath:@"locations"];
    anim.fromValue = @[@(-0.3), @(-0.15), @(0.0)];
    anim.toValue = @[@(1.0), @(1.15), @(1.3)];
    anim.duration = 1.5;
    anim.repeatCount = HUGE_VALF;
    anim.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    [self.shimmerLayer addAnimation:anim forKey:@"shimmer"];
}

- (void)stopShimmer {
    [self.shimmerLayer removeAnimationForKey:@"shimmer"];
    self.shimmerLayer.hidden = YES;
}

@end

@implementation GMLCircularProgressView {
    CAShapeLayer *_trackLayer;
    CAShapeLayer *_progressLayer;
    CAShapeLayer *_checkLayer;
}

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _progress = 0;
        [self setupLayers];
    }
    return self;
}

- (void)setupLayers {
    _trackLayer = [CAShapeLayer layer];
    _trackLayer.fillColor = [UIColor clearColor].CGColor;
    _trackLayer.strokeColor = [UIColor colorWithRed:0.12 green:0.16 blue:0.24 alpha:1.0].CGColor;
    _trackLayer.lineWidth = 6.0;
    _trackLayer.lineCap = kCALineCapRound;
    [self.layer addSublayer:_trackLayer];

    _progressLayer = [CAShapeLayer layer];
    _progressLayer.fillColor = [UIColor clearColor].CGColor;
    _progressLayer.strokeColor = [GMLThemeManager accentTextColor].CGColor;
    _progressLayer.lineWidth = 6.0;
    _progressLayer.lineCap = kCALineCapRound;
    _progressLayer.strokeEnd = 0;
    [self.layer addSublayer:_progressLayer];

    _checkLayer = [CAShapeLayer layer];
    _checkLayer.fillColor = [UIColor clearColor].CGColor;
    _checkLayer.strokeColor = [UIColor colorWithRed:0.30 green:0.85 blue:0.45 alpha:1.0].CGColor;
    _checkLayer.lineWidth = 4.0;
    _checkLayer.lineCap = kCALineCapRound;
    _checkLayer.lineJoin = kCALineJoinRound;
    _checkLayer.strokeEnd = 0;
    _checkLayer.hidden = YES;
    [self.layer addSublayer:_checkLayer];

    self.percentLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.percentLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.percentLabel.font = [UIFont monospacedDigitSystemFontOfSize:18 weight:UIFontWeightBold];
    self.percentLabel.textColor = [GMLThemeManager primaryTextColor];
    self.percentLabel.textAlignment = NSTextAlignmentCenter;
    self.percentLabel.text = @"0%";
    [self addSubview:self.percentLabel];

    [NSLayoutConstraint activateConstraints:@[
        [self.percentLabel.centerXAnchor constraintEqualToAnchor:self.centerXAnchor],
        [self.percentLabel.centerYAnchor constraintEqualToAnchor:self.centerYAnchor]
    ]];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGPoint center = CGPointMake(self.bounds.size.width / 2.0, self.bounds.size.height / 2.0);
    CGFloat radius = MIN(self.bounds.size.width, self.bounds.size.height) / 2.0 - 4.0;
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center radius:radius startAngle:-M_PI_2 endAngle:M_PI_2 * 3 clockwise:YES];
    _trackLayer.path = path.CGPath;
    _progressLayer.path = path.CGPath;

    CGFloat checkSize = radius * 0.5;
    UIBezierPath *checkPath = [UIBezierPath bezierPath];
    [checkPath moveToPoint:CGPointMake(center.x - checkSize * 0.5, center.y)];
    [checkPath addLineToPoint:CGPointMake(center.x - checkSize * 0.1, center.y + checkSize * 0.35)];
    [checkPath addLineToPoint:CGPointMake(center.x + checkSize * 0.5, center.y - checkSize * 0.35)];
    _checkLayer.path = checkPath.CGPath;
}

- (void)setProgress:(CGFloat)progress animated:(BOOL)animated {
    _progress = MIN(1.0, MAX(0.0, progress));
    self.percentLabel.text = [NSString stringWithFormat:@"%ld%%", (long)lroundf(_progress * 100.0f)];
    if (animated) {
        CABasicAnimation *anim = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
        anim.fromValue = @(_progressLayer.strokeEnd);
        anim.toValue = @(_progress);
        anim.duration = 0.3;
        anim.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
        _progressLayer.strokeEnd = _progress;
        [_progressLayer addAnimation:anim forKey:@"progress"];
    } else {
        [CATransaction begin];
        [CATransaction setDisableActions:YES];
        _progressLayer.strokeEnd = _progress;
        [CATransaction commit];
    }
}

- (void)showSuccess {
    self.percentLabel.hidden = YES;
    _progressLayer.strokeColor = [UIColor colorWithRed:0.30 green:0.85 blue:0.45 alpha:1.0].CGColor;

    CABasicAnimation *fillAnim = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    fillAnim.toValue = @(1.0);
    fillAnim.duration = 0.3;
    fillAnim.fillMode = kCAFillModeForwards;
    fillAnim.removedOnCompletion = NO;
    _progressLayer.strokeEnd = 1.0;
    [_progressLayer addAnimation:fillAnim forKey:@"fill"];

    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.3 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        self->_checkLayer.hidden = NO;
        CABasicAnimation *check = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
        check.fromValue = @(0.0);
        check.toValue = @(1.0);
        check.duration = 0.4;
        check.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
        self->_checkLayer.strokeEnd = 1.0;
        [self->_checkLayer addAnimation:check forKey:@"draw"];

        CABasicAnimation *scale = [CABasicAnimation animationWithKeyPath:@"transform.scale"];
        scale.fromValue = @(0.8);
        scale.toValue = @(1.0);
        scale.duration = 0.3;
        scale.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseOut];
        [self.layer addAnimation:scale forKey:@"pop"];
    });
}

- (void)reset {
    _progress = 0;
    _progressLayer.strokeEnd = 0;
    _progressLayer.strokeColor = [GMLThemeManager accentTextColor].CGColor;
    _checkLayer.hidden = YES;
    _checkLayer.strokeEnd = 0;
    self.percentLabel.hidden = NO;
    self.percentLabel.text = @"0%";
}

@end

@implementation GMLUIFactory

+ (UILabel *)badgeLabel:(NSString *)text {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.text = text;
    label.font = [UIFont systemFontOfSize:11 weight:UIFontWeightBold];
    label.textColor = [GMLThemeManager accentTextColor];
    label.backgroundColor = [UIColor colorWithRed:0.15 green:0.25 blue:0.45 alpha:0.4];
    label.layer.cornerRadius = 12;
    label.layer.borderWidth = 0.5;
    label.layer.borderColor = [UIColor colorWithRed:0.30 green:0.50 blue:0.85 alpha:0.3].CGColor;
    label.clipsToBounds = YES;
    label.textAlignment = NSTextAlignmentCenter;
    label.translatesAutoresizingMaskIntoConstraints = NO;
    [label.widthAnchor constraintGreaterThanOrEqualToConstant:80].active = YES;
    [label.heightAnchor constraintEqualToConstant:24].active = YES;
    return label;
}

+ (UIButton *)actionButton:(NSString *)title primary:(BOOL)primary {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:primary ? [UIColor whiteColor] : [GMLThemeManager primaryTextColor] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    button.backgroundColor = primary ? [GMLThemeManager primaryButtonBackgroundColor] : [UIColor colorWithRed:0.08 green:0.11 blue:0.18 alpha:1.0];
    button.layer.cornerRadius = [GMLThemeManager buttonCornerRadius];
    button.layer.borderWidth = primary ? 0.0 : 0.5;
    button.layer.borderColor = [UIColor colorWithRed:0.20 green:0.30 blue:0.48 alpha:0.5].CGColor;
    button.contentEdgeInsets = UIEdgeInsetsMake(12, 16, 12, 16);
    return button;
}

+ (GMLGradientButton *)gradientButton:(NSString *)title {
    GMLGradientButton *button = [GMLGradientButton buttonWithType:UIButtonTypeCustom];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:16 weight:UIFontWeightBold];
    button.layer.cornerRadius = [GMLThemeManager buttonCornerRadius];
    button.clipsToBounds = YES;
    button.contentEdgeInsets = UIEdgeInsetsMake(14, 24, 14, 24);

    CAGradientLayer *gradient = [CAGradientLayer layer];
    gradient.colors = @[
        (id)[UIColor colorWithRed:0.25 green:0.48 blue:0.92 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.45 green:0.30 blue:0.90 alpha:1.0].CGColor,
        (id)[UIColor colorWithRed:0.25 green:0.48 blue:0.92 alpha:1.0].CGColor
    ];
    gradient.startPoint = CGPointMake(0, 0.5);
    gradient.endPoint = CGPointMake(1, 0.5);
    [button.layer insertSublayer:gradient atIndex:0];
    button.gradientLayer = gradient;

    CAGradientLayer *shimmer = [CAGradientLayer layer];
    shimmer.colors = @[
        (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor,
        (id)[UIColor colorWithWhite:1.0 alpha:0.25].CGColor,
        (id)[UIColor colorWithWhite:1.0 alpha:0.0].CGColor
    ];
    shimmer.locations = @[@(-0.3), @(-0.15), @(0.0)];
    shimmer.startPoint = CGPointMake(0, 0.5);
    shimmer.endPoint = CGPointMake(1, 0.5);
    shimmer.hidden = YES;
    [button.layer insertSublayer:shimmer above:gradient];
    button.shimmerLayer = shimmer;

    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:16 weight:UIImageSymbolWeightBold];
    UIImage *bolt = [UIImage systemImageNamed:@"bolt.fill" withConfiguration:cfg];
    [button setImage:[bolt imageWithRenderingMode:UIImageRenderingModeAlwaysTemplate] forState:UIControlStateNormal];
    button.tintColor = [UIColor whiteColor];
    button.imageEdgeInsets = UIEdgeInsetsMake(0, -8, 0, 8);

    return button;
}

+ (GMLCircularProgressView *)circularProgress {
    GMLCircularProgressView *view = [[GMLCircularProgressView alloc] initWithFrame:CGRectZero];
    view.translatesAutoresizingMaskIntoConstraints = NO;
    [NSLayoutConstraint activateConstraints:@[
        [view.widthAnchor constraintEqualToConstant:80],
        [view.heightAnchor constraintEqualToConstant:80]
    ]];
    return view;
}

+ (UIImage *)symbolImageNamed:(NSString *)name {
    UIImageSymbolConfiguration *config = [UIImageSymbolConfiguration configurationWithPointSize:16 weight:UIImageSymbolWeightSemibold];
    return [UIImage systemImageNamed:name withConfiguration:config];
}

+ (UIButton *)chromeButtonWithSymbol:(NSString *)symbol accessibility:(NSString *)label {
    UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
    button.translatesAutoresizingMaskIntoConstraints = NO;
    [button setImage:[self symbolImageNamed:symbol] forState:UIControlStateNormal];
    button.tintColor = [GMLThemeManager chromeButtonTintColor];
    button.backgroundColor = [GMLThemeManager chromeButtonBackgroundColor];
    button.layer.cornerRadius = [GMLThemeManager chromeButtonCornerRadius];
    button.layer.borderWidth = 1.0;
    button.layer.borderColor = [GMLThemeManager chromeButtonBorderColor].CGColor;
    button.accessibilityLabel = label;
    CGFloat size = [GMLThemeManager chromeButtonSize];
    [button.widthAnchor constraintEqualToConstant:size].active = YES;
    [button.heightAnchor constraintEqualToConstant:size].active = YES;
    return button;
}

+ (UITextField *)textFieldWithPlaceholder:(NSString *)placeholder delegate:(id<UITextFieldDelegate>)delegate {
    UITextField *field = [[UITextField alloc] initWithFrame:CGRectZero];
    field.translatesAutoresizingMaskIntoConstraints = NO;
    field.backgroundColor = [GMLThemeManager inputBackgroundColor];
    field.textColor = [GMLThemeManager primaryTextColor];
    field.attributedPlaceholder = [[NSAttributedString alloc] initWithString:placeholder ?: @"" attributes:@{ NSForegroundColorAttributeName: [GMLThemeManager placeholderTextColor] }];
    field.layer.cornerRadius = [GMLThemeManager inputCornerRadius];
    field.layer.borderWidth = 1.0;
    field.layer.borderColor = [GMLThemeManager inputBorderColor].CGColor;
    field.font = [UIFont systemFontOfSize:15 weight:UIFontWeightMedium];
    field.leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 12, 1)];
    field.leftViewMode = UITextFieldViewModeAlways;
    field.rightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 12, 1)];
    field.rightViewMode = UITextFieldViewModeAlways;
    field.delegate = delegate;
    [field.heightAnchor constraintEqualToConstant:[GMLThemeManager inputHeight]].active = YES;
    return field;
}

+ (UIToolbar *)numericAccessoryToolbarWithTarget:(id)target action:(SEL)action {
    UIToolbar *toolbar = [[UIToolbar alloc] initWithFrame:CGRectMake(0, 0, 320, 44)];
    toolbar.translucent = YES;
    UIBarButtonItem *flex = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil];
    UIBarButtonItem *done = [[UIBarButtonItem alloc] initWithTitle:@"OK" style:UIBarButtonItemStyleDone target:target action:action];
    toolbar.items = @[flex, done];
    return toolbar;
}

+ (UITextView *)textViewWithMinHeight:(CGFloat)height {
    UITextView *view = [[UITextView alloc] initWithFrame:CGRectZero];
    view.translatesAutoresizingMaskIntoConstraints = NO;
    view.backgroundColor = [GMLThemeManager textViewBackgroundColor];
    view.textColor = [GMLThemeManager textViewTextColor];
    view.font = [UIFont fontWithName:@"Menlo-Regular" size:11.5] ?: [UIFont monospacedSystemFontOfSize:11.5 weight:UIFontWeightRegular];
    view.layer.cornerRadius = [GMLThemeManager textViewCornerRadius];
    view.layer.borderWidth = 1.0;
    view.layer.borderColor = [GMLThemeManager textViewBorderColor].CGColor;
    view.textContainerInset = UIEdgeInsetsMake(10, 10, 10, 10);
    [view.heightAnchor constraintGreaterThanOrEqualToConstant:height].active = YES;
    return view;
}

+ (UILabel *)sectionTitle:(NSString *)text {
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = text;
    label.font = [UIFont systemFontOfSize:16 weight:UIFontWeightSemibold];
    label.textColor = [GMLThemeManager primaryTextColor];
    return label;
}

+ (UIView *)fieldBlockWithTitle:(NSString *)title control:(UIView *)control {
    UIView *container = [[UIView alloc] initWithFrame:CGRectZero];
    container.translatesAutoresizingMaskIntoConstraints = NO;
    container.backgroundColor = [UIColor colorWithRed:0.05 green:0.07 blue:0.11 alpha:1.0];
    container.layer.cornerRadius = 12;

    UILabel *label = [[UILabel alloc] initWithFrame:CGRectZero];
    label.translatesAutoresizingMaskIntoConstraints = NO;
    label.text = [title uppercaseString];
    label.font = [UIFont systemFontOfSize:10 weight:UIFontWeightBold];
    label.textColor = [GMLThemeManager accentTextColor];
    label.alpha = 0.7;
    [container addSubview:label];
    [container addSubview:control];

    [NSLayoutConstraint activateConstraints:@[
        [label.topAnchor constraintEqualToAnchor:container.topAnchor constant:10],
        [label.leadingAnchor constraintEqualToAnchor:container.leadingAnchor constant:10],
        [label.trailingAnchor constraintEqualToAnchor:container.trailingAnchor constant:-10],
        [control.topAnchor constraintEqualToAnchor:label.bottomAnchor constant:6],
        [control.leadingAnchor constraintEqualToAnchor:container.leadingAnchor constant:10],
        [control.trailingAnchor constraintEqualToAnchor:container.trailingAnchor constant:-10],
        [control.bottomAnchor constraintEqualToAnchor:container.bottomAnchor constant:-10]
    ]];
    return container;
}

+ (UIStackView *)horizontalStack:(NSArray *)views compact:(BOOL)compact {
    UIStackView *stack = [[UIStackView alloc] initWithArrangedSubviews:views];
    stack.translatesAutoresizingMaskIntoConstraints = NO;
    stack.axis = compact ? UILayoutConstraintAxisVertical : UILayoutConstraintAxisHorizontal;
    stack.alignment = UIStackViewAlignmentFill;
    stack.distribution = compact ? UIStackViewDistributionFill : UIStackViewDistributionFillEqually;
    stack.spacing = 8.0;
    return stack;
}

@end
