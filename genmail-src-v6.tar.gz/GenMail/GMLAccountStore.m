#import "GMLAccountStore.h"
#import "GMLNetworkManager.h"

NSNotificationName const GMLAccountsDidChangeNotification = @"GMLAccountsDidChangeNotification";

@interface GMLAccountStore ()
@property (nonatomic, strong) NSString *internalStorageDir;
@property (nonatomic, strong) NSString *internalAccountsPath;
@end

@implementation GMLAccountStore

+ (instancetype)shared {
    static GMLAccountStore *instance;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [[GMLAccountStore alloc] init];
    });
    return instance;
}

- (instancetype)init {
    self = [super init];
    if (self) {
        _internalStorageDir = [self computeStorageDirectory];
        _internalAccountsPath = [_internalStorageDir stringByAppendingPathComponent:@"accounts.json"];
    }
    return self;
}

- (NSString *)accountsPath {
    return _internalAccountsPath;
}

- (NSString *)storageDirectory {
    return _internalStorageDir;
}

- (NSString *)computeStorageDirectory {
    NSString *dir = @"/var/mobile/GenMail/AllMail/data";
    NSError *error = nil;
    NSDictionary *attrs = @{ NSFilePosixPermissions: @0755 };
    [[NSFileManager defaultManager] createDirectoryAtPath:dir withIntermediateDirectories:YES attributes:attrs error:&error];
    if (error) NSLog(@"[GenMail] Impossible de creer %@: %@", dir, error.localizedDescription);
    // Fix permissions if directory was created by root (e.g. SCP deploy)
    NSFileManager *fm = [NSFileManager defaultManager];
    NSDictionary *existing = [fm attributesOfItemAtPath:dir error:nil];
    if (existing && ![fm isWritableFileAtPath:dir]) {
        [fm setAttributes:@{ NSFilePosixPermissions: @0755 } ofItemAtPath:dir error:nil];
        NSLog(@"[GenMail] Fixed permissions on %@", dir);
    }
    return dir;
}

- (NSString *)documentsPath:(NSString *)name {
    return [self.storageDirectory stringByAppendingPathComponent:name ?: @""];
}

#pragma mark - Providers

- (NSDictionary *)providers {
    return @{
        @"tempemail": @{ @"label": @"tempemail.cc", @"base_url": @"https://www.tempemail.cc" },
        @"mailtm": @{ @"label": @"mail.tm", @"base_url": @"https://api.mail.tm" }
    };
}

- (NSDictionary *)providerConfig:(NSString *)provider {
    return [self providers][provider];
}

#pragma mark - CRUD

- (NSArray *)loadAccounts {
    NSData *data = [NSData dataWithContentsOfFile:self.accountsPath];
    if (!data) return @[];
    id obj = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
    return [obj isKindOfClass:[NSArray class]] ? obj : @[];
}

- (void)saveAccounts:(NSArray *)accounts {
    NSData *data = [NSJSONSerialization dataWithJSONObject:accounts ?: @[] options:NSJSONWritingPrettyPrinted error:nil];
    BOOL ok = [data writeToFile:self.accountsPath atomically:YES];
    if (!ok) NSLog(@"[GenMail] ERREUR: saveAccounts failed to write to %@", self.accountsPath);
    else NSLog(@"[GenMail] saveAccounts: %ld accounts saved", (long)(accounts ?: @[]).count);
    dispatch_async(dispatch_get_main_queue(), ^{
        [[NSNotificationCenter defaultCenter] postNotificationName:GMLAccountsDidChangeNotification object:nil];
    });
}

- (NSArray *)accountsForProvider:(NSString *)provider {
    NSMutableArray *out = [NSMutableArray array];
    for (NSDictionary *a in [self loadAccounts]) {
        if (provider.length == 0 || [[self stringValue:a[@"provider"] fallback:@""] isEqualToString:provider]) [out addObject:a];
    }
    return out;
}

- (void)upsertAccount:(NSMutableDictionary *)item inAccounts:(NSMutableArray *)accounts {
    NSString *provider = [self stringValue:item[@"provider"] fallback:@""];
    NSString *email = [[self stringValue:item[@"email"] fallback:@""] lowercaseString];
    for (NSInteger i = 0; i < accounts.count; i++) {
        NSDictionary *a = accounts[i];
        if ([[self stringValue:a[@"provider"] fallback:@""] isEqualToString:provider] && [[[self stringValue:a[@"email"] fallback:@""] lowercaseString] isEqualToString:email]) {
            accounts[i] = [item mutableCopy];
            return;
        }
    }
    [accounts addObject:[item mutableCopy]];
}

- (void)updateMessageCount:(NSInteger)count forEmail:(NSString *)email {
    if (email.length == 0) return;
    NSString *lower = [email lowercaseString];
    NSMutableArray *all = [[self loadAccounts] mutableCopy];
    BOOL changed = NO;
    for (NSMutableDictionary *a in all) {
        if ([[[self stringValue:a[@"email"] fallback:@""] lowercaseString] isEqualToString:lower]) {
            if ([a[@"messages_count"] integerValue] != count) {
                a[@"messages_count"] = @(count);
                changed = YES;
            }
            break;
        }
    }
    if (changed) [self saveAccounts:all];
}

- (void)refreshAllMessageCounts {
    NSArray *accounts = [self loadAccounts];
    for (NSDictionary *account in accounts) {
        NSString *token = [self stringValue:account[@"token"] fallback:@""];
        if (token.length == 0) continue;
        NSString *provider = [self stringValue:account[@"provider"] fallback:@""];
        NSString *email = [self stringValue:account[@"email"] fallback:@""];
        NSString *url = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/messages" : @"https://api.mail.tm/messages";
        [[GMLNetworkManager shared] requestJSON:@"GET" url:url token:token jsonBody:nil provider:provider completion:^(NSInteger status, id payload) {
            if (status >= 400 || status == 0) return;
            NSArray *items = nil;
            if ([provider isEqualToString:@"tempemail"]) {
                if ([payload[@"data"] isKindOfClass:[NSDictionary class]]) items = payload[@"data"][@"items"];
            } else {
                if ([payload isKindOfClass:[NSDictionary class]]) items = payload[@"hydra:member"];
            }
            NSInteger count = [items isKindOfClass:[NSArray class]] ? (NSInteger)items.count : 0;
            dispatch_async(dispatch_get_main_queue(), ^{
                [self updateMessageCount:count forEmail:email];
            });
        }];
    }
}

- (void)deleteAccountByEmail:(NSString *)email {
    if (email.length == 0) return;
    NSString *lower = [email lowercaseString];
    NSMutableArray *all = [[self loadAccounts] mutableCopy];
    NSMutableArray *kept = [NSMutableArray array];
    for (NSDictionary *a in all) {
        if (![[[self stringValue:a[@"email"] fallback:@""] lowercaseString] isEqualToString:lower]) {
            [kept addObject:a];
        }
    }
    // saveAccounts: already posts GMLAccountsDidChangeNotification
    [self saveAccounts:kept];
}

#pragma mark - Generation helpers

- (NSString *)randomLocal:(NSInteger)length {
    NSString *chars = @"abcdefghijklmnopqrstuvwxyz0123456789";
    NSMutableString *out = [NSMutableString string];
    for (NSInteger i = 0; i < length; i++) {
        [out appendFormat:@"%C", [chars characterAtIndex:arc4random_uniform((uint32_t)chars.length)]];
    }
    return out;
}

- (NSString *)randomPassword {
    NSString *lower = @"abcdefghijklmnopqrstuvwxyz";
    NSString *upper = @"ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    NSString *digits = @"0123456789";
    NSString *pool = [NSString stringWithFormat:@"%@%@%@", lower, upper, digits];
    NSMutableString *out = [NSMutableString stringWithFormat:@"%C%C%C",
                            [lower characterAtIndex:arc4random_uniform((uint32_t)lower.length)],
                            [upper characterAtIndex:arc4random_uniform((uint32_t)upper.length)],
                            [digits characterAtIndex:arc4random_uniform((uint32_t)digits.length)]];
    while (out.length < 11) {
        [out appendFormat:@"%C", [pool characterAtIndex:arc4random_uniform((uint32_t)pool.length)]];
    }
    [out appendString:@"!"];
    return out;
}

- (NSString *)uniqueEmailForProvider:(NSString *)provider domain:(NSString *)domain prefix:(NSString *)prefix accounts:(NSArray *)accounts {
    while (1) {
        NSString *email = [NSString stringWithFormat:@"%@@%@", [NSString stringWithFormat:@"%@%@", prefix ?: @"", [self randomLocal:10]], domain].lowercaseString;
        BOOL exists = NO;
        for (NSDictionary *a in accounts) {
            if ([[self stringValue:a[@"provider"] fallback:@""] isEqualToString:provider] && [[[self stringValue:a[@"email"] fallback:@""] lowercaseString] isEqualToString:email]) {
                exists = YES;
                break;
            }
        }
        if (!exists) return email;
    }
}

#pragma mark - Utilities

- (NSString *)jsonString:(id)obj {
    if (!obj) return @"";
    if ([obj isKindOfClass:[NSString class]]) return obj;
    NSData *data = [NSJSONSerialization dataWithJSONObject:obj options:NSJSONWritingPrettyPrinted error:nil];
    return [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] ?: [obj description];
}

- (NSString *)stringValue:(id)value fallback:(NSString *)fallback {
    if ([value isKindOfClass:[NSString class]]) return value;
    if ([value respondsToSelector:@selector(stringValue)]) return [value stringValue];
    return fallback ?: @"";
}

- (NSString *)compactString:(NSString *)value limit:(NSUInteger)limit {
    NSString *clean = [self stringValue:value fallback:@""];
    if (limit == 0 || clean.length <= limit) return clean;
    return [[clean substringToIndex:limit] stringByAppendingString:@"..."];
}

@end
