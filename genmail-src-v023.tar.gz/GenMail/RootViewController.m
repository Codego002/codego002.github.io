#import "RootViewController.h"
#import "GMLThemeManager.h"
#import "GMLNetworkManager.h"
#import "GMLAccountStore.h"
#import "GMLCardView.h"

typedef void (^GMNativeCompletion)(BOOL ok, id payload);

@interface RootViewController () <UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate, UITextViewDelegate>
@property (nonatomic, strong) NSString *logsPath;

@property (nonatomic, strong) UILabel *statusLabel;
@property (nonatomic, strong) UIButton *reloadButton;
@property (nonatomic, strong) UIActivityIndicatorView *spinner;
@property (nonatomic, strong) UITextView *logTextView;
@property (nonatomic, strong) UIButton *clearLogsButton;
@property (nonatomic, strong) UIButton *toggleLogsButton;
@property (nonatomic, strong) UIButton *settingsButton;

@property (nonatomic, strong) UISegmentedControl *providerControl;
@property (nonatomic, strong) UITextField *countField;
@property (nonatomic, strong) UIButton *domainButton;
@property (nonatomic, strong) UITextField *prefixField;
@property (nonatomic, strong) UITextField *delayField;
@property (nonatomic, strong) UISegmentedControl *passwordModeControl;
@property (nonatomic, strong) UITextField *fixedPasswordField;
@property (nonatomic, strong) UILabel *fixedPasswordHint;
@property (nonatomic, strong) UISegmentedControl *verifyLoginControl;
@property (nonatomic, strong) UITextView *bulkTextView;
@property (nonatomic, strong) UIButton *loadDomainsButton;
@property (nonatomic, strong) GMLGradientButton *generateButton;
@property (nonatomic, strong) UIButton *importButton;
@property (nonatomic, strong) UIButton *loginAllButton;
@property (nonatomic, strong) UIButton *refreshButton;
@property (nonatomic, strong) UIButton *pasteImportButton;
@property (nonatomic, strong) UIButton *exportCopyButton;
@property (nonatomic, strong) UIButton *outputCopyButton;
@property (nonatomic, strong) GMLCircularProgressView *circularProgress;
@property (nonatomic, strong) UITextView *exportTextView;
@property (nonatomic, strong) UILabel *selectionLabel;
@property (nonatomic, strong) UIButton *selectedCopyButton;
@property (nonatomic, strong) UIButton *selectedMailCopyButton;
@property (nonatomic, strong) UIButton *selectedPasswordCopyButton;
@property (nonatomic, strong) UIButton *messagesSelectedButton;
@property (nonatomic, strong) UIButton *deleteSelectedButton;
@property (nonatomic, strong) UITableView *accountsTableView;
@property (nonatomic, strong) UITextView *outputTextView;

@property (nonatomic, strong) NSMutableArray *logEntries;
@property (nonatomic, strong) NSMutableDictionary *requestActions;
@property (nonatomic, strong) NSMutableDictionary *pendingCallbacks;
@property (nonatomic, strong) NSDateFormatter *logFormatter;
@property (nonatomic, strong) NSArray *domains;
@property (nonatomic, strong) NSMutableArray *displayedAccounts;
@property (nonatomic, strong) NSArray *pendingGeneratedAccounts;
@property (nonatomic, strong) NSDictionary *selectedAccount;
@property (nonatomic, strong) UILabel *settingsSummaryLabel;
@property (nonatomic, strong) UIView *settingsCard;
@property (nonatomic, strong) UIView *generationSection;
@property (nonatomic, strong) UIView *accountsSection;
@property (nonatomic, strong) UIView *outputSection;
@property (nonatomic, strong) UIView *logsSection;
@property (nonatomic, strong) UIStackView *selectionActionsRow;
@property (nonatomic, strong) UIStackView *selectionActionsSecondaryRow;
@property (nonatomic, strong) UISegmentedControl *consoleTabControl;
@property (nonatomic, strong) UIStackView *settingsContentStack;
@property (nonatomic, strong) UIStackView *consoleContentStack;

@property (nonatomic, strong) NSTimer *progressTimer;
@property (nonatomic, strong) NSLayoutConstraint *logHeightConstraint;
@property (nonatomic, strong) NSLayoutConstraint *accountsTableHeightConstraint;
@property (nonatomic, assign) NSInteger progressRequested;
@property (nonatomic, assign) NSInteger progressCurrent;
@property (nonatomic, assign) NSInteger runningActions;
@property (nonatomic, assign) BOOL logsExpanded;
@property (nonatomic, assign) BOOL settingsExpanded;
@end

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    self.view.backgroundColor = [GMLThemeManager backgroundColor];
    self.displayedAccounts = [NSMutableArray array];
    self.pendingGeneratedAccounts = @[];
    self.logEntries = [NSMutableArray array];
    self.requestActions = [NSMutableDictionary dictionary];
    self.pendingCallbacks = [NSMutableDictionary dictionary];
    self.logFormatter = [[NSDateFormatter alloc] init];
    self.logFormatter.dateFormat = @"HH:mm:ss";
    self.logsExpanded = NO;
    self.settingsExpanded = NO;
    self.logsPath = [[GMLAccountStore shared] documentsPath:@"app.log"];

    __weak typeof(self) weakSelf = self;
    [GMLNetworkManager shared].logBlock = ^(NSString *message, NSString *level) {
        [weakSelf appendLog:message level:level];
    };

    UIScrollView *scrollView = [[UIScrollView alloc] initWithFrame:CGRectZero];
    scrollView.translatesAutoresizingMaskIntoConstraints = NO;
    scrollView.alwaysBounceVertical = YES;
    scrollView.keyboardDismissMode = UIScrollViewKeyboardDismissModeInteractive;
    scrollView.backgroundColor = UIColor.clearColor;
    [self.view addSubview:scrollView];

    UIView *content = [[UIView alloc] initWithFrame:CGRectZero];
    content.translatesAutoresizingMaskIntoConstraints = NO;
    [scrollView addSubview:content];

    UITapGestureRecognizer *dismissTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(dismissKeyboardTapped)];
    dismissTap.cancelsTouchesInView = NO;
    [content addGestureRecognizer:dismissTap];

    // ── Toolbar Card (main control panel) ──
    UIView *panel = [GMLCardView card];
    [content addSubview:panel];

    UILabel *panelTitle = [[UILabel alloc] initWithFrame:CGRectZero];
    panelTitle.translatesAutoresizingMaskIntoConstraints = NO;
    panelTitle.text = @"Studio";
    panelTitle.font = [UIFont systemFontOfSize:20 weight:UIFontWeightBold];
    panelTitle.textColor = [GMLThemeManager primaryTextColor];
    [panel addSubview:panelTitle];

    self.statusLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.statusLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.statusLabel.font = [UIFont systemFontOfSize:14 weight:UIFontWeightMedium];
    self.statusLabel.textColor = [GMLThemeManager tertiaryTextColor];
    self.statusLabel.numberOfLines = 0;
    self.statusLabel.text = @"Preparation du studio mobile...";
    [panel addSubview:self.statusLabel];

    self.reloadButton = [GMLUIFactory chromeButtonWithSymbol:@"arrow.clockwise" accessibility:@"Actualiser"];
    self.reloadButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.reloadButton addTarget:self action:@selector(reloadTapped) forControlEvents:UIControlEventTouchUpInside];
    [panel addSubview:self.reloadButton];

    self.settingsButton = [GMLUIFactory chromeButtonWithSymbol:@"slider.horizontal.3" accessibility:@"Parametres"];
    self.settingsButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.settingsButton addTarget:self action:@selector(toggleSettingsTapped) forControlEvents:UIControlEventTouchUpInside];
    [panel addSubview:self.settingsButton];

    self.toggleLogsButton = [GMLUIFactory chromeButtonWithSymbol:@"doc.text.magnifyingglass" accessibility:@"Logs"];
    self.toggleLogsButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.toggleLogsButton addTarget:self action:@selector(toggleLogsTapped) forControlEvents:UIControlEventTouchUpInside];
    [panel addSubview:self.toggleLogsButton];

    self.spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    self.spinner.translatesAutoresizingMaskIntoConstraints = NO;
    self.spinner.color = [UIColor colorWithRed:0.51 green:0.71 blue:1.0 alpha:1.0];
    [panel addSubview:self.spinner];

    // Settings summary as pill chips (replaces old settingsSummaryLabel + menuControl)
    self.settingsSummaryLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.settingsSummaryLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.settingsSummaryLabel.numberOfLines = 0;
    [panel addSubview:self.settingsSummaryLabel];

    self.clearLogsButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.clearLogsButton.translatesAutoresizingMaskIntoConstraints = NO;
    [self.clearLogsButton setTitle:@"Effacer logs" forState:UIControlStateNormal];
    [self.clearLogsButton setTitleColor:[UIColor colorWithRed:0.79 green:0.87 blue:1.0 alpha:1.0] forState:UIControlStateNormal];
    self.clearLogsButton.titleLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    [self.clearLogsButton addTarget:self action:@selector(clearLogs) forControlEvents:UIControlEventTouchUpInside];

    self.logTextView = [GMLUIFactory textViewWithMinHeight:150.0];
    self.logTextView.editable = NO;
    self.logTextView.selectable = YES;
    self.logTextView.text = @"Journal en attente...";

    self.providerControl = [[UISegmentedControl alloc] initWithItems:@[@"tempemail", @"mail.tm"]];
    self.providerControl.translatesAutoresizingMaskIntoConstraints = NO;
    self.providerControl.selectedSegmentIndex = 1;
    self.providerControl.backgroundColor = [UIColor colorWithRed:0.10 green:0.13 blue:0.19 alpha:1.0];
    self.providerControl.selectedSegmentTintColor = [UIColor colorWithRed:0.21 green:0.34 blue:0.62 alpha:1.0];
    [self.providerControl setTitleTextAttributes:@{ NSForegroundColorAttributeName: UIColor.whiteColor } forState:UIControlStateSelected];
    [self.providerControl setTitleTextAttributes:@{ NSForegroundColorAttributeName: [UIColor colorWithRed:0.83 green:0.88 blue:0.97 alpha:1.0] } forState:UIControlStateNormal];
    [self.providerControl addTarget:self action:@selector(providerChanged) forControlEvents:UIControlEventValueChanged];

    self.countField = [GMLUIFactory textFieldWithPlaceholder:@"5" delegate:self];
    self.countField.keyboardType = UIKeyboardTypeNumberPad;
    self.countField.inputAccessoryView = [GMLUIFactory numericAccessoryToolbarWithTarget:self action:@selector(numericDoneTapped)];
    self.countField.text = @"5";
    [self.countField addTarget:self action:@selector(settingsInputChanged) forControlEvents:UIControlEventEditingChanged];

    self.domainButton = [GMLUIFactory actionButton:@"Choisir domaine" primary:NO];
    [self.domainButton addTarget:self action:@selector(chooseDomainTapped) forControlEvents:UIControlEventTouchUpInside];

    self.prefixField = [GMLUIFactory textFieldWithPlaceholder:@"prefixe optionnel" delegate:self];
    [self.prefixField addTarget:self action:@selector(settingsInputChanged) forControlEvents:UIControlEventEditingChanged];
    self.delayField = [GMLUIFactory textFieldWithPlaceholder:@"3500" delegate:self];
    self.delayField.keyboardType = UIKeyboardTypeNumberPad;
    self.delayField.inputAccessoryView = [GMLUIFactory numericAccessoryToolbarWithTarget:self action:@selector(numericDoneTapped)];
    self.delayField.text = @"3500";
    [self.delayField addTarget:self action:@selector(settingsInputChanged) forControlEvents:UIControlEventEditingChanged];

    self.passwordModeControl = [[UISegmentedControl alloc] initWithItems:@[@"Aleatoire", @"Fixe"]];
    self.passwordModeControl.translatesAutoresizingMaskIntoConstraints = NO;
    self.passwordModeControl.selectedSegmentIndex = 0;
    self.passwordModeControl.backgroundColor = [UIColor colorWithRed:0.10 green:0.13 blue:0.19 alpha:1.0];
    self.passwordModeControl.selectedSegmentTintColor = [UIColor colorWithRed:0.21 green:0.34 blue:0.62 alpha:1.0];
    [self.passwordModeControl setTitleTextAttributes:@{ NSForegroundColorAttributeName: UIColor.whiteColor } forState:UIControlStateSelected];
    [self.passwordModeControl setTitleTextAttributes:@{ NSForegroundColorAttributeName: [UIColor colorWithRed:0.83 green:0.88 blue:0.97 alpha:1.0] } forState:UIControlStateNormal];
    [self.passwordModeControl addTarget:self action:@selector(updatePasswordMode) forControlEvents:UIControlEventValueChanged];

    self.fixedPasswordField = [GMLUIFactory textFieldWithPlaceholder:@"mot de passe fixe" delegate:self];
    self.fixedPasswordField.enabled = NO;
    [self.fixedPasswordField addTarget:self action:@selector(settingsInputChanged) forControlEvents:UIControlEventEditingChanged];
    [self.fixedPasswordField addTarget:self action:@selector(updatePasswordHint) forControlEvents:UIControlEventEditingChanged];

    self.fixedPasswordHint = [[UILabel alloc] initWithFrame:CGRectZero];
    self.fixedPasswordHint.translatesAutoresizingMaskIntoConstraints = NO;
    self.fixedPasswordHint.font = [UIFont systemFontOfSize:11 weight:UIFontWeightMedium];
    self.fixedPasswordHint.textColor = [UIColor colorWithRed:0.95 green:0.65 blue:0.30 alpha:1.0];
    self.fixedPasswordHint.numberOfLines = 0;
    self.fixedPasswordHint.text = @"";

    self.verifyLoginControl = [[UISegmentedControl alloc] initWithItems:@[@"Oui", @"Non"]];
    self.verifyLoginControl.translatesAutoresizingMaskIntoConstraints = NO;
    self.verifyLoginControl.selectedSegmentIndex = 0;
    self.verifyLoginControl.backgroundColor = [UIColor colorWithRed:0.10 green:0.13 blue:0.19 alpha:1.0];
    self.verifyLoginControl.selectedSegmentTintColor = [UIColor colorWithRed:0.21 green:0.34 blue:0.62 alpha:1.0];
    [self.verifyLoginControl setTitleTextAttributes:@{ NSForegroundColorAttributeName: UIColor.whiteColor } forState:UIControlStateSelected];
    [self.verifyLoginControl setTitleTextAttributes:@{ NSForegroundColorAttributeName: [UIColor colorWithRed:0.83 green:0.88 blue:0.97 alpha:1.0] } forState:UIControlStateNormal];
    [self.verifyLoginControl addTarget:self action:@selector(settingsInputChanged) forControlEvents:UIControlEventValueChanged];

    self.bulkTextView = [GMLUIFactory textViewWithMinHeight:120.0];
    self.bulkTextView.text = @"";
    self.bulkTextView.delegate = self;

    UIView *providerBlock = [GMLUIFactory fieldBlockWithTitle:@"Provider" control:self.providerControl];
    UIView *countBlock = [GMLUIFactory fieldBlockWithTitle:@"Nombre" control:self.countField];
    UIView *domainBlock = [GMLUIFactory fieldBlockWithTitle:@"Domaine" control:self.domainButton];
    UIView *prefixBlock = [GMLUIFactory fieldBlockWithTitle:@"Prefixe" control:self.prefixField];
    UIView *delayBlock = [GMLUIFactory fieldBlockWithTitle:@"Delai ms tempemail" control:self.delayField];
    UIView *passwordModeBlock = [GMLUIFactory fieldBlockWithTitle:@"Mode mot de passe" control:self.passwordModeControl];
    UIStackView *fixedPasswordStack = [[UIStackView alloc] initWithArrangedSubviews:@[self.fixedPasswordField, self.fixedPasswordHint]];
    fixedPasswordStack.translatesAutoresizingMaskIntoConstraints = NO;
    fixedPasswordStack.axis = UILayoutConstraintAxisVertical;
    fixedPasswordStack.spacing = 4;
    UIView *fixedPasswordBlock = [GMLUIFactory fieldBlockWithTitle:@"Mot de passe fixe" control:fixedPasswordStack];
    UIView *verifyBlock = [GMLUIFactory fieldBlockWithTitle:@"Verifier login" control:self.verifyLoginControl];
    UIView *bulkBlock = [GMLUIFactory fieldBlockWithTitle:@"Import comptes existants (email:motdepasse)" control:self.bulkTextView];

    BOOL compact = [self isCompactPhoneLayout];
    UIStackView *row1 = [GMLUIFactory horizontalStack:@[providerBlock, countBlock] compact:compact];
    UIStackView *row2 = [GMLUIFactory horizontalStack:@[domainBlock, prefixBlock] compact:compact];
    UIStackView *row3 = [GMLUIFactory horizontalStack:@[delayBlock, passwordModeBlock] compact:compact];
    UIStackView *row4 = [GMLUIFactory horizontalStack:@[fixedPasswordBlock, verifyBlock] compact:compact];

    self.loadDomainsButton = [GMLUIFactory actionButton:@"Charger domaines" primary:NO];
    [self.loadDomainsButton addTarget:self action:@selector(loadDomainsTapped) forControlEvents:UIControlEventTouchUpInside];
    self.generateButton = [GMLUIFactory gradientButton:@"Generer"];
    [self.generateButton addTarget:self action:@selector(generateTapped) forControlEvents:UIControlEventTouchUpInside];
    self.importButton = [GMLUIFactory actionButton:@"Importer" primary:NO];
    [self.importButton addTarget:self action:@selector(importTapped) forControlEvents:UIControlEventTouchUpInside];
    self.loginAllButton = [GMLUIFactory actionButton:@"Login all" primary:NO];
    [self.loginAllButton addTarget:self action:@selector(loginAllTapped) forControlEvents:UIControlEventTouchUpInside];
    self.refreshButton = [GMLUIFactory actionButton:@"Rafraichir liste" primary:NO];
    [self.refreshButton addTarget:self action:@selector(refreshTapped) forControlEvents:UIControlEventTouchUpInside];
    self.pasteImportButton = [GMLUIFactory actionButton:@"Coller import" primary:NO];
    [self.pasteImportButton addTarget:self action:@selector(pasteImportTapped) forControlEvents:UIControlEventTouchUpInside];
    self.exportCopyButton = [GMLUIFactory actionButton:@"Copier export" primary:NO];
    [self.exportCopyButton addTarget:self action:@selector(copyExportTapped) forControlEvents:UIControlEventTouchUpInside];
    self.outputCopyButton = [GMLUIFactory actionButton:@"Copier sortie" primary:NO];
    [self.outputCopyButton addTarget:self action:@selector(copyOutputTapped) forControlEvents:UIControlEventTouchUpInside];

    self.circularProgress = [GMLUIFactory circularProgress];
    self.circularProgress.hidden = YES;

    self.exportTextView = [GMLUIFactory textViewWithMinHeight:110.0];
    self.exportTextView.editable = NO;
    self.exportTextView.selectable = YES;
    self.exportTextView.text = @"Aucune generation pour le moment.";

    self.selectionLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    self.selectionLabel.translatesAutoresizingMaskIntoConstraints = NO;
    self.selectionLabel.font = [UIFont systemFontOfSize:13 weight:UIFontWeightSemibold];
    self.selectionLabel.textColor = [UIColor colorWithRed:0.83 green:0.88 blue:0.97 alpha:1.0];
    self.selectionLabel.numberOfLines = 0;
    self.selectionLabel.text = @"Aucun compte selectionne";

    self.selectedCopyButton = [GMLUIFactory actionButton:@"Copier selection" primary:NO];
    [self.selectedCopyButton addTarget:self action:@selector(copySelectedTapped) forControlEvents:UIControlEventTouchUpInside];
    self.selectedMailCopyButton = [GMLUIFactory actionButton:@"Copier mail" primary:NO];
    [self.selectedMailCopyButton addTarget:self action:@selector(copySelectedMailTapped) forControlEvents:UIControlEventTouchUpInside];
    self.selectedPasswordCopyButton = [GMLUIFactory actionButton:@"Copier mdp" primary:NO];
    [self.selectedPasswordCopyButton addTarget:self action:@selector(copySelectedPasswordTapped) forControlEvents:UIControlEventTouchUpInside];
    self.messagesSelectedButton = [GMLUIFactory actionButton:@"Messages selection" primary:NO];
    [self.messagesSelectedButton addTarget:self action:@selector(messagesSelectedTapped) forControlEvents:UIControlEventTouchUpInside];
    self.deleteSelectedButton = [GMLUIFactory actionButton:@"Suppr selection" primary:NO];
    [self.deleteSelectedButton addTarget:self action:@selector(deleteSelectedTapped) forControlEvents:UIControlEventTouchUpInside];
    self.accountsTableView = [[UITableView alloc] initWithFrame:CGRectZero style:UITableViewStyleInsetGrouped];
    self.accountsTableView.translatesAutoresizingMaskIntoConstraints = NO;
    self.accountsTableView.dataSource = self;
    self.accountsTableView.delegate = self;
    self.accountsTableView.backgroundColor = [UIColor colorWithRed:0.06 green:0.08 blue:0.12 alpha:1.0];
    self.accountsTableView.layer.cornerRadius = 16.0;
    self.accountsTableView.rowHeight = 80.0;
    self.accountsTableView.separatorColor = [UIColor colorWithRed:0.18 green:0.23 blue:0.32 alpha:1.0];
    self.accountsTableView.scrollEnabled = YES;

    self.outputTextView = [GMLUIFactory textViewWithMinHeight:150.0];
    self.outputTextView.editable = NO;
    self.outputTextView.selectable = YES;
    self.outputTextView.text = @"Pret.";

    UIStackView *settingsActionsTop = [GMLUIFactory horizontalStack:@[self.loadDomainsButton, self.importButton, self.pasteImportButton] compact:compact];
    UIStackView *settingsActionsBottom = [GMLUIFactory horizontalStack:@[self.loginAllButton] compact:compact];

    // ── Parametres avances (presented as modal sheet) ──
    self.settingsCard = [[UIView alloc] init];
    self.settingsCard.hidden = YES; // not inline — modal only
    UIView *settingsHeader = [self sectionHeaderWithIcon:@"slider.horizontal.3" title:@"Parametres avances" color:[UIColor colorWithRed:0.55 green:0.45 blue:0.95 alpha:1.0]];
    UILabel *settingsHint = [self hintLabel:@"Provider, domaine, import et mode de mot de passe."];
    UIView *settingsDivider = [self thinDivider];
    UIButton *applyButton = [GMLUIFactory actionButton:@"Appliquer" primary:YES];
    [applyButton addTarget:self action:@selector(dismissSettingsSheet) forControlEvents:UIControlEventTouchUpInside];
    UIStackView *settingsStack = [[UIStackView alloc] initWithArrangedSubviews:@[settingsHeader, settingsHint, settingsDivider, row1, row2, row3, row4, bulkBlock, settingsActionsTop, settingsActionsBottom, applyButton]];
    settingsStack.translatesAutoresizingMaskIntoConstraints = NO;
    settingsStack.axis = UILayoutConstraintAxisVertical;
    settingsStack.spacing = 10.0;
    [settingsStack setCustomSpacing:6 afterView:settingsHeader];
    [settingsStack setCustomSpacing:14 afterView:settingsDivider];
    [settingsStack setCustomSpacing:16 afterView:settingsActionsBottom];
    self.settingsContentStack = settingsStack;

    // ── Studio de generation ──
    self.generationSection = [GMLCardView card];
    UIView *genHeader = [self sectionHeaderWithIcon:@"wand.and.stars" title:@"Studio de generation" color:[UIColor colorWithRed:0.30 green:0.60 blue:1.0 alpha:1.0]];
    UILabel *genHint = [self hintLabel:@"Generez des comptes temporaires en un clic."];
    UIView *genDivider = [self thinDivider];
    [self.generateButton.heightAnchor constraintEqualToConstant:56].active = YES;
    // Generate button full-width (alone on its row)
    UILabel *latestTitle = [GMLUIFactory sectionTitle:@"Derniere generation"];
    [self.exportTextView.heightAnchor constraintEqualToConstant:100].active = YES;
    // Copier export below the result text (contextual)
    UIStackView *resultActions = [GMLUIFactory horizontalStack:@[self.exportCopyButton] compact:compact];
    UIStackView *genStack = [[UIStackView alloc] initWithArrangedSubviews:@[genHeader, genHint, genDivider, self.generateButton, self.circularProgress, latestTitle, self.exportTextView, resultActions]];
    genStack.translatesAutoresizingMaskIntoConstraints = NO;
    genStack.axis = UILayoutConstraintAxisVertical;
    genStack.spacing = 12.0;
    [genStack setCustomSpacing:6 afterView:genHeader];
    [genStack setCustomSpacing:14 afterView:genDivider];
    [genStack setCustomSpacing:20 afterView:self.generateButton];
    [genStack setCustomSpacing:16 afterView:self.circularProgress];
    [genStack setCustomSpacing:8 afterView:self.exportTextView];
    self.circularProgress.hidden = YES;
    [self.generationSection addSubview:genStack];

    // ── Comptes ──
    self.accountsSection = [GMLCardView card];
    UIView *acctHeader = [self sectionHeaderWithIcon:@"person.crop.rectangle.stack" title:@"Comptes" color:[UIColor colorWithRed:0.25 green:0.78 blue:0.55 alpha:1.0]];
    UILabel *acctHint = [self hintLabel:@"Tap pour selectionner. Recents en premier."];
    UIView *acctDivider = [self thinDivider];
    // Selection actions — hidden until account selected
    UIStackView *selectionActions = [GMLUIFactory horizontalStack:@[self.selectedCopyButton, self.messagesSelectedButton, self.deleteSelectedButton] compact:compact];
    UIStackView *selectionActionsSecondary = [GMLUIFactory horizontalStack:@[self.selectedMailCopyButton, self.selectedPasswordCopyButton] compact:compact];
    selectionActions.hidden = YES;
    selectionActionsSecondary.hidden = YES;
    self.selectionLabel.hidden = YES;
    // Store refs for show/hide in updateSelectionUI
    self.selectionActionsRow = selectionActions;
    self.selectionActionsSecondaryRow = selectionActionsSecondary;
    // Refresh as standalone action row
    UIStackView *acctToolbar = [GMLUIFactory horizontalStack:@[self.refreshButton] compact:compact];
    [self.accountsTableView.heightAnchor constraintEqualToConstant:220].active = YES;
    UIStackView *acctStack = [[UIStackView alloc] initWithArrangedSubviews:@[acctHeader, acctHint, acctDivider, acctToolbar, self.selectionLabel, selectionActions, selectionActionsSecondary, self.accountsTableView]];
    acctStack.translatesAutoresizingMaskIntoConstraints = NO;
    acctStack.axis = UILayoutConstraintAxisVertical;
    acctStack.spacing = 10.0;
    [acctStack setCustomSpacing:6 afterView:acctHeader];
    [acctStack setCustomSpacing:14 afterView:acctDivider];
    [self.accountsSection addSubview:acctStack];

    // ── Console (presented as modal sheet) ──
    self.outputSection = [[UIView alloc] init];
    self.outputSection.hidden = YES; // not inline — modal only
    UIView *consoleHeader = [self sectionHeaderWithIcon:@"terminal" title:@"Console" color:[UIColor colorWithRed:0.95 green:0.60 blue:0.25 alpha:1.0]];

    self.consoleTabControl = [[UISegmentedControl alloc] initWithItems:@[@"Sortie API", @"Journal"]];
    self.consoleTabControl.translatesAutoresizingMaskIntoConstraints = NO;
    self.consoleTabControl.selectedSegmentIndex = 0;
    self.consoleTabControl.backgroundColor = [UIColor colorWithRed:0.10 green:0.13 blue:0.19 alpha:1.0];
    self.consoleTabControl.selectedSegmentTintColor = [UIColor colorWithRed:0.21 green:0.34 blue:0.62 alpha:1.0];
    [self.consoleTabControl setTitleTextAttributes:@{ NSForegroundColorAttributeName: UIColor.whiteColor, NSFontAttributeName: [UIFont systemFontOfSize:12 weight:UIFontWeightSemibold] } forState:UIControlStateSelected];
    [self.consoleTabControl setTitleTextAttributes:@{ NSForegroundColorAttributeName: [UIColor colorWithRed:0.65 green:0.72 blue:0.88 alpha:1.0], NSFontAttributeName: [UIFont systemFontOfSize:12 weight:UIFontWeightMedium] } forState:UIControlStateNormal];
    [self.consoleTabControl addTarget:self action:@selector(consoleTabChanged) forControlEvents:UIControlEventValueChanged];

    UIView *consoleDivider = [self thinDivider];
    UIStackView *consoleActions = [GMLUIFactory horizontalStack:@[self.outputCopyButton, self.clearLogsButton] compact:compact];
    // Large heights for modal display — fills most of the sheet
    [self.outputTextView.heightAnchor constraintGreaterThanOrEqualToConstant:400].active = YES;
    [self.logTextView.heightAnchor constraintGreaterThanOrEqualToConstant:400].active = YES;
    self.logTextView.hidden = YES;
    self.clearLogsButton.hidden = YES;

    UIStackView *consoleStack = [[UIStackView alloc] initWithArrangedSubviews:@[consoleHeader, self.consoleTabControl, consoleDivider, consoleActions, self.outputTextView, self.logTextView]];
    consoleStack.translatesAutoresizingMaskIntoConstraints = NO;
    consoleStack.axis = UILayoutConstraintAxisVertical;
    consoleStack.spacing = 10.0;
    [consoleStack setCustomSpacing:6 afterView:consoleHeader];
    [consoleStack setCustomSpacing:14 afterView:consoleDivider];
    self.consoleContentStack = consoleStack;

    self.logsSection = [[UIView alloc] init];
    self.logsSection.hidden = YES;

    // Comptes section removed — use dedicated Comptes tab
    self.accountsSection = [[UIView alloc] init];
    self.accountsSection.hidden = YES;

    // ── Only generation section remains inline ──
    UIStackView *sectionsStack = [[UIStackView alloc] initWithArrangedSubviews:@[self.generationSection]];
    sectionsStack.translatesAutoresizingMaskIntoConstraints = NO;
    sectionsStack.axis = UILayoutConstraintAxisVertical;
    sectionsStack.spacing = 12;
    [content addSubview:sectionsStack];

    CGFloat pad = 16;
    CGFloat innerPad = 18;

    [NSLayoutConstraint activateConstraints:@[
        // Scroll view fills safe area
        [scrollView.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor],
        [scrollView.leadingAnchor constraintEqualToAnchor:self.view.leadingAnchor],
        [scrollView.trailingAnchor constraintEqualToAnchor:self.view.trailingAnchor],
        [scrollView.bottomAnchor constraintEqualToAnchor:self.view.bottomAnchor],

        [content.topAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.topAnchor constant:12],
        [content.leadingAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.leadingAnchor constant:pad],
        [content.trailingAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.trailingAnchor constant:-pad],
        [content.bottomAnchor constraintEqualToAnchor:scrollView.contentLayoutGuide.bottomAnchor constant:-20],
        [content.widthAnchor constraintEqualToAnchor:scrollView.frameLayoutGuide.widthAnchor constant:-pad*2],

        // ── Toolbar Card ──
        [panel.topAnchor constraintEqualToAnchor:content.topAnchor],
        [panel.leadingAnchor constraintEqualToAnchor:content.leadingAnchor],
        [panel.trailingAnchor constraintEqualToAnchor:content.trailingAnchor],

        [panelTitle.topAnchor constraintEqualToAnchor:panel.topAnchor constant:pad],
        [panelTitle.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:innerPad],

        [self.spinner.centerYAnchor constraintEqualToAnchor:panelTitle.centerYAnchor],
        [self.spinner.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-innerPad],

        [self.toggleLogsButton.centerYAnchor constraintEqualToAnchor:panelTitle.centerYAnchor],
        [self.toggleLogsButton.trailingAnchor constraintEqualToAnchor:self.spinner.leadingAnchor constant:-8],

        [self.settingsButton.centerYAnchor constraintEqualToAnchor:panelTitle.centerYAnchor],
        [self.settingsButton.trailingAnchor constraintEqualToAnchor:self.toggleLogsButton.leadingAnchor constant:-8],

        [self.reloadButton.centerYAnchor constraintEqualToAnchor:panelTitle.centerYAnchor],
        [self.reloadButton.trailingAnchor constraintEqualToAnchor:self.settingsButton.leadingAnchor constant:-8],

        [self.statusLabel.topAnchor constraintEqualToAnchor:panelTitle.bottomAnchor constant:6],
        [self.statusLabel.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:innerPad],
        [self.statusLabel.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-innerPad],

        [self.settingsSummaryLabel.topAnchor constraintEqualToAnchor:self.statusLabel.bottomAnchor constant:10],
        [self.settingsSummaryLabel.leadingAnchor constraintEqualToAnchor:panel.leadingAnchor constant:innerPad],
        [self.settingsSummaryLabel.trailingAnchor constraintEqualToAnchor:panel.trailingAnchor constant:-innerPad],
        [self.settingsSummaryLabel.bottomAnchor constraintEqualToAnchor:panel.bottomAnchor constant:-pad],

        // ── Sections Stack ──
        [sectionsStack.topAnchor constraintEqualToAnchor:panel.bottomAnchor constant:12],
        [sectionsStack.leadingAnchor constraintEqualToAnchor:content.leadingAnchor],
        [sectionsStack.trailingAnchor constraintEqualToAnchor:content.trailingAnchor],
        [sectionsStack.bottomAnchor constraintEqualToAnchor:content.bottomAnchor],

        // ── Generation Section (inner stack) ──
        [genStack.topAnchor constraintEqualToAnchor:self.generationSection.topAnchor constant:pad],
        [genStack.leadingAnchor constraintEqualToAnchor:self.generationSection.leadingAnchor constant:innerPad],
        [genStack.trailingAnchor constraintEqualToAnchor:self.generationSection.trailingAnchor constant:-innerPad],
        [genStack.bottomAnchor constraintEqualToAnchor:self.generationSection.bottomAnchor constant:-pad]
    ]];

    [self updatePasswordMode];
    [self updateSelectionUI];
    [self updateSettingsSummary];
    [self updateSettingsVisibility];
    [self updateMenuVisibility];
    [self appendLog:[NSString stringWithFormat:@"Application initialisee. Stockage local: %@", [[GMLAccountStore shared] storageDirectory]] level:@"INFO"];
    [self bootstrapNativeInterface];
}

- (UIView *)sectionHeaderWithIcon:(NSString *)iconName title:(NSString *)title color:(UIColor *)color {
    UIView *header = [[UIView alloc] initWithFrame:CGRectZero];
    header.translatesAutoresizingMaskIntoConstraints = NO;

    UIImageSymbolConfiguration *cfg = [UIImageSymbolConfiguration configurationWithPointSize:14 weight:UIImageSymbolWeightSemibold];
    UIImageView *icon = [[UIImageView alloc] initWithImage:[UIImage systemImageNamed:iconName withConfiguration:cfg]];
    icon.translatesAutoresizingMaskIntoConstraints = NO;
    icon.tintColor = color;
    icon.contentMode = UIViewContentModeScaleAspectFit;

    UIView *iconBg = [[UIView alloc] initWithFrame:CGRectZero];
    iconBg.translatesAutoresizingMaskIntoConstraints = NO;
    iconBg.backgroundColor = [color colorWithAlphaComponent:0.15];
    iconBg.layer.cornerRadius = 8;
    [iconBg addSubview:icon];

    UILabel *titleLabel = [[UILabel alloc] initWithFrame:CGRectZero];
    titleLabel.translatesAutoresizingMaskIntoConstraints = NO;
    titleLabel.text = title;
    titleLabel.font = [UIFont systemFontOfSize:17 weight:UIFontWeightBold];
    titleLabel.textColor = [GMLThemeManager primaryTextColor];

    [header addSubview:iconBg];
    [header addSubview:titleLabel];

    [NSLayoutConstraint activateConstraints:@[
        [iconBg.leadingAnchor constraintEqualToAnchor:header.leadingAnchor],
        [iconBg.centerYAnchor constraintEqualToAnchor:header.centerYAnchor],
        [iconBg.widthAnchor constraintEqualToConstant:30],
        [iconBg.heightAnchor constraintEqualToConstant:30],
        [icon.centerXAnchor constraintEqualToAnchor:iconBg.centerXAnchor],
        [icon.centerYAnchor constraintEqualToAnchor:iconBg.centerYAnchor],
        [titleLabel.leadingAnchor constraintEqualToAnchor:iconBg.trailingAnchor constant:10],
        [titleLabel.centerYAnchor constraintEqualToAnchor:header.centerYAnchor],
        [titleLabel.trailingAnchor constraintLessThanOrEqualToAnchor:header.trailingAnchor],
        [header.heightAnchor constraintEqualToConstant:34]
    ]];
    return header;
}

- (UILabel *)hintLabel:(NSString *)text {
    UILabel *hint = [[UILabel alloc] initWithFrame:CGRectZero];
    hint.translatesAutoresizingMaskIntoConstraints = NO;
    hint.text = text;
    hint.font = [UIFont systemFontOfSize:13 weight:UIFontWeightMedium];
    hint.textColor = [UIColor colorWithRed:0.55 green:0.60 blue:0.72 alpha:1.0];
    hint.numberOfLines = 0;
    return hint;
}

- (UIView *)thinDivider {
    UIView *div = [[UIView alloc] initWithFrame:CGRectZero];
    div.translatesAutoresizingMaskIntoConstraints = NO;
    div.backgroundColor = [UIColor colorWithRed:0.18 green:0.22 blue:0.30 alpha:0.6];
    [div.heightAnchor constraintEqualToConstant:0.5].active = YES;
    return div;
}

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    [self installLogoInLargeTitle];
}

- (void)installLogoInLargeTitle {
    // Find the large title label in the navigation bar hierarchy
    UINavigationBar *navBar = self.navigationController.navigationBar;
    if (!navBar) return;

    // Avoid adding multiple times
    if ([navBar viewWithTag:9999]) return;

    UIView *largeTitleView = [self findLargeTitleViewIn:navBar];
    if (!largeTitleView) return;

    // Find the existing large title UILabel
    UILabel *titleLabel = nil;
    for (UIView *sub in largeTitleView.subviews) {
        if ([sub isKindOfClass:[UILabel class]]) {
            titleLabel = (UILabel *)sub;
            break;
        }
    }
    if (!titleLabel) return;

    // Hide default text — we replace it
    titleLabel.hidden = YES;

    // Create logo container
    UIView *logoContainer = [[UIView alloc] initWithFrame:CGRectZero];
    logoContainer.translatesAutoresizingMaskIntoConstraints = NO;
    logoContainer.tag = 9999;
    [largeTitleView addSubview:logoContainer];

    // Logo image
    NSString *logoPath = [[NSBundle mainBundle] pathForResource:@"genmail-logo" ofType:@"png"];
    UIImage *logoImage = [UIImage imageWithContentsOfFile:logoPath];
    UIImageView *logoIV = [[UIImageView alloc] initWithImage:logoImage];
    logoIV.translatesAutoresizingMaskIntoConstraints = NO;
    logoIV.contentMode = UIViewContentModeScaleAspectFit;
    logoIV.layer.cornerRadius = 10;
    logoIV.clipsToBounds = YES;
    [logoContainer addSubview:logoIV];

    // Title text
    UILabel *customTitle = [[UILabel alloc] initWithFrame:CGRectZero];
    customTitle.translatesAutoresizingMaskIntoConstraints = NO;
    customTitle.text = @"GenMail";
    customTitle.font = [UIFont systemFontOfSize:34 weight:UIFontWeightBold];
    customTitle.textColor = [GMLThemeManager primaryTextColor];
    [logoContainer addSubview:customTitle];

    // Version badge
    UILabel *badge = [[UILabel alloc] initWithFrame:CGRectZero];
    badge.translatesAutoresizingMaskIntoConstraints = NO;
    NSString *bundleVer = [NSBundle mainBundle].infoDictionary[@"CFBundleShortVersionString"] ?: @"?";
    badge.text = [@"v" stringByAppendingString:bundleVer];
    badge.font = [UIFont systemFontOfSize:11 weight:UIFontWeightBold];
    badge.textColor = [GMLThemeManager accentTextColor];
    badge.backgroundColor = [UIColor colorWithRed:0.15 green:0.25 blue:0.50 alpha:0.5];
    badge.textAlignment = NSTextAlignmentCenter;
    badge.layer.cornerRadius = 8;
    badge.clipsToBounds = YES;
    UIEdgeInsets badgeInsets = UIEdgeInsetsMake(2, 8, 2, 8);
    badge.layoutMargins = badgeInsets;
    [logoContainer addSubview:badge];

    [NSLayoutConstraint activateConstraints:@[
        [logoContainer.leadingAnchor constraintEqualToAnchor:largeTitleView.leadingAnchor],
        [logoContainer.centerYAnchor constraintEqualToAnchor:titleLabel.centerYAnchor],

        [logoIV.leadingAnchor constraintEqualToAnchor:logoContainer.leadingAnchor],
        [logoIV.centerYAnchor constraintEqualToAnchor:logoContainer.centerYAnchor],
        [logoIV.widthAnchor constraintEqualToConstant:38],
        [logoIV.heightAnchor constraintEqualToConstant:38],

        [customTitle.leadingAnchor constraintEqualToAnchor:logoIV.trailingAnchor constant:10],
        [customTitle.centerYAnchor constraintEqualToAnchor:logoContainer.centerYAnchor],

        [badge.leadingAnchor constraintEqualToAnchor:customTitle.trailingAnchor constant:8],
        [badge.centerYAnchor constraintEqualToAnchor:logoContainer.centerYAnchor constant:2],
        [badge.trailingAnchor constraintLessThanOrEqualToAnchor:logoContainer.trailingAnchor],
        [badge.heightAnchor constraintEqualToConstant:20],
        [badge.widthAnchor constraintGreaterThanOrEqualToConstant:44],

        [logoContainer.topAnchor constraintEqualToAnchor:logoIV.topAnchor],
        [logoContainer.bottomAnchor constraintEqualToAnchor:logoIV.bottomAnchor]
    ]];
}

- (UIView *)findLargeTitleViewIn:(UIView *)view {
    NSString *className = NSStringFromClass([view class]);
    if ([className containsString:@"LargeTitle"] && [className containsString:@"View"]) {
        return view;
    }
    for (UIView *sub in view.subviews) {
        UIView *found = [self findLargeTitleViewIn:sub];
        if (found) return found;
    }
    return nil;
}

- (void)dealloc {
    [self.progressTimer invalidate];
}

#pragma mark - Native UI

- (void)numericDoneTapped {
    [self.view endEditing:YES];
    [self settingsInputChanged];
}


- (BOOL)isCompactPhoneLayout {
    return UIScreen.mainScreen.bounds.size.width <= 430.0;
}

- (void)menuChanged {
    // No-op: segmented control removed — all sections always visible
}

- (void)toggleSettingsTapped {
    [self presentSettingsSheet];
}

- (void)dismissSettingsSheet {
    [self dismissViewControllerAnimated:YES completion:^{
        [self updateSettingsSummary];
    }];
}

- (void)presentSettingsSheet {
    UIViewController *sheetVC = [[UIViewController alloc] init];
    sheetVC.view.backgroundColor = [GMLThemeManager backgroundColor];

    UIScrollView *scroll = [[UIScrollView alloc] initWithFrame:CGRectZero];
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    scroll.alwaysBounceVertical = YES;
    [sheetVC.view addSubview:scroll];

    // Reparent settingsContentStack into this sheet
    [self.settingsContentStack removeFromSuperview];
    [scroll addSubview:self.settingsContentStack];

    [NSLayoutConstraint activateConstraints:@[
        [scroll.topAnchor constraintEqualToAnchor:sheetVC.view.safeAreaLayoutGuide.topAnchor],
        [scroll.leadingAnchor constraintEqualToAnchor:sheetVC.view.leadingAnchor],
        [scroll.trailingAnchor constraintEqualToAnchor:sheetVC.view.trailingAnchor],
        [scroll.bottomAnchor constraintEqualToAnchor:sheetVC.view.bottomAnchor],
        [self.settingsContentStack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:20],
        [self.settingsContentStack.leadingAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.leadingAnchor constant:18],
        [self.settingsContentStack.trailingAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.trailingAnchor constant:-18],
        [self.settingsContentStack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-20]
    ]];

    sheetVC.modalPresentationStyle = UIModalPresentationPageSheet;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability-new"
    if ([sheetVC respondsToSelector:@selector(sheetPresentationController)]) {
        UISheetPresentationController *sheet = sheetVC.sheetPresentationController;
        sheet.detents = @[UISheetPresentationControllerDetent.mediumDetent, UISheetPresentationControllerDetent.largeDetent];
        sheet.prefersGrabberVisible = YES;
        sheet.preferredCornerRadius = 20;
    }
#pragma clang diagnostic pop
    [self presentViewController:sheetVC animated:YES completion:nil];
}

- (void)settingsInputChanged {
    [self updateSettingsSummary];
}

- (void)updateSettingsVisibility {
    // Settings is now a modal sheet — no inline visibility to update
}

- (void)updateMenuVisibility {
    // Only generation section is inline
    self.generationSection.hidden = NO;
}

- (NSAttributedString *)pillString:(NSString *)text {
    NSDictionary *attrs = @{
        NSFontAttributeName: [UIFont systemFontOfSize:11 weight:UIFontWeightBold],
        NSForegroundColorAttributeName: [UIColor colorWithRed:0.65 green:0.75 blue:0.95 alpha:1.0],
        NSBackgroundColorAttributeName: [UIColor colorWithRed:0.15 green:0.20 blue:0.32 alpha:1.0]
    };
    return [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"  %@  ", text] attributes:attrs];
}

- (void)updateSettingsSummary {
    NSString *provider = self.providerControl.selectedSegmentIndex == 0 ? @"tempemail" : @"mail.tm";
    NSString *domain = [self currentDomain];
    NSString *count = [[GMLAccountStore shared] stringValue:self.countField.text fallback:@"5"];
    NSString *passwordMode = self.passwordModeControl.selectedSegmentIndex == 1 ? @"fixe" : @"aleatoire";
    NSString *verify = self.verifyLoginControl.selectedSegmentIndex == 0 ? @"login" : @"no-login";

    NSMutableAttributedString *summary = [[NSMutableAttributedString alloc] init];
    NSDictionary *spaceAttrs = @{ NSFontAttributeName: [UIFont systemFontOfSize:6] };
    NSAttributedString *space = [[NSAttributedString alloc] initWithString:@"  " attributes:spaceAttrs];

    [summary appendAttributedString:[self pillString:provider]];
    [summary appendAttributedString:space];
    [summary appendAttributedString:[self pillString:[NSString stringWithFormat:@"%@ comptes", count.length ? count : @"5"]]];
    [summary appendAttributedString:space];
    [summary appendAttributedString:[self pillString:[NSString stringWithFormat:@"mdp: %@", passwordMode]]];
    [summary appendAttributedString:space];
    [summary appendAttributedString:[self pillString:verify]];
    if (domain.length) {
        [summary appendAttributedString:space];
        [summary appendAttributedString:[self pillString:domain]];
    }

    self.settingsSummaryLabel.attributedText = summary;
}

- (void)bootstrapNativeInterface {
    NSLog(@"[GenMail] bootstrapNativeInterface called");
    self.statusLabel.text = @"Interface native prete. Chargement des domaines et des comptes...";
    [self beginAction:@"Initialisation"];
    [self loadDomainsNativeWithCompletion:^{
        [self endAction:@"Domaines charges"];
    }];
    [self beginAction:@"Chargement comptes"];
    [self refreshAccountsNativeWithCompletion:^{
        [self endAction:@"Comptes synchronises"];
    }];
}

- (NSString *)providerKey {
    return self.providerControl.selectedSegmentIndex == 0 ? @"tempemail" : @"mailtm";
}

- (NSString *)currentDomain {
    NSString *title = [self.domainButton titleForState:UIControlStateNormal] ?: @"";
    if ([title isEqualToString:@"Choisir domaine"] || [title isEqualToString:@"Aucun domaine"]) return @"";
    return title;
}

- (void)providerChanged {
    self.selectedAccount = nil;
    self.pendingGeneratedAccounts = @[];
    [self updateSelectionUI];
    [self updatePasswordHint];
    [self updateSettingsSummary];
    [self beginAction:@"Changement provider"];
    [self loadDomainsNativeWithCompletion:^{
        [self endAction:@"Domaines mis a jour"];
    }];
    [self beginAction:@"Rafraichissement comptes"];
    [self refreshAccountsNativeWithCompletion:^{
        [self endAction:@"Comptes mis a jour"];
    }];
}

- (void)reloadTapped {
    [self appendLog:@"Recharge native demandee." level:@"INFO"];
    [self refreshTapped];
}

- (void)updatePasswordMode {
    BOOL fixed = self.passwordModeControl.selectedSegmentIndex == 1;
    self.fixedPasswordField.enabled = fixed;
    self.fixedPasswordField.alpha = fixed ? 1.0 : 0.5;
    [self updatePasswordHint];
    [self updateSettingsSummary];
}

- (void)updatePasswordHint {
    if (!self.fixedPasswordHint) return;
    BOOL fixed = self.passwordModeControl.selectedSegmentIndex == 1;
    BOOL isTempemail = self.providerControl.selectedSegmentIndex == 0;
    NSString *pw = self.fixedPasswordField.text ?: @"";
    if (!fixed || !isTempemail || pw.length == 0) {
        self.fixedPasswordHint.text = @"";
        return;
    }
    NSCharacterSet *digits = [NSCharacterSet decimalDigitCharacterSet];
    if ([pw rangeOfCharacterFromSet:digits].location == NSNotFound) {
        self.fixedPasswordHint.text = @"⚠ tempemail.cc exige ≥1 chiffre — un chiffre sera ajoute automatiquement";
    } else {
        self.fixedPasswordHint.text = @"";
    }
}

- (void)consoleTabChanged {
    BOOL showLogs = self.consoleTabControl.selectedSegmentIndex == 1;
    self.logTextView.hidden = !showLogs;
    self.outputTextView.hidden = showLogs;
    self.clearLogsButton.hidden = !showLogs;
    self.outputCopyButton.hidden = showLogs;
}

- (void)toggleLogsTapped {
    [self presentConsoleSheet];
}

- (void)presentConsoleSheet {
    UIViewController *sheetVC = [[UIViewController alloc] init];
    sheetVC.view.backgroundColor = [GMLThemeManager backgroundColor];

    UIScrollView *scroll = [[UIScrollView alloc] initWithFrame:CGRectZero];
    scroll.translatesAutoresizingMaskIntoConstraints = NO;
    scroll.alwaysBounceVertical = YES;
    [sheetVC.view addSubview:scroll];

    // Reparent consoleContentStack into this sheet's scroll view
    [self.consoleContentStack removeFromSuperview];
    [scroll addSubview:self.consoleContentStack];

    [NSLayoutConstraint activateConstraints:@[
        [scroll.topAnchor constraintEqualToAnchor:sheetVC.view.safeAreaLayoutGuide.topAnchor],
        [scroll.leadingAnchor constraintEqualToAnchor:sheetVC.view.leadingAnchor],
        [scroll.trailingAnchor constraintEqualToAnchor:sheetVC.view.trailingAnchor],
        [scroll.bottomAnchor constraintEqualToAnchor:sheetVC.view.bottomAnchor],
        [self.consoleContentStack.topAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.topAnchor constant:20],
        [self.consoleContentStack.leadingAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.leadingAnchor constant:18],
        [self.consoleContentStack.trailingAnchor constraintEqualToAnchor:scroll.frameLayoutGuide.trailingAnchor constant:-18],
        [self.consoleContentStack.bottomAnchor constraintEqualToAnchor:scroll.contentLayoutGuide.bottomAnchor constant:-20]
    ]];

    // Ensure the active text view is visible and has proper height
    [self consoleTabChanged];

    sheetVC.modalPresentationStyle = UIModalPresentationPageSheet;
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunguarded-availability-new"
    if ([sheetVC respondsToSelector:@selector(sheetPresentationController)]) {
        UISheetPresentationController *sheet = sheetVC.sheetPresentationController;
        sheet.detents = @[UISheetPresentationControllerDetent.mediumDetent, UISheetPresentationControllerDetent.largeDetent];
        sheet.prefersGrabberVisible = YES;
        sheet.preferredCornerRadius = 20;
    }
#pragma clang diagnostic pop
    [self presentViewController:sheetVC animated:YES completion:nil];
}

- (void)updateLogVisibility {
    // Console is a modal — nothing to update inline
}

- (void)dismissKeyboardTapped {
    [self.view endEditing:YES];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    [self settingsInputChanged];
    return YES;
}

- (void)setControlsEnabled:(BOOL)enabled {
    self.reloadButton.enabled = enabled;
    self.settingsButton.enabled = enabled;

    self.providerControl.enabled = enabled;
    self.countField.enabled = enabled;
    self.domainButton.enabled = enabled;
    self.prefixField.enabled = enabled;
    self.delayField.enabled = enabled;
    self.passwordModeControl.enabled = enabled;
    self.fixedPasswordField.enabled = enabled && self.passwordModeControl.selectedSegmentIndex == 1;
    self.verifyLoginControl.enabled = enabled;
    self.bulkTextView.editable = enabled;
    self.loadDomainsButton.enabled = enabled;
    self.generateButton.enabled = enabled;
    self.importButton.enabled = enabled;
    self.loginAllButton.enabled = enabled;
    self.refreshButton.enabled = enabled;
    self.pasteImportButton.enabled = enabled;
    self.exportCopyButton.enabled = enabled;
    self.outputCopyButton.enabled = enabled;
    self.selectedCopyButton.enabled = enabled && self.selectedAccount != nil;
    self.selectedMailCopyButton.enabled = enabled && self.selectedAccount != nil;
    self.selectedPasswordCopyButton.enabled = enabled && self.selectedAccount != nil;
    self.messagesSelectedButton.enabled = enabled && self.selectedAccount != nil;
    self.deleteSelectedButton.enabled = enabled && self.selectedAccount != nil;
}

- (void)beginAction:(NSString *)message {
    [self.view endEditing:YES];
    self.runningActions += 1;
    if (message.length) self.statusLabel.text = message;
    [self.spinner startAnimating];
    [self setControlsEnabled:NO];
}

- (void)endAction:(NSString *)message {
    self.runningActions = MAX(0, self.runningActions - 1);
    if (message.length) self.statusLabel.text = message;
    if (self.runningActions == 0) {
        [self.spinner stopAnimating];
        [self setControlsEnabled:YES];
    }
}

- (void)setProgressCurrent:(NSInteger)current total:(NSInteger)total text:(NSString *)text {
    NSInteger safeTotal = MAX(1, total);
    float progress = MIN(1.0f, MAX(0.0f, (float)current / (float)safeTotal));
    [self.circularProgress setProgress:progress animated:YES];
}

- (void)startProgressSimulationForCount:(NSInteger)count provider:(NSString *)provider delayMs:(NSInteger)delayMs {
    [self.progressTimer invalidate];
    self.progressRequested = MAX(1, count);
    self.progressCurrent = 0;
    [self.circularProgress reset];
    self.circularProgress.hidden = NO;
    [self.generateButton startShimmer];
    [self setProgressCurrent:0 total:self.progressRequested text:@""];
    NSTimeInterval interval = [provider isEqualToString:@"tempemail"] ? MAX(1.2, ((double)MAX(0, delayMs) / 1000.0)) : 0.7;
    self.progressTimer = [NSTimer scheduledTimerWithTimeInterval:interval target:self selector:@selector(handleProgressTick) userInfo:nil repeats:YES];
}

- (void)handleProgressTick {
    self.progressCurrent = MIN(self.progressRequested, self.progressCurrent + 1);
    [self setProgressCurrent:self.progressCurrent total:self.progressRequested text:[NSString stringWithFormat:@"Traitement %ld/%ld", (long)self.progressCurrent, (long)self.progressRequested]];
}

- (void)stopProgressSimulationWithText:(NSString *)text success:(BOOL)success {
    [self.progressTimer invalidate];
    self.progressTimer = nil;
    [self.generateButton stopShimmer];
    if (success) {
        [self.circularProgress showSuccess];
        UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleMedium];
        [haptic impactOccurred];
    } else {
        NSInteger finalValue = self.progressCurrent;
        [self setProgressCurrent:finalValue total:self.progressRequested text:text];
    }
}

- (void)showOutputObject:(id)obj {
    self.outputTextView.text = [[GMLAccountStore shared] jsonString:obj];
}

- (void)showOutputString:(NSString *)text {
    self.outputTextView.text = text ?: @"";
}

- (void)showToast:(NSString *)text {
    UIImpactFeedbackGenerator *haptic = [[UIImpactFeedbackGenerator alloc] initWithStyle:UIImpactFeedbackStyleLight];
    [haptic impactOccurred];
    UILabel *toast = [[UILabel alloc] initWithFrame:CGRectZero];
    toast.translatesAutoresizingMaskIntoConstraints = NO;
    toast.text = text;
    toast.font = [UIFont systemFontOfSize:14 weight:UIFontWeightSemibold];
    toast.textColor = [UIColor whiteColor];
    toast.backgroundColor = [UIColor colorWithRed:0.20 green:0.50 blue:0.85 alpha:0.95];
    toast.textAlignment = NSTextAlignmentCenter;
    toast.layer.cornerRadius = 10;
    toast.clipsToBounds = YES;
    toast.alpha = 0;
    [self.view addSubview:toast];
    [NSLayoutConstraint activateConstraints:@[
        [toast.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
        [toast.bottomAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.bottomAnchor constant:-20],
        [toast.heightAnchor constraintEqualToConstant:40],
        [toast.widthAnchor constraintGreaterThanOrEqualToConstant:160],
        [toast.leadingAnchor constraintGreaterThanOrEqualToAnchor:self.view.leadingAnchor constant:40],
        [toast.trailingAnchor constraintLessThanOrEqualToAnchor:self.view.trailingAnchor constant:-40]
    ]];
    [UIView animateWithDuration:0.25 animations:^{
        toast.alpha = 1.0;
    } completion:^(BOOL finished) {
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [UIView animateWithDuration:0.3 animations:^{ toast.alpha = 0; } completion:^(BOOL f) { [toast removeFromSuperview]; }];
        });
    }];
}

- (void)refreshExportFromAccounts {
    NSMutableArray *lines = [NSMutableArray array];
    for (NSDictionary *item in self.displayedAccounts) {
        if ([[[GMLAccountStore shared] stringValue:item[@"status"] fallback:@""] isEqualToString:@"ok"]) {
            NSString *email = [[GMLAccountStore shared] stringValue:item[@"email"] fallback:@""];
            NSString *password = [[GMLAccountStore shared] stringValue:item[@"password"] fallback:@""];
            if (email.length && password.length) [lines addObject:[NSString stringWithFormat:@"%@:%@", email, password]];
        }
    }
    self.exportTextView.text = lines.count ? [lines componentsJoinedByString:@"\n"] : @"Aucun compte OK pour ce provider.";
}

- (void)updateAccountsTableHeight {
    NSInteger visibleRows = self.displayedAccounts.count > 0 ? MIN(6, self.displayedAccounts.count) : 1;
    CGFloat height = visibleRows * self.accountsTableView.rowHeight + 24.0;
    self.accountsTableHeightConstraint.constant = MAX(120.0, height);
    self.accountsTableView.scrollEnabled = self.displayedAccounts.count > 6;
}

- (void)updateSelectionUI {
    NSString *email = [[GMLAccountStore shared] stringValue:self.selectedAccount[@"email"] fallback:@""];
    NSString *status = [[GMLAccountStore shared] stringValue:self.selectedAccount[@"status"] fallback:@""];
    NSString *countText = [NSString stringWithFormat:@"%lu compte%@", (unsigned long)self.displayedAccounts.count, self.displayedAccounts.count > 1 ? @"s" : @""];
    BOOL hasSelection = self.selectedAccount != nil;

    if (email.length) {
        self.selectionLabel.text = [NSString stringWithFormat:@"%@ - Selection: %@ (%@)", countText, email, status.length ? status : @"sans statut"];
    } else {
        self.selectionLabel.text = self.displayedAccounts.count ? [NSString stringWithFormat:@"%@ - Touchez une ligne pour voir les actions", countText] : @"Aucun compte genere pour ce provider";
    }

    // Show/hide action rows based on selection (progressive disclosure)
    self.selectionLabel.hidden = !hasSelection && self.displayedAccounts.count == 0;
    self.selectionActionsRow.hidden = !hasSelection;
    self.selectionActionsSecondaryRow.hidden = !hasSelection;

    BOOL enabled = hasSelection && self.runningActions == 0;
    self.selectedCopyButton.enabled = enabled;
    self.selectedMailCopyButton.enabled = enabled;
    self.selectedPasswordCopyButton.enabled = enabled;
    self.messagesSelectedButton.enabled = enabled;
    self.deleteSelectedButton.enabled = enabled;
}

- (void)chooseDomainTapped {
    if (self.domains.count == 0) {
        [self appendLog:@"Aucun domaine disponible a choisir." level:@"WARN"];
        return;
    }

    UIAlertController *sheet = [UIAlertController alertControllerWithTitle:@"Choisir domaine" message:nil preferredStyle:UIAlertControllerStyleActionSheet];
    for (NSString *domain in self.domains) {
        [sheet addAction:[UIAlertAction actionWithTitle:domain style:UIAlertActionStyleDefault handler:^(__unused UIAlertAction *action) {
            [self.domainButton setTitle:domain forState:UIControlStateNormal];
            [self updateSettingsSummary];
            [self appendLog:[NSString stringWithFormat:@"Domaine selectionne: %@", domain] level:@"INFO"];
        }]];
    }
    [sheet addAction:[UIAlertAction actionWithTitle:@"Annuler" style:UIAlertActionStyleCancel handler:nil]];
    if (sheet.popoverPresentationController) sheet.popoverPresentationController.sourceView = self.domainButton;
    [self presentViewController:sheet animated:YES completion:nil];
}

- (void)loadDomainsTapped {
    [self beginAction:@"Chargement domaines"];
    [self loadDomainsNativeWithCompletion:^{
        [self endAction:@"Domaines charges"];
    }];
}

- (void)generateTapped {
    NSLog(@"[GenMail] generateTapped called, provider=%@ domain=%@ runningActions=%ld", [self providerKey], [self currentDomain], (long)self.runningActions);
    NSInteger count = MAX(1, MIN(200, [[[GMLAccountStore shared] stringValue:self.countField.text fallback:@"5"] integerValue]));
    NSInteger delayMs = [[[GMLAccountStore shared] stringValue:self.delayField.text fallback:@"0"] integerValue];
    NSDictionary *params = @{
        @"provider": [self providerKey],
        @"count": @(count),
        @"domain": [self currentDomain],
        @"prefix": [[GMLAccountStore shared] stringValue:self.prefixField.text fallback:@""],
        @"password_mode": self.passwordModeControl.selectedSegmentIndex == 1 ? @"fixed" : @"random",
        @"fixed_password": [[GMLAccountStore shared] stringValue:self.fixedPasswordField.text fallback:@""],
        @"verify_login": @(self.verifyLoginControl.selectedSegmentIndex == 0),
        @"delay_ms": @(MAX(0, delayMs))
    };

    NSLog(@"[GenMail] generateTapped params=%@", params);
    [self beginAction:@"Generation en cours"];
    [self startProgressSimulationForCount:count provider:[self providerKey] delayMs:delayMs];
    [self performNativeAction:@"generateAccounts" params:params completion:^(BOOL ok, id payload) {
        NSLog(@"[GenMail] generateAccounts completion ok=%d payload_class=%@", ok, NSStringFromClass([payload class]));
        if (ok && [payload isKindOfClass:[NSDictionary class]]) {
            NSDictionary *data = (NSDictionary *)payload;
            NSDictionary *summary = [data[@"summary"] isKindOfClass:[NSDictionary class]] ? data[@"summary"] : @{};
            NSArray *items = [data[@"items"] isKindOfClass:[NSArray class]] ? data[@"items"] : @[];
            NSInteger success = [summary[@"success"] integerValue];
            NSInteger failed = [summary[@"failed"] integerValue];
            NSString *focusEmail = @"";
            NSString *provider = [self providerKey];
            NSDictionary *cfg = [[GMLAccountStore shared] providerConfig:provider] ?: @{};
            NSString *providerLabel = [[GMLAccountStore shared] stringValue:cfg[@"label"] fallback:provider];
            NSMutableArray *quickAccounts = [NSMutableArray array];
            for (NSDictionary *item in items) {
                if (![item isKindOfClass:[NSDictionary class]]) continue;
                BOOL itemOk = [item[@"ok"] boolValue];
                if (itemOk) {
                    focusEmail = [[GMLAccountStore shared] stringValue:item[@"email"] fallback:@""];
                }
                if (!itemOk) continue;
                NSString *email = [[GMLAccountStore shared] stringValue:item[@"email"] fallback:@""];
                if (email.length == 0) continue;
                [quickAccounts addObject:@{
                    @"provider": provider ?: @"",
                    @"provider_label": providerLabel ?: @"",
                    @"email": email,
                    @"password": [[GMLAccountStore shared] stringValue:item[@"password"] fallback:@""],
                    @"status": [[GMLAccountStore shared] stringValue:item[@"status"] fallback:@""],
                    @"last_error": [[GMLAccountStore shared] stringValue:item[@"error"] fallback:@""],
                    @"messages_count": @0
                }];
                if (focusEmail.length == 0) {
                    focusEmail = email;
                }
            }
            if (focusEmail.length == 0) {
                NSDictionary *firstItem = [items.firstObject isKindOfClass:[NSDictionary class]] ? items.firstObject : nil;
                focusEmail = [[GMLAccountStore shared] stringValue:firstItem[@"email"] fallback:@""];
            }
            if (quickAccounts.count > 0) {
                NSArray *quickReversed = [[quickAccounts reverseObjectEnumerator] allObjects];
                self.pendingGeneratedAccounts = quickReversed;
                self.displayedAccounts = [quickReversed mutableCopy];
                self.selectedAccount = self.displayedAccounts.firstObject;
                [self.accountsTableView reloadData];
                [self updateAccountsTableHeight];
                [self refreshExportFromAccounts];
                [self updateSelectionUI];
            } else if (focusEmail.length) {
                self.selectedAccount = @{ @"email": focusEmail };
            }
            NSString *exportText = [[GMLAccountStore shared] stringValue:data[@"export"] fallback:@""];
            // If all failed, surface the first API error message instead of empty export
            if (success == 0 && failed > 0) {
                NSArray *items = [data[@"items"] isKindOfClass:[NSArray class]] ? data[@"items"] : @[];
                NSString *firstErr = @"";
                for (NSDictionary *it in items) {
                    NSString *err = [[GMLAccountStore shared] stringValue:it[@"last_error"] fallback:@""];
                    if (err.length) { firstErr = err; break; }
                }
                if (firstErr.length) {
                    exportText = [NSString stringWithFormat:@"❌ %ld/%ld echec(s).\nErreur API: %@", (long)failed, (long)(success + failed), firstErr];
                }
            }
            self.exportTextView.text = exportText;
            [self showOutputObject:data];
            [self updateMenuVisibility];
            [self stopProgressSimulationWithText:[NSString stringWithFormat:@"Termine - %ld OK / %ld KO", (long)success, (long)failed] success:(success > 0)];
            [self refreshAccountsNativeWithCompletion:nil];
            [self endAction:@"Generation terminee"];
            if (success > 0) {
                [self showToast:[NSString stringWithFormat:@"%ld comptes → onglet Comptes", (long)success]];
            } else if (failed > 0) {
                [self showToast:[NSString stringWithFormat:@"❌ %ld echec(s) — voir details", (long)failed]];
            }
            return;
        }
        [self showOutputString:[[GMLAccountStore shared] stringValue:payload fallback:@"Erreur de generation"]];
        [self stopProgressSimulationWithText:@"Erreur pendant la generation" success:NO];
        [self endAction:@"Generation en echec"];
    }];
}

- (void)importTapped {
    NSDictionary *params = @{
        @"provider": [self providerKey],
        @"lines": [[GMLAccountStore shared] stringValue:self.bulkTextView.text fallback:@""]
    };
    [self beginAction:@"Import en cours"];
    [self performNativeAction:@"importAccounts" params:params completion:^(BOOL ok, id payload) {
        if (ok) {
            [self showOutputObject:payload];
            // menuControl removed (tabs replace segmented control)
            [self updateMenuVisibility];
            [self refreshAccountsNativeWithCompletion:nil];
            [self endAction:@"Import termine"];
            return;
        }
        [self showOutputString:[[GMLAccountStore shared] stringValue:payload fallback:@"Erreur import"]];
        [self endAction:@"Import en echec"];
    }];
}

- (void)loginAllTapped {
    [self beginAction:@"Login all en cours"];
    [self performNativeAction:@"loginAll" params:@{ @"provider": [self providerKey] } completion:^(BOOL ok, id payload) {
        if (ok) {
            [self showOutputObject:payload];
            // menuControl removed (tabs replace segmented control)
            [self updateMenuVisibility];
            [self refreshAccountsNativeWithCompletion:nil];
            [self endAction:@"Login all termine"];
            return;
        }
        [self showOutputString:[[GMLAccountStore shared] stringValue:payload fallback:@"Erreur login all"]];
        [self endAction:@"Login all en echec"];
    }];
}

- (void)refreshTapped {
    [self beginAction:@"Synchronisation interface"];
    [self loadDomainsNativeWithCompletion:^{
        [self refreshAccountsNativeWithCompletion:^{
            [self endAction:@"Interface synchronisee"];
        }];
    }];
}

- (void)copyExportTapped {
    [self beginAction:@"Copie export"];
    [self performNativeAction:@"exportText" params:@{ @"provider": [self providerKey] } completion:^(BOOL ok, id payload) {
        if (ok && [payload isKindOfClass:[NSDictionary class]]) {
            NSString *text = [[GMLAccountStore shared] stringValue:payload[@"text"] fallback:@""];
            self.exportTextView.text = text;
            [UIPasteboard generalPasteboard].string = text;
            [self showOutputString:text.length ? [NSString stringWithFormat:@"Export copie.\n\n%@", text] : @"Export vide."];
            self.statusLabel.text = text.length ? @"Export copie dans le presse-papiers" : @"Aucun export a copier";
            [self endAction:@"Export copie"];
            return;
        }
        [self showOutputString:[[GMLAccountStore shared] stringValue:payload fallback:@"Erreur export"]];
        [self endAction:@"Export en echec"];
    }];
}

- (void)copyOutputTapped {
    NSString *text = [[GMLAccountStore shared] stringValue:self.outputTextView.text fallback:@""];
    [UIPasteboard generalPasteboard].string = text;
    self.statusLabel.text = text.length ? @"Sortie detaillee copiee" : @"Sortie vide";
    [self appendLog:@"Copie de la sortie detaillee." level:@"INFO"];
}

- (void)pasteImportTapped {
    NSString *paste = [[GMLAccountStore shared] stringValue:[UIPasteboard generalPasteboard].string fallback:@""];
    self.bulkTextView.text = paste;
    self.statusLabel.text = paste.length ? @"Texte colle dans la zone import" : @"Le presse-papiers est vide";
    [self appendLog:@"Collage du presse-papiers dans la zone import." level:@"INFO"];
}

- (NSDictionary *)selectedAccountOrFirst {
    if (!self.selectedAccount && self.displayedAccounts.count > 0) self.selectedAccount = self.displayedAccounts.firstObject;
    return self.selectedAccount;
}

- (void)copySelectedTapped {
    NSDictionary *account = [self selectedAccountOrFirst];
    if (!account) return;
    NSString *email = [[GMLAccountStore shared] stringValue:account[@"email"] fallback:@""];
    NSString *password = [[GMLAccountStore shared] stringValue:account[@"password"] fallback:@""];
    NSString *line = [NSString stringWithFormat:@"%@:%@", email, password];
    [UIPasteboard generalPasteboard].string = line;
    [self showOutputString:line];
    self.statusLabel.text = @"Compte copie dans le presse-papiers";
    [self appendLog:[NSString stringWithFormat:@"Copie selection: %@", email] level:@"INFO"];
}

- (void)copySelectedMailTapped {
    NSDictionary *account = [self selectedAccountOrFirst];
    if (!account) return;
    NSString *email = [[GMLAccountStore shared] stringValue:account[@"email"] fallback:@""];
    [UIPasteboard generalPasteboard].string = email;
    [self showOutputString:email];
    self.statusLabel.text = @"Mail copie dans le presse-papiers";
    [self appendLog:[NSString stringWithFormat:@"Copie mail: %@", email] level:@"INFO"];
}

- (void)copySelectedPasswordTapped {
    NSDictionary *account = [self selectedAccountOrFirst];
    if (!account) return;
    NSString *email = [[GMLAccountStore shared] stringValue:account[@"email"] fallback:@""];
    NSString *password = [[GMLAccountStore shared] stringValue:account[@"password"] fallback:@""];
    [UIPasteboard generalPasteboard].string = password;
    [self showOutputString:password];
    self.statusLabel.text = @"Mot de passe copie dans le presse-papiers";
    [self appendLog:[NSString stringWithFormat:@"Copie mdp pour: %@", email] level:@"INFO"];
}

- (void)messagesSelectedTapped {
    if (!self.selectedAccount) return;
    NSString *provider = [[GMLAccountStore shared] stringValue:self.selectedAccount[@"provider"] fallback:@""];
    NSString *email = [[GMLAccountStore shared] stringValue:self.selectedAccount[@"email"] fallback:@""];
    [self beginAction:@"Chargement messages"];
    [self performNativeAction:@"messages" params:@{ @"provider": provider, @"email": email } completion:^(BOOL ok, id payload) {
        if (ok) {
            [self showOutputObject:payload];
            // menuControl removed (tabs replace segmented control)
            [self updateMenuVisibility];
            [self refreshAccountsNativeWithCompletion:nil];
            [self endAction:@"Messages charges"];
            return;
        }
        [self showOutputString:[[GMLAccountStore shared] stringValue:payload fallback:@"Erreur messages"]];
        [self endAction:@"Lecture messages en echec"];
    }];
}

- (void)deleteSelectedTapped {
    if (!self.selectedAccount) return;
    NSString *email = [[GMLAccountStore shared] stringValue:self.selectedAccount[@"email"] fallback:@""];
    NSString *provider = [[GMLAccountStore shared] stringValue:self.selectedAccount[@"provider"] fallback:@""];
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Supprimer localement" message:email preferredStyle:UIAlertControllerStyleAlert];
    [alert addAction:[UIAlertAction actionWithTitle:@"Annuler" style:UIAlertActionStyleCancel handler:nil]];
    [alert addAction:[UIAlertAction actionWithTitle:@"Supprimer" style:UIAlertActionStyleDestructive handler:^(__unused UIAlertAction *action) {
        [self beginAction:@"Suppression locale"];
        [self performNativeAction:@"deleteAccount" params:@{ @"provider": provider, @"email": email } completion:^(BOOL ok, id payload) {
            if (ok) {
                self.selectedAccount = nil;
                [self showOutputObject:payload];
                [self refreshAccountsNativeWithCompletion:nil];
                [self endAction:@"Compte supprime"];
                return;
            }
            [self showOutputString:[[GMLAccountStore shared] stringValue:payload fallback:@"Erreur suppression"]];
            [self endAction:@"Suppression en echec"];
        }];
    }]];
    [self presentViewController:alert animated:YES completion:nil];
}

- (void)loadDomainsNativeWithCompletion:(void (^)(void))completion {
    [self performNativeAction:@"domains" params:@{ @"provider": [self providerKey] } completion:^(BOOL ok, id payload) {
        if (ok && [payload isKindOfClass:[NSDictionary class]]) {
            NSArray *items = [payload[@"domains"] isKindOfClass:[NSArray class]] ? payload[@"domains"] : @[];
            self.domains = items;
            NSString *domain = items.firstObject ?: @"Aucun domaine";
            [self.domainButton setTitle:domain forState:UIControlStateNormal];
            [self updateSettingsSummary];
            [self showOutputObject:payload];
        } else {
            self.domains = @[];
            [self.domainButton setTitle:@"Aucun domaine" forState:UIControlStateNormal];
            [self updateSettingsSummary];
            [self showOutputString:[[GMLAccountStore shared] stringValue:payload fallback:@"Erreur domaines"]];
        }
        if (completion) completion();
    }];
}

- (void)refreshAccountsNativeWithCompletion:(void (^)(void))completion {
    NSString *provider = [self providerKey];
    NSString *selectedEmail = [[GMLAccountStore shared] stringValue:self.selectedAccount[@"email"] fallback:@""];
    NSArray *fallbackAccounts = self.pendingGeneratedAccounts ?: @[];
    [self performNativeAction:@"localAccounts" params:@{ @"provider": provider } completion:^(BOOL ok, id payload) {
        if (ok && [payload isKindOfClass:[NSDictionary class]]) {
            NSArray *items = [payload[@"items"] isKindOfClass:[NSArray class]] ? payload[@"items"] : @[];
            NSArray *reversed = [[items reverseObjectEnumerator] allObjects];
            if (reversed.count == 0 && fallbackAccounts.count > 0) {
                self.displayedAccounts = [fallbackAccounts mutableCopy];
                [self appendLog:@"Aucun compte local retourne, fallback sur les comptes generes en memoire." level:@"WARN"];
            } else {
                self.displayedAccounts = [reversed mutableCopy];
                if (reversed.count > 0) self.pendingGeneratedAccounts = @[];
            }
            self.selectedAccount = nil;
            for (NSDictionary *item in self.displayedAccounts) {
                NSString *email = [[GMLAccountStore shared] stringValue:item[@"email"] fallback:@""];
                if (selectedEmail.length && [email.lowercaseString isEqualToString:selectedEmail.lowercaseString]) {
                    self.selectedAccount = item;
                    break;
                }
            }
            if (!self.selectedAccount && self.displayedAccounts.count > 0) {
                self.selectedAccount = self.displayedAccounts.firstObject;
            }
            [self.accountsTableView reloadData];
            [self updateAccountsTableHeight];
            [self refreshExportFromAccounts];
            [self updateSelectionUI];
            if (self.displayedAccounts.count > 0) {
                NSIndexPath *top = [NSIndexPath indexPathForRow:0 inSection:0];
                [self.accountsTableView scrollToRowAtIndexPath:top atScrollPosition:UITableViewScrollPositionTop animated:NO];
                if (self.selectedAccount) {
                    NSUInteger index = [self.displayedAccounts indexOfObjectPassingTest:^BOOL(NSDictionary *obj, NSUInteger idx, BOOL *stop) {
                        return [[[[GMLAccountStore shared] stringValue:obj[@"email"] fallback:@""] lowercaseString] isEqualToString:selectedEmail.lowercaseString];
                    }];
                    if (index != NSNotFound) {
                        NSIndexPath *selectedPath = [NSIndexPath indexPathForRow:index inSection:0];
                        [self.accountsTableView scrollToRowAtIndexPath:selectedPath atScrollPosition:UITableViewScrollPositionMiddle animated:NO];
                    }
                }
            }
        } else {
            [self showOutputString:[[GMLAccountStore shared] stringValue:payload fallback:@"Erreur comptes locaux"]];
        }
        if (completion) completion();
    }];
}

#pragma mark - Native Action Dispatch

- (void)performNativeAction:(NSString *)action params:(NSDictionary *)params completion:(GMNativeCompletion)completion {
    NSString *requestId = [[NSUUID UUID] UUIDString];
    if (completion) self.pendingCallbacks[requestId] = [completion copy];
    if (requestId.length) self.requestActions[requestId] = action.length ? action : @"(sans action)";
    [self dispatchAction:action params:params ?: @{} requestId:requestId];
}

- (void)dispatchAction:(NSString *)action params:(NSDictionary *)params requestId:(NSString *)requestId {
    [self appendLog:[NSString stringWithFormat:@"Action %@ %@", action ?: @"(vide)", requestId ?: @""] level:@"API"];
    if ([action isEqualToString:@"providers"]) {
        [self resolve:requestId payload:@{ @"ok": @YES, @"providers": [[GMLAccountStore shared] providers] }];
    } else if ([action isEqualToString:@"domains"]) {
        [self handleDomains:params requestId:requestId];
    } else if ([action isEqualToString:@"localAccounts"]) {
        NSString *provider = [[GMLAccountStore shared] stringValue:params[@"provider"] fallback:@""];
        NSArray *items = [[GMLAccountStore shared] accountsForProvider:provider];
        [self resolve:requestId payload:@{ @"ok": @YES, @"items": items ?: @[] }];
    } else if ([action isEqualToString:@"importAccounts"]) {
        [self handleImport:params requestId:requestId];
    } else if ([action isEqualToString:@"generateAccounts"]) {
        [self handleGenerate:params requestId:requestId];
    } else if ([action isEqualToString:@"loginAll"]) {
        [self handleLoginAll:params requestId:requestId];
    } else if ([action isEqualToString:@"messages"]) {
        [self handleMessages:params requestId:requestId];
    } else if ([action isEqualToString:@"deleteAccount"]) {
        [self handleDelete:params requestId:requestId];
    } else if ([action isEqualToString:@"exportText"]) {
        NSString *provider = [[GMLAccountStore shared] stringValue:params[@"provider"] fallback:@""];
        NSArray *items = [[GMLAccountStore shared] accountsForProvider:provider];
        NSMutableArray *lines = [NSMutableArray array];
        for (NSDictionary *a in items) {
            if ([[[GMLAccountStore shared] stringValue:a[@"status"] fallback:@""] isEqualToString:@"ok"]) {
                NSString *email = [[GMLAccountStore shared] stringValue:a[@"email"] fallback:@""];
                NSString *password = [[GMLAccountStore shared] stringValue:a[@"password"] fallback:@""];
                if (email.length && password.length) [lines addObject:[NSString stringWithFormat:@"%@:%@", email, password]];
            }
        }
        [self resolve:requestId payload:@{ @"ok": @YES, @"text": [lines componentsJoinedByString:@"\n"] }];
    } else {
        [self reject:requestId error:@"Action inconnue"];
    }
}

#pragma mark - Actions

- (void)handleDomains:(NSDictionary *)params requestId:(NSString *)requestId {
    NSString *provider = [[GMLAccountStore shared] stringValue:params[@"provider"] fallback:@""];
    NSDictionary *cfg = [[GMLAccountStore shared] providerConfig:provider];
    if (!cfg) return [self reject:requestId error:@"provider invalide"];
    NSString *url = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/domains" : @"https://api.mail.tm/domains";
    [[GMLNetworkManager shared] requestJSON:@"GET" url:url token:nil jsonBody:nil provider:provider completion:^(NSInteger status, id payload) {
        if (status >= 400 || status == 0) return [self reject:requestId error:[[GMLAccountStore shared] jsonString:payload]];
        NSArray *domains = [[GMLNetworkManager shared] extractDomainsFromPayload:payload provider:provider];
        [self resolve:requestId payload:@{ @"ok": @YES, @"provider": provider, @"domains": domains ?: @[] }];
    }];
}

- (void)handleImport:(NSDictionary *)params requestId:(NSString *)requestId {
    NSString *provider = [[GMLAccountStore shared] stringValue:params[@"provider"] fallback:@""];
    NSDictionary *cfg = [[GMLAccountStore shared] providerConfig:provider];
    if (!cfg) return [self reject:requestId error:@"provider invalide"];
    NSString *lines = [[GMLAccountStore shared] stringValue:params[@"lines"] fallback:@""];
    NSMutableArray *accounts = [[[GMLAccountStore shared] loadAccounts] mutableCopy];
    NSInteger added = 0, updated = 0;
    for (NSString *raw in [lines componentsSeparatedByCharactersInSet:[NSCharacterSet newlineCharacterSet]]) {
        NSString *line = [raw stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
        NSRange sep = [line rangeOfString:@":"];
        if (line.length == 0 || sep.location == NSNotFound) continue;
        NSString *email = [[line substringToIndex:sep.location] lowercaseString];
        NSString *password = [line substringFromIndex:sep.location + 1];
        NSMutableDictionary *found = nil;
        for (NSMutableDictionary *acc in accounts) {
            if ([[[GMLAccountStore shared] stringValue:acc[@"provider"] fallback:@""] isEqualToString:provider] && [[[[GMLAccountStore shared] stringValue:acc[@"email"] fallback:@""] lowercaseString] isEqualToString:email]) {
                found = acc;
                break;
            }
        }
        if (found) {
            found[@"password"] = password;
            updated++;
        } else {
            [accounts addObject:[@{ @"provider": provider, @"provider_label": cfg[@"label"], @"email": email, @"password": password, @"base_url": cfg[@"base_url"], @"token": @"", @"remote_id": @"", @"status": @"imported", @"last_error": @"", @"messages_count": @0 } mutableCopy]];
            added++;
        }
    }
    [[GMLAccountStore shared] saveAccounts:accounts];
    [self resolve:requestId payload:@{ @"ok": @YES, @"added": @(added), @"updated": @(updated) }];
}

- (void)handleGenerate:(NSDictionary *)params requestId:(NSString *)requestId {
    NSString *provider = [[GMLAccountStore shared] stringValue:params[@"provider"] fallback:@""];
    NSDictionary *cfg = [[GMLAccountStore shared] providerConfig:provider];
    if (!cfg) return [self reject:requestId error:@"provider invalide"];
    NSInteger count = MAX(1, MIN(200, [params[@"count"] integerValue] ?: 1));
    NSString *requestedDomain = [[GMLAccountStore shared] stringValue:params[@"domain"] fallback:@""];
    NSString *prefix = [[[GMLAccountStore shared] stringValue:params[@"prefix"] fallback:@""] lowercaseString];
    BOOL verifyLogin = params[@"verify_login"] ? [params[@"verify_login"] boolValue] : YES;
    NSString *passwordMode = [[GMLAccountStore shared] stringValue:params[@"password_mode"] fallback:@"random"];
    NSString *fixedPassword = [[GMLAccountStore shared] stringValue:params[@"fixed_password"] fallback:@""];
    NSInteger delayMs = [params[@"delay_ms"] integerValue];

    [self appendLog:[NSString stringWithFormat:@"Generation demandee: provider=%@ count=%ld domain=%@ prefix=%@", provider, (long)count, requestedDomain.length ? requestedDomain : @"(auto)", prefix.length ? prefix : @"(vide)"] level:@"INFO"];

    NSLog(@"[GenMail] handleGenerate: fetching domains for provider=%@", provider);
    [[GMLNetworkManager shared] fetchDomainsForProvider:provider completion:^(NSArray *domains, NSString *error) {
        NSLog(@"[GenMail] handleGenerate: domains=%@ error=%@", domains, error);
        if (error || domains.count == 0) return [self reject:requestId error:error ?: @"Aucun domaine disponible"];
        NSString *domain = requestedDomain.length ? requestedDomain : domains.firstObject;
        if (![domains containsObject:domain]) return [self reject:requestId error:@"Domaine indisponible"];
        NSMutableArray *accounts = [[[GMLAccountStore shared] loadAccounts] mutableCopy];
        NSLog(@"[GenMail] handleGenerate: starting generation domain=%@ existingAccounts=%ld", domain, (long)accounts.count);
        NSMutableArray *results = [NSMutableArray array];
        [self generateNextForProvider:provider cfg:cfg domain:domain prefix:prefix verifyLogin:verifyLogin passwordMode:passwordMode fixedPassword:fixedPassword delayMs:delayMs remaining:count accounts:accounts results:results requestId:requestId];
    }];
}

- (void)generateNextForProvider:(NSString *)provider cfg:(NSDictionary *)cfg domain:(NSString *)domain prefix:(NSString *)prefix verifyLogin:(BOOL)verifyLogin passwordMode:(NSString *)passwordMode fixedPassword:(NSString *)fixedPassword delayMs:(NSInteger)delayMs remaining:(NSInteger)remaining accounts:(NSMutableArray *)accounts results:(NSMutableArray *)results requestId:(NSString *)requestId {
    if (remaining <= 0) {
        [[GMLAccountStore shared] saveAccounts:accounts];
        NSMutableArray *ok = [NSMutableArray array];
        for (NSDictionary *r in results) if ([r[@"ok"] boolValue]) [ok addObject:[NSString stringWithFormat:@"%@:%@", r[@"email"], r[@"password"]]];
        NSInteger failed = results.count - ok.count;
        [self resolve:requestId payload:@{ @"ok": @YES, @"summary": @{ @"requested": @(results.count), @"success": @(ok.count), @"failed": @(failed), @"domain": domain, @"provider": provider }, @"export": [ok componentsJoinedByString:@"\n"], @"items": results }];
        return;
    }

    NSString *email = [[GMLAccountStore shared] uniqueEmailForProvider:provider domain:domain prefix:prefix accounts:accounts];
    NSString *password = [passwordMode isEqualToString:@"fixed"] && fixedPassword.length ? fixedPassword : [[GMLAccountStore shared] randomPassword];
    // tempemail.cc requires at least 1 digit in password (since Apr 2026)
    if ([provider isEqualToString:@"tempemail"]) {
        NSCharacterSet *digits = [NSCharacterSet decimalDigitCharacterSet];
        if ([password rangeOfCharacterFromSet:digits].location == NSNotFound) {
            NSString *injected = [NSString stringWithFormat:@"%@%u", password, (unsigned int)arc4random_uniform(10)];
            [self appendLog:[NSString stringWithFormat:@"tempemail exige >=1 chiffre dans le mdp, ajustement: %@ -> %@", password, injected] level:@"WARN"];
            password = injected;
        }
    }
    NSMutableDictionary *item = [@{ @"provider": provider, @"provider_label": cfg[@"label"], @"email": email, @"password": password, @"base_url": cfg[@"base_url"], @"token": @"", @"remote_id": @"", @"status": @"create_error", @"last_error": @"", @"messages_count": @0 } mutableCopy];
    [self appendLog:[NSString stringWithFormat:@"Creation compte %@ (%@) reste=%ld", email, provider, (long)remaining] level:@"INFO"];

    NSString *createURL = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/accounts" : @"https://api.mail.tm/accounts";
    NSDictionary *createBody = [provider isEqualToString:@"tempemail"] ? @{ @"email": email, @"password": password } : @{ @"address": email, @"password": password };

    [[GMLNetworkManager shared] requestJSON:@"POST" url:createURL token:nil jsonBody:createBody provider:provider completion:^(NSInteger status, id payload) {
        void (^finishItem)(void) = ^{
            BOOL itemOk = [[[GMLAccountStore shared] stringValue:item[@"status"] fallback:@""] isEqualToString:@"ok"];
            if (itemOk) {
                [[GMLAccountStore shared] upsertAccount:item inAccounts:accounts];
            }
            [results addObject:@{ @"provider": provider, @"email": item[@"email"] ?: @"", @"password": item[@"password"] ?: @"", @"status": item[@"status"] ?: @"", @"ok": @(itemOk), @"error": item[@"last_error"] ?: @"" }];
            void (^nextBlock)(void) = ^{
                [self generateNextForProvider:provider cfg:cfg domain:domain prefix:prefix verifyLogin:verifyLogin passwordMode:passwordMode fixedPassword:fixedPassword delayMs:delayMs remaining:remaining - 1 accounts:accounts results:results requestId:requestId];
            };
            if (delayMs > 0 && [provider isEqualToString:@"tempemail"]) dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)delayMs * 1000000LL), dispatch_get_main_queue(), nextBlock);
            else nextBlock();
        };

        if (([provider isEqualToString:@"tempemail"] && status == 200) || ([provider isEqualToString:@"mailtm"] && (status == 200 || status == 201))) {
            if ([payload isKindOfClass:[NSDictionary class]]) item[@"remote_id"] = [[GMLAccountStore shared] stringValue:payload[@"id"] fallback:[[GMLAccountStore shared] stringValue:[payload[@"data"] isKindOfClass:[NSDictionary class]] ? payload[@"data"][@"id"] : @"" fallback:@""]];
            if ([provider isEqualToString:@"tempemail"] && [payload[@"data"] isKindOfClass:[NSDictionary class]]) {
                NSString *createdToken = [[GMLAccountStore shared] stringValue:payload[@"data"][@"token"] fallback:@""];
                if (createdToken.length) item[@"token"] = createdToken;
            }
            item[@"status"] = @"created";
            if (!verifyLogin) {
                item[@"status"] = @"ok";
                return finishItem();
            }

            NSString *loginURL = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/token" : @"https://api.mail.tm/token";
            NSDictionary *loginBody = [provider isEqualToString:@"tempemail"] ? @{ @"email": email, @"password": password } : @{ @"address": email, @"password": password };
            [[GMLNetworkManager shared] requestJSON:@"POST" url:loginURL token:nil jsonBody:loginBody provider:provider completion:^(NSInteger loginStatus, id loginPayload) {
                NSString *token = @"";
                if ([provider isEqualToString:@"tempemail"]) token = [[GMLAccountStore shared] stringValue:[loginPayload[@"data"] isKindOfClass:[NSDictionary class]] ? loginPayload[@"data"][@"token"] : @"" fallback:@""];
                else token = [[GMLAccountStore shared] stringValue:[loginPayload isKindOfClass:[NSDictionary class]] ? loginPayload[@"token"] : @"" fallback:@""];
                BOOL loginOk = [provider isEqualToString:@"tempemail"] ? (loginStatus == 200 && token.length) : ((loginStatus == 200 || loginStatus == 201) && token.length);
                if (!loginOk) {
                    item[@"status"] = @"login_error";
                    item[@"last_error"] = [[GMLAccountStore shared] jsonString:loginPayload];
                    return finishItem();
                }

                item[@"token"] = token;
                NSString *meURL = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/me" : @"https://api.mail.tm/me";
                [[GMLNetworkManager shared] requestJSON:@"GET" url:meURL token:token jsonBody:nil provider:provider completion:^(NSInteger meStatus, id mePayload) {
                    if (meStatus == 200) {
                        item[@"status"] = @"ok";
                        if ([mePayload isKindOfClass:[NSDictionary class]] && [mePayload[@"id"] isKindOfClass:[NSString class]]) item[@"remote_id"] = mePayload[@"id"];
                    } else {
                        item[@"status"] = @"check_error";
                        item[@"last_error"] = [[GMLAccountStore shared] jsonString:mePayload];
                    }
                    finishItem();
                }];
            }];
        } else {
            item[@"last_error"] = [[GMLAccountStore shared] jsonString:payload];
            finishItem();
        }
    }];
}

- (void)handleLoginAll:(NSDictionary *)params requestId:(NSString *)requestId {
    NSString *provider = [[GMLAccountStore shared] stringValue:params[@"provider"] fallback:@""];
    NSDictionary *cfg = [[GMLAccountStore shared] providerConfig:provider];
    if (!cfg) return [self reject:requestId error:@"provider invalide"];
    NSMutableArray *accounts = [[[GMLAccountStore shared] loadAccounts] mutableCopy];
    NSMutableArray *targets = [NSMutableArray array];
    for (NSMutableDictionary *a in accounts) if ([[[GMLAccountStore shared] stringValue:a[@"provider"] fallback:@""] isEqualToString:provider]) [targets addObject:a];
    [self loginNextProvider:provider cfg:cfg index:0 targets:targets allAccounts:accounts out:[NSMutableArray array] requestId:requestId];
}

- (void)loginNextProvider:(NSString *)provider cfg:(NSDictionary *)cfg index:(NSInteger)index targets:(NSMutableArray *)targets allAccounts:(NSMutableArray *)allAccounts out:(NSMutableArray *)out requestId:(NSString *)requestId {
    if (index >= targets.count) {
        [[GMLAccountStore shared] saveAccounts:allAccounts];
        [self resolve:requestId payload:@{ @"ok": @YES, @"items": out }];
        return;
    }

    NSMutableDictionary *a = targets[index];
    NSString *email = [[GMLAccountStore shared] stringValue:a[@"email"] fallback:@""];
    NSString *password = [[GMLAccountStore shared] stringValue:a[@"password"] fallback:@""];
    NSString *url = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/token" : @"https://api.mail.tm/token";
    NSDictionary *body = [provider isEqualToString:@"tempemail"] ? @{ @"email": email, @"password": password } : @{ @"address": email, @"password": password };
    [[GMLNetworkManager shared] requestJSON:@"POST" url:url token:nil jsonBody:body provider:provider completion:^(NSInteger status, id payload) {
        NSString *token = [provider isEqualToString:@"tempemail"] ? [[GMLAccountStore shared] stringValue:[payload[@"data"] isKindOfClass:[NSDictionary class]] ? payload[@"data"][@"token"] : @"" fallback:@""] : [[GMLAccountStore shared] stringValue:[payload isKindOfClass:[NSDictionary class]] ? payload[@"token"] : @"" fallback:@""];
        BOOL ok = [provider isEqualToString:@"tempemail"] ? (status == 200 && token.length) : ((status == 200 || status == 201) && token.length);
        if (ok) {
            a[@"token"] = token;
            a[@"status"] = @"ok";
            a[@"last_error"] = @"";
            [out addObject:@{ @"email": email, @"ok": @YES }];
        } else {
            a[@"status"] = @"login_error";
            a[@"last_error"] = [[GMLAccountStore shared] jsonString:payload];
            [out addObject:@{ @"email": email, @"ok": @NO, @"error": a[@"last_error"] ?: @"" }];
        }
        [self loginNextProvider:provider cfg:cfg index:index + 1 targets:targets allAccounts:allAccounts out:out requestId:requestId];
    }];
}

- (void)handleMessages:(NSDictionary *)params requestId:(NSString *)requestId {
    NSString *provider = [[GMLAccountStore shared] stringValue:params[@"provider"] fallback:@""];
    NSString *email = [[[GMLAccountStore shared] stringValue:params[@"email"] fallback:@""] lowercaseString];
    NSMutableArray *accounts = [[[GMLAccountStore shared] loadAccounts] mutableCopy];
    NSMutableDictionary *target = nil;
    for (NSMutableDictionary *a in accounts) {
        if ([[[GMLAccountStore shared] stringValue:a[@"provider"] fallback:@""] isEqualToString:provider] && [[[[GMLAccountStore shared] stringValue:a[@"email"] fallback:@""] lowercaseString] isEqualToString:email]) {
            target = a;
            break;
        }
    }
    if (!target) return [self reject:requestId error:@"Compte introuvable"];
    NSString *token = [[GMLAccountStore shared] stringValue:target[@"token"] fallback:@""];
    if (token.length == 0) return [self reject:requestId error:@"Token absent"];
    NSString *url = [provider isEqualToString:@"tempemail"] ? @"https://www.tempemail.cc/api/messages" : @"https://api.mail.tm/messages";
    [[GMLNetworkManager shared] requestJSON:@"GET" url:url token:token jsonBody:nil provider:provider completion:^(NSInteger status, id payload) {
        if (status >= 400 || status == 0) return [self reject:requestId error:[[GMLAccountStore shared] jsonString:payload]];
        NSArray *items = [provider isEqualToString:@"tempemail"] ? ([payload[@"data"] isKindOfClass:[NSDictionary class]] ? payload[@"data"][@"items"] : @[]) : ([payload isKindOfClass:[NSDictionary class]] ? payload[@"hydra:member"] : @[]);
        target[@"messages_count"] = @([items count]);
        [[GMLAccountStore shared] saveAccounts:accounts];
        [self resolve:requestId payload:@{ @"ok": @YES, @"response": payload ?: @{} }];
    }];
}

- (void)handleDelete:(NSDictionary *)params requestId:(NSString *)requestId {
    NSString *provider = [[GMLAccountStore shared] stringValue:params[@"provider"] fallback:@""];
    NSString *email = [[[GMLAccountStore shared] stringValue:params[@"email"] fallback:@""] lowercaseString];
    NSArray *accounts = [[GMLAccountStore shared] loadAccounts];
    NSMutableArray *filtered = [NSMutableArray array];
    NSInteger removed = 0;
    for (NSDictionary *a in accounts) {
        BOOL match = [[[GMLAccountStore shared] stringValue:a[@"provider"] fallback:@""] isEqualToString:provider] && [[[[GMLAccountStore shared] stringValue:a[@"email"] fallback:@""] lowercaseString] isEqualToString:email];
        if (match) removed++;
        else [filtered addObject:[a mutableCopy]];
    }
    [[GMLAccountStore shared] saveAccounts:filtered];
    [self resolve:requestId payload:@{ @"ok": @YES, @"removed": @(removed) }];
}

- (void)resolve:(NSString *)requestId payload:(NSDictionary *)payload {
    NSString *action = requestId.length ? self.requestActions[requestId] : nil;
    if (requestId.length) [self.requestActions removeObjectForKey:requestId];
    [self appendLog:[NSString stringWithFormat:@"Resolve %@ -> %@", action ?: @"(inconnu)", [[GMLAccountStore shared] compactString:[[GMLAccountStore shared] jsonString:payload ?: @{}] limit:220]] level:@"API"];
    GMNativeCompletion completion = requestId.length ? self.pendingCallbacks[requestId] : nil;
    if (requestId.length) [self.pendingCallbacks removeObjectForKey:requestId];
    if (completion) completion(YES, payload ?: @{});
}

- (void)reject:(NSString *)requestId error:(NSString *)error {
    NSString *action = requestId.length ? self.requestActions[requestId] : nil;
    if (requestId.length) [self.requestActions removeObjectForKey:requestId];
    [self appendLog:[NSString stringWithFormat:@"Reject %@ -> %@", action ?: @"(inconnu)", [[GMLAccountStore shared] compactString:error ?: @"Erreur" limit:220]] level:@"ERROR"];
    GMNativeCompletion completion = requestId.length ? self.pendingCallbacks[requestId] : nil;
    if (requestId.length) [self.pendingCallbacks removeObjectForKey:requestId];
    if (completion) completion(NO, error ?: @"Erreur");
}

- (void)appendLog:(NSString *)message level:(NSString *)level {
    NSString *cleanLevel = [[GMLAccountStore shared] stringValue:level fallback:@"INFO"];
    NSString *cleanMessage = [[GMLAccountStore shared] stringValue:message fallback:@""];
    NSString *entry = [NSString stringWithFormat:@"[%@] %@ %@", [self.logFormatter stringFromDate:[NSDate date]], cleanLevel, cleanMessage];
    NSLog(@"%@", entry);
    [self.logEntries addObject:entry];
    while (self.logEntries.count > 140) [self.logEntries removeObjectAtIndex:0];
    self.logTextView.text = [self.logEntries componentsJoinedByString:@"\n"];
    [self.logTextView.text writeToFile:self.logsPath atomically:YES encoding:NSUTF8StringEncoding error:nil];
    if (self.logTextView.text.length > 0) {
        NSRange bottom = NSMakeRange(self.logTextView.text.length - 1, 1);
        [self.logTextView scrollRangeToVisible:bottom];
    }
}

- (void)clearLogs {
    [self.logEntries removeAllObjects];
    self.logTextView.text = @"Journal vide.";
    [self.logTextView.text writeToFile:self.logsPath atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

#pragma mark - Table

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.displayedAccounts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *reuse = @"AccountCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuse];
    if (!cell) cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:reuse];

    NSDictionary *item = self.displayedAccounts[indexPath.row];
    NSString *email = [[GMLAccountStore shared] stringValue:item[@"email"] fallback:@"(sans email)"];
    NSString *provider = [[GMLAccountStore shared] stringValue:item[@"provider_label"] fallback:[[GMLAccountStore shared] stringValue:item[@"provider"] fallback:@""]];
    NSString *status = [[GMLAccountStore shared] stringValue:item[@"status"] fallback:@""];
    NSString *error = [[GMLAccountStore shared] stringValue:item[@"last_error"] fallback:@""];
    NSInteger messages = [item[@"messages_count"] integerValue];

    cell.backgroundColor = [UIColor colorWithRed:0.06 green:0.08 blue:0.12 alpha:1.0];
    cell.contentView.backgroundColor = cell.backgroundColor;
    cell.textLabel.text = email;
    cell.textLabel.textColor = UIColor.whiteColor;
    cell.textLabel.font = [UIFont systemFontOfSize:15 weight:UIFontWeightSemibold];
    NSString *detail = [NSString stringWithFormat:@"%@ | %@ | msg:%ld%@", provider, status.length ? status : @"-", (long)messages, error.length ? [NSString stringWithFormat:@" | %@", [[GMLAccountStore shared] compactString:error limit:70]] : @""];
    cell.detailTextLabel.text = detail;
    cell.detailTextLabel.textColor = [UIColor colorWithRed:0.66 green:0.71 blue:0.83 alpha:1.0];
    cell.detailTextLabel.numberOfLines = 2;
    cell.accessoryType = (self.selectedAccount == item) ? UITableViewCellAccessoryCheckmark : UITableViewCellAccessoryNone;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.selectedAccount = self.displayedAccounts[indexPath.row];
    [self updateSelectionUI];
    [self.accountsTableView reloadData];
}

@end
